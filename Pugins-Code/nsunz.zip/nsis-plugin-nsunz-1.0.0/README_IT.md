# nsisunz NSIS Plugin

**Plugin NSIS per estrazione file ZIP**

## Versioni

| Cartella | Versione zlib | Note |
|----------|---------------|------|
| `zlib-1.1.3/` | zlib 1.1.3 (1998) | Versione originale |
| `zlib-1.3/` | zlib 1.3.1 (2023) | Versione aggiornata |

## Script di Build

Il repo include un unico script unificato `build_plugin.py` che sostituisce i precedenti script per-versione.

## Compilazione

```powershell
# Raccomandato: zlib 1.3 con toolset rilevato automaticamente
python build_plugin.py

# Seleziona versione zlib (1.1.3 = legacy, 1.3 = default)
python build_plugin.py --zlib-version 1.1.3

# Toolset specifico (2022|2026|auto)
python build_plugin.py --toolset 2022

# Stampa versione ed esce
python build_plugin.py --version
```

## Output

I DLL compilati vengono copiati in `plugins/{platform}/nsisunz.dll`:

- `plugins/x86-ansi/nsisunz.dll`
- `plugins/x86-unicode/nsisunz.dll`
- `plugins/amd64-unicode/nsisunz.dll`

## Documentazione

- **zlib 1.3**: Vedi [zlib-1.3/README.md](zlib-1.3/README.md) e [zlib-1.3/BUILD_INFO.md](zlib-1.3/BUILD_INFO.md)
- **zlib 1.1.3**: Vedi [zlib-1.1.3/README.md](zlib-1.1.3/README.md)

## Crediti

Basato su [past-due/nsisunz](https://github.com/past-due/nsisunz)
