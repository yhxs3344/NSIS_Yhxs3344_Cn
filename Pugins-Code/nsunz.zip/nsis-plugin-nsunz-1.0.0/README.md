# nsisunz NSIS Plugin

NSIS plugin for ZIP file extraction.

## Versions

| Folder | zlib version | Notes |
|--------|-------------|-------|
| `zlib-1.1.3/` | zlib 1.1.3 (1998) | Original version |
| `zlib-1.3/` | zlib 1.3.1 (2023) | Updated version |

## Build Script

The repo includes a single unified `build_plugin.py` script that replaces the previous per-version scripts.

## Build

```powershell
# Recommended: zlib 1.3 with auto-detected toolset
python build_plugin.py

# Select zlib version (1.1.3 = legacy, 1.3 = default)
python build_plugin.py --zlib-version 1.1.3

# Specific toolset (2022|2026|auto)
python build_plugin.py --toolset 2022

# Print version and exit
python build_plugin.py --version
```

## Output

Compiled DLLs are copied to `plugins/{platform}/nsisunz.dll`:

- `plugins/x86-ansi/nsisunz.dll`
- `plugins/x86-unicode/nsisunz.dll`
- `plugins/amd64-unicode/nsisunz.dll`

## Documentation

- **zlib 1.3**: See [zlib-1.3/README.md](zlib-1.3/README.md) and [zlib-1.3/BUILD_INFO.md](zlib-1.3/BUILD_INFO.md)
- **zlib 1.1.3**: See [zlib-1.1.3/README.md](zlib-1.1.3/README.md)

## Credits

Based on [past-due/nsisunz](https://github.com/past-due/nsisunz)

---

*See [README_IT.md](README_IT.md) for the Italian version.*
