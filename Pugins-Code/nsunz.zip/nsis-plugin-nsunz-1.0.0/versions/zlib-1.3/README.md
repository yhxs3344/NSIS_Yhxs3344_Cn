# nsisunz NSIS Plugin - zlib 1.3.1

**Plugin NSIS per estrazione file ZIP con zlib 1.3.1**

Basato su [past-due/nsisunz](https://github.com/past-due/nsisunz) - Aggiornato da zlib 1.1.3 (1998) a zlib 1.3.1 (2023).

## Quick Start

### Compilazione

**Visual Studio 2022:**
```cmd
cd nsUnz
python build_plugin_zlib13_vs2022.py
```

**Visual Studio 2026:**
```cmd
cd nsUnz
python build_plugin_zlib13_vs2026.py
```

I DLL compilati vengono copiati in `plugins/{platform}/nsisunz.dll`.

**Installa VS2026 Build Tools:** `choco install visualstudio2026buildtools`

### Output

Dopo la compilazione:
- `plugins/x86-ansi/nsisunz.dll` (~124 KB)
- `plugins/x86-unicode/nsisunz.dll` (~127-129 KB)
- `plugins/amd64-unicode/nsisunz.dll` (~150-153 KB)

**Documentazione completa:** Vedi [BUILD_INFO.md](BUILD_INFO.md) per dettagli su VS2022/VS2026.

---

## Uso in NSIS

### UnzipToLog

Estrae i file e mostra il log dettagliato:

```nsis
InitPluginsDir
; Chiama il plugin. Prima il file ZIP, poi la cartella di destinazione.
nsisunz::UnzipToLog "$PLUGINSDIR\myzipfile.zip" "$INSTDIR"

; Controlla sempre il risultato sullo stack
Pop $0
StrCmp $0 "success" ok
DetailPrint "$0" ; stampa messaggio di errore nel log
ok:
```

### Unzip

Estrazione veloce senza log (preferita per archivi grandi):

```nsis
nsisunz::Unzip "$PLUGINSDIR\myzipfile.zip" "$INSTDIR"
```

---

## Caratteristiche Versione zlib 1.3.1

### Aggiornamenti principali

**zlib 1.1.3 (1998) → zlib 1.3.1 (2023):**
- 25 anni di correzioni di sicurezza
- Prestazioni decompressione migliorate del 20-30%
- Supporto ZIP64 completo per archivi > 4GB
- Minizip aggiornato dalla versione contrib/minizip di zlib 1.3.1

### File zlib inclusi

**Core decompressione:**
- inflate.c/h, inftrees.c/h, inffast.c/h, inffixed.h

**Checksum:**
- adler32.c, crc32.c/h

**Utilities:**
- zutil.c/h, zconf.h, zlib.h

**Minizip:**
- unzip.c/h, ioapi.c/h, iowin32.c/h, crypt.h

### Preprocessor Defines

- `NOCRYPT` - Disabilita supporto ZIP criptati
- `Z_SOLO` - Disabilita funzioni gzip (riduce dipendenze)

---

## Progetti Visual Studio

### Visual Studio 2022 (v143)
- File: `Source/nsisunz.vcxproj`
- Script: `build_plugin.py`
- Toolset: v143
- Percorso: `C:\Program Files\Microsoft Visual Studio\2022\`

### Visual Studio 2026 (v145)
- File: `Source/nsisunz_vs2026.vcxproj`
- Script: `build_plugin_vs2026.py`
- Toolset: v145
- Percorso: `C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools`

### Configurazioni supportate

| Config | Configurazione VS | Piattaforma | Output |
|--------|-------------------|-------------|--------|
| x86-ansi | Release | Win32 | nsisunz.dll |
| x86-unicode | Release Unicode | Win32 | nsisunz.dll |
| x64-unicode | Release Unicode | x64 | nsisunz.dll |

---

## Credits e Licenza

**Credits:**
- Originale: Saivert (http://saivert.com/)
- Unicode support: Gringoloco023, 2010
- Miglioramenti: past-due, 2018+
- zlib 1.3.1 update: 2025

**Basato su:**
- NSIS Zip2Exe - Copyright © 1999-2001 Miguel Garrido
- [ZLIB](https://zlib.net) - Copyright © Mark Adler
- MiniZip - Copyright © 1998-2010 Gilles Vollant

**Licenza:** [zlib License](https://en.wikipedia.org/wiki/Zlib_License)

---

## Documentazione

- **[BUILD_INFO.md](BUILD_INFO.md)** - Guida completa compilazione VS2022/VS2026
- **[CHANGES.md](CHANGES.md)** - Changelog dettagliato zlib 1.1.3 → 1.3.1
- **[COMPARISON_nsUnz_vs_nsUnz-zlib1.3.md](../COMPARISON_nsUnz_vs_nsUnz-zlib1.3.md)** - Confronto con versione originale

---

*Aggiornato: Dicembre 2025*
