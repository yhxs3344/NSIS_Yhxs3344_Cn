# nsisunz - Informazioni di Build

## ⚠️ Nota importante

**Visual Studio 2026 Build Tools - Toolset v145**

Visual Studio 2026 Build Tools (versione 18.x) utilizza il **Platform Toolset v145**.

### Percorsi di installazione

VS2026 Build Tools installato con Chocolatey si trova in:
- `C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools`

### Toolset

- **VS2022**: v143
- **VS2026**: v145

---

## File di progetto disponibili

Questo plugin supporta due versioni di Visual Studio:

### Visual Studio 2022 (v143)
- **File progetto**: `Source/nsisunz.vcxproj`
- **Script build**: `build_plugin.py`
- **Platform Toolset**: v143
- **Percorso VS**: `C:\Program Files\Microsoft Visual Studio\2022\`

### Visual Studio 2026 (v145)
- **File progetto**: `Source/nsisunz_vs2026.vcxproj`
- **Script build**: `build_plugin_vs2026.py`
- **Platform Toolset**: v145
- **Percorso VS**: `C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools`

## Compilazione

### Con Visual Studio 2022

#### Metodo 1: Script Python
```cmd
cd nsUnz-zlib1.3
python build_plugin.py
```

#### Metodo 2: Visual Studio IDE
1. Apri `Source\nsisunz.vcxproj` in Visual Studio 2022
2. Seleziona la configurazione (Release, Release Unicode)
3. Seleziona la piattaforma (Win32, x64)
4. Build → Rebuild Solution

#### Metodo 3: MSBuild diretto
```cmd
cd nsUnz-zlib1.3\Source
msbuild nsisunz.vcxproj /p:Configuration="Release Unicode" /p:Platform=Win32
msbuild nsisunz.vcxproj /p:Configuration="Release Unicode" /p:Platform=x64
msbuild nsisunz.vcxproj /p:Configuration=Release /p:Platform=Win32
```

### Visual Studio 2026 (FUNZIONANTE)

#### Metodo 1: Script Python
```cmd
cd nsUnz-zlib1.3
python build_plugin_vs2026.py
```

#### Metodo 2: Visual Studio IDE
1. Apri `Source\nsisunz_vs2026.vcxproj` in Visual Studio 2026
2. Seleziona la configurazione (Release, Release Unicode)
3. Seleziona la piattaforma (Win32, x64)
4. Build → Rebuild Solution

#### Metodo 3: MSBuild diretto
```cmd
cd nsUnz-zlib1.3\Source
msbuild nsisunz_vs2026.vcxproj /p:Configuration="Release Unicode" /p:Platform=Win32
msbuild nsisunz_vs2026.vcxproj /p:Configuration="Release Unicode" /p:Platform=x64
msbuild nsisunz_vs2026.vcxproj /p:Configuration=Release /p:Platform=Win32
```

## Configurazioni Build

Entrambi i progetti supportano le stesse configurazioni:

| Nome Config | Configurazione VS | Piattaforma | Output | Destinazione Plugin |
|-------------|-------------------|-------------|--------|---------------------|
| x86-ansi | Release | Win32 | nsisunz.dll | plugins/x86-ansi/ |
| x86-unicode | Release Unicode | Win32 | nsisunz.dll | plugins/x86-unicode/ |
| x64-unicode | Release Unicode | x64 | nsisunz.dll | plugins/amd64-unicode/ |

## Opzioni Script Python

Entrambi gli script supportano le stesse opzioni:

```cmd
# Compila tutte le configurazioni
python build_plugin.py

# Compila solo configurazioni specifiche
python build_plugin.py --configs x86-unicode x64-unicode

# Build incrementale (no rebuild)
python build_plugin.py --no-rebuild

# Build single-thread (no parallel)
python build_plugin.py --no-parallel

# Aumenta verbosità
python build_plugin.py --verbosity minimal

# Non pulire file intermedi
python build_plugin.py --no-clean

# Lista configurazioni disponibili
python build_plugin.py --list

# Pausa alla fine
python build_plugin.py --pause

# Benchmark prestazioni
python build_plugin.py --benchmark --configs x86-unicode
```

## Differenze tra VS2022 e VS2026

### Platform Toolset
- **VS2022**: v143
- **VS2026**: v145 (versione 18.x Build Tools)

### Percorso installazione
- **VS2022**: `C:\Program Files\Microsoft Visual Studio\2022\`
- **VS2026 Build Tools**: `C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools`

### Compatibilità
Entrambe le versioni producono DLL binari compatibili con NSIS. La differenza principale è nel compilatore e nell'ottimizzatore utilizzato.

### Quando usare quale versione?

**Usa VS2022** se:
- È la tua versione corrente di Visual Studio
- Vuoi stabilità e compatibilità provata
- Stai lavorando in un ambiente di produzione

**Usa VS2026** se:
- Hai installato VS2026 Build Tools (choco install visualstudio2026buildtools)
- Vuoi utilizzare il toolset v145
- Vuoi testare il compilatore più recente

## Output

Dopo la compilazione, i DLL vengono copiati in:
```
Launchers/plugins/
├── x86-ansi/nsisunz.dll
├── x86-unicode/nsisunz.dll
└── amd64-unicode/nsisunz.dll
```

## Preprocessor Defines

Entrambi i progetti utilizzano:
- `NOCRYPT` - Disabilita supporto ZIP criptati
- `Z_SOLO` - Disabilita funzioni gzip (riduce dipendenze)

## Requisiti

### Per Visual Studio 2022
- Visual Studio 2022 (Community/Professional/Enterprise)
- Windows SDK 10.0
- Desktop development with C++ workload
- Python 3.6+ (opzionale, per script build)

### Per Visual Studio 2026
- Visual Studio 2026 Build Tools (Community/Professional/Enterprise)
  ```cmd
  choco install visualstudio2026buildtools
  ```
- Windows SDK 10.0
- Desktop development with C++ workload
- Python 3.6+ (opzionale, per script build)

## Troubleshooting

### MSBuild non trovato
Assicurati che Visual Studio sia installato con il workload "Desktop development with C++".

### Errore Platform Toolset
Se vedi errori sul toolset, verifica che la versione corretta di Visual Studio sia installata:
- v143 richiede VS2022
- v145 richiede VS2026 Build Tools (versione 18.x)

### Errore Z_SOLO / gzguts.h
Questo è già risolto nei progetti. Se vedi questo errore, assicurati che `Z_SOLO` sia definito nei preprocessor defines.

## Note

- Visual Studio 2026 Build Tools (versione 18.x) usa il toolset **v145**
- Installabile con Chocolatey: `choco install visualstudio2026buildtools`
- Il percorso di installazione è `C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools`
- Entrambi gli script (VS2022 e VS2026) sono completamente funzionanti

---
Aggiornato: Dicembre 2025
