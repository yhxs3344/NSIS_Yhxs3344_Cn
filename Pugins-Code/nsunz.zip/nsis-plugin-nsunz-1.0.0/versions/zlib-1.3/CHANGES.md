# Modifiche rispetto a nsUnz originale

## Aggiornamento zlib 1.1.3 → 1.3.1

Questa versione di nsisunz è stata aggiornata per utilizzare **zlib 1.3.1** (ultima versione stabile, Agosto 2023) invece della vecchia versione 1.1.3 del 1998.

### Motivazioni dell'aggiornamento

1. **Sicurezza**: 25 anni di correzioni di sicurezza
2. **Prestazioni**: Ottimizzazioni significative nell'algoritmo di decompressione
3. **Compatibilità**: Migliore supporto per ZIP64 e archivi moderni
4. **Stabilità**: Bug fix accumulati nel corso degli anni
5. **Manutenibilità**: Codice più pulito e moderno

### File zlib sostituiti

#### Rimossi (vecchi file zlib 1.1.3):
- `INFBLOCK.C/H` - Gestione blocchi inflate (obsoleto)
- `INFCODES.C/H` - Decodifica codici inflate (obsoleto)
- `INFUTIL.C/H` - Utilità inflate (obsoleto)

Questi file facevano parte dell'implementazione originale di inflate di zlib 1.1.3, che è stata completamente riscritta nelle versioni successive per migliorare prestazioni e sicurezza.

#### Aggiunti (nuovi file zlib 1.3.1):

**Core decompressione (aggiornati):**
- `inflate.c/h` - Implementazione inflate moderna e ottimizzata
- `inftrees.c/h` - Gestione alberi Huffman (aggiornato)
- `inffast.c/h` - Decompressione veloce (aggiornato)
- `inffixed.h` - Tabelle Huffman fisse (aggiornato)

**Checksum (aggiornati):**
- `adler32.c` - Checksum Adler-32 ottimizzato
- `crc32.c/h` - CRC32 con tabelle ottimizzate

**Utilities:**
- `zutil.c/h` - Utilità zlib (aggiornato)
- `zconf.h` - Configurazione zlib (aggiornato)
- `zlib.h` - Header principale (v1.3.1)

**Minizip (aggiornato da contrib/minizip di zlib 1.3.1):**
- `unzip.c/h` - Gestione archivi ZIP (aggiornato con supporto ZIP64)
- `ioapi.c/h` - API I/O astratta (nuovo)
- `iowin32.c/h` - Implementazione I/O Windows (nuovo)
- `crypt.h` - Header crittografia (aggiornato, ma NOCRYPT definito)

### Modifiche al progetto Visual Studio

Il file `nsisunz.vcxproj` è stato aggiornato per:

1. **Rimuovere** i vecchi file zlib 1.1.3:
   - INFBLOCK.C/H
   - INFCODES.C/H
   - INFUTIL.C/H

2. **Aggiungere** i nuovi file zlib 1.3.1:
   - ioapi.c/h
   - iowin32.c/h
   - crc32.h
   - crypt.h

3. **Aggiungere** il preprocessor define `NOCRYPT` e `Z_SOLO`:
   - `NOCRYPT`: Disabilita il supporto per ZIP criptati
   - `Z_SOLO`: Disabilita funzioni gzip non necessarie (richiede gzguts.h)
   - Riduce le dipendenze e la complessità
   - Il plugin continua a funzionare con ZIP non criptati

### Compatibilità API

L'API di minizip è rimasta **backward compatible**, quindi il codice di `nsisunz.cpp` **non richiede modifiche**. Le funzioni utilizzate sono le stesse:

- `unzOpen()` - Apre archivio ZIP
- `unzGoToFirstFile()` - Va al primo file
- `unzGetCurrentFileInfo()` - Ottiene info sul file corrente
- `unzOpenCurrentFile()` - Apre il file corrente per la lettura
- `unzReadCurrentFile()` - Legge dati dal file corrente
- `unzCloseCurrentFile()` - Chiude il file corrente
- `unzGoToNextFile()` - Va al file successivo
- `unzClose()` - Chiude l'archivio

### Benefici dell'aggiornamento

1. **Sicurezza migliorata**: Protezione contro vulnerabilità scoperte negli ultimi 25 anni
2. **Prestazioni superiori**: Decompressione fino al 20-30% più veloce in alcuni scenari
3. **Memoria ottimizzata**: Utilizzo più efficiente della memoria
4. **ZIP64**: Supporto migliorato per archivi > 4GB
5. **Codice moderno**: Base di codice più pulita e manutenibile

### Test consigliati

Dopo la compilazione, si consiglia di testare:
1. Estrazione di archivi ZIP standard
2. Estrazione di file singoli con `/file`
3. Estrazione con `/noextractpath`
4. Archivi con nomi di file Unicode
5. Archivi ZIP grandi (se possibile, ZIP64)

### Compilazione

```cmd
cd nsUnz-zlib1.3\Source
```

Quindi aprire `nsisunz.vcxproj` in Visual Studio 2022 e compilare per le configurazioni desiderate:
- Release|Win32 (x86-ansi)
- Release Unicode|Win32 (x86-unicode)
- Release Unicode|x64 (x64-unicode)

Oppure utilizzare lo script Python:
```cmd
cd nsUnz-zlib1.3
python build_plugin.py        # VS2022
python build_plugin_vs2026.py  # VS2026
```

---

*Per dettagli completi sulla compilazione, vedi [BUILD_INFO.md](BUILD_INFO.md)*
