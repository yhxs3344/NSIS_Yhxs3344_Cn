# nsisunz NSIS Plugin

**Versione personale modificata**

Basato su [past-due/nsisunz](https://github.com/past-due/nsisunz) - un plugin NSIS per estrarre file da archivi ZIP.

---

## Descrizione Originale

**nsisunz** è un plugin [NSIS](https://en.wikipedia.org/wiki/Nullsoft_Scriptable_Install_System) che permette di estrarre file da archivi ZIP.

> **nsisunz** è ideale quando si usa un altro plugin NSIS chiamato _NSISdl_ per scaricare un file ZIP da internet. Si può creare un piccolo installer che permette all'utente di scegliere i componenti da installare e l'installer li scarica.

### Origini e Storia

- _nsisunz_ è stato originariamente scritto da Saivert (http://saivert.com/)
- Supporto NSIS Unicode [aggiunto da Gringoloco023](http://portableapps.com/node/21879), Febbraio 2010
- Ulteriori miglioramenti di past-due, 2018+:
  - Aggiornamento NSIS plugin API a 3.0
  - Aggiornamento [zlib](https://zlib.net) a [1.2.11](https://zlib.net/ChangeLog.txt)
  - Aggiornamento Minizip a 1.1-8
  - Supporto build [CMake](https://cmake.org) (compila sia DLL ANSI che Unicode)

## Funzioni

### UnzipToLog

Estrae i file e mostra il log dettagliato:

```nsis
InitPluginsDir
; Chiama il plugin. Prima il file ZIP, poi la cartella di destinazione.
nsisunz::UnzipToLog "$PLUGINSDIR\myzipfile.zip" "$INSTDIR"

; Controlla sempre il risultato sullo stack
Pop $0
StrCmp $0 "success" ok
DetailPrint "$0" ; stampa messaggio di errore nel log
ok:
```

### Unzip

Estrazione veloce senza log (preferita per archivi grandi):

```nsis
nsisunz::Unzip "$PLUGINSDIR\myzipfile.zip" "$INSTDIR"
```

## Credits

- Basato sul codice di NSIS Zip2Exe - porzioni Copyright © 1999-2001 Miguel Garrido (mgarrido01@hotmail.com)
- [ZLIB](https://zlib.net) - Copyright © Mark Adler
- MiniZip - Copyright © 1998-2010 - di Gilles Vollant - versione 1.1 64 bits di Mathias Svensson

## Licenza

Le condizioni di uso e distribuzione sono le stesse di [zlib](https://en.wikipedia.org/wiki/Zlib_License).

---

## ⚠️ Differenze nella versione personale

Questa versione è basata su [past-due/nsisunz](https://github.com/past-due/nsisunz) con le seguenti modifiche:

### Nuova architettura supportata: x64 (amd64-unicode)

L'originale supporta:
- x86-ansi
- x86-unicode

La versione personale aggiunge il supporto per:
- **amd64-unicode** (x64)

### Progetto Visual Studio

L'originale usa CMake per la compilazione. La versione personale include progetti Visual Studio:
- `Source/nsisunz.vcproj` - Progetto VS2008 (legacy)
- `Source/nsisunz.vcxproj` - Progetto VS2022 (x86-ansi, x86-unicode, amd64-unicode)

### File modificati/semplificati

La versione personale usa una versione più vecchia e semplificata di zlib:
- `Source/zlib/` - Libreria zlib semplificata (solo file essenziali per decompressione)

Rispetto all'originale GitHub che include:
- CMakeLists.txt e configurazione CMake completa
- zlib 1.2.11 completa con tutti i contributi (285 file)
- Minizip completo
- Configurazione CI/CD (.github, appveyor)

### File aggiunti

- `build_plugin.py` - Script Python per compilare il plugin per tutte le architetture
- `Doc/` - Documentazione (info.rtf, nsisunz_readme.html)
- `ExDLL/exdll.h` - Header per l'API NSIS extern DLL

### Compilazione

```cmd
cd nsUnz
python build_plugin.py
```

I DLL vengono copiati in `plugins/{platform}/nsisunz.dll`.
