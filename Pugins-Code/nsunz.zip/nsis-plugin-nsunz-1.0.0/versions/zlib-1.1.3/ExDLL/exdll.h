#ifndef _EXDLL_H_
#define _EXDLL_H_

#include <windows.h>
#include <tchar.h>

#if defined(__GNUC__)
#define UNUSED __attribute__((unused))
#else
#define UNUSED
#endif

// only include this file from one place in your DLL.
// (it is all static, if you use it in two places it will fail)

typedef struct _stack_t
{
  struct _stack_t *next;
  TCHAR text[1]; // this should be the length of string_size
} stack_t;

// Global variables (must be declared where you include this header)
static unsigned int g_stringsize;
static stack_t **g_stacktop;
static TCHAR *g_variables;

#define EXDLL_INIT()            \
  {                             \
    g_stringsize = string_size; \
    g_stacktop = stacktop;      \
    g_variables = variables;    \
  }

enum
{
  INST_0,       // $0
  INST_1,       // $1
  INST_2,       // $2
  INST_3,       // $3
  INST_4,       // $4
  INST_5,       // $5
  INST_6,       // $6
  INST_7,       // $7
  INST_8,       // $8
  INST_9,       // $9
  INST_R0,      // $R0
  INST_R1,      // $R1
  INST_R2,      // $R2
  INST_R3,      // $R3
  INST_R4,      // $R4
  INST_R5,      // $R5
  INST_R6,      // $R6
  INST_R7,      // $R7
  INST_R8,      // $R8
  INST_R9,      // $R9
  INST_CMDLINE, // $CMDLINE
  INST_INSTDIR, // $INSTDIR
  INST_OUTDIR,  // $OUTDIR
  INST_EXEDIR,  // $EXEDIR
  INST_LANG,    // $LANGUAGE
  __INST_LAST
};

// utility functions (not required but often useful)
static int UNUSED popstring(TCHAR *str)
{
  stack_t *th;
  if (!g_stacktop || !*g_stacktop)
    return 1;
  th = (*g_stacktop);
  lstrcpyn(str, th->text, (int)g_stringsize);
  *g_stacktop = th->next;
  GlobalFree((HGLOBAL)th);
  return 0;
}

static void UNUSED pushstring(const TCHAR *str)
{
  stack_t *th;
  if (!g_stacktop)
    return;
  th = (stack_t *)GlobalAlloc(GPTR, (sizeof(stack_t) + (g_stringsize) * sizeof(TCHAR)));
  lstrcpyn(th->text, str, (int)g_stringsize);
  th->next = *g_stacktop;
  *g_stacktop = th;
}

static TCHAR *UNUSED getuservariable(const int varnum)
{
  if (varnum < 0 || varnum >= __INST_LAST)
    return NULL;
  return g_variables + varnum * g_stringsize;
}

static void UNUSED setuservariable(const int varnum, const TCHAR *var)
{
  if (var != NULL && varnum >= 0 && varnum < __INST_LAST)
    lstrcpy(g_variables + varnum * g_stringsize, var);
}

#endif //_EXDLL_H_
