#!/usr/bin/env python3
"""Build script for nsisunz NSIS plugin.

Wraps per-version/per-toolset build scripts.
Defaults: zlib 1.3, VS2026 (v145 toolset)
"""
from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path


class Colors:
    CYAN = "\033[36m";  GREEN = "\033[32m";  YELLOW = "\033[33m"
    RED = "\033[31m";   GRAY = "\033[90m";   RESET = "\033[0m"
    BOLD = "\033[1m";   BRIGHT_CYAN = "\033[96m"


ROOT = Path(__file__).resolve().parent
SCRIPTS = {
    "1.1.3": {"2022": "tools/legacy/build_plugin_zlib113_vs2022.py",
               "2026": "tools/legacy/build_plugin_zlib113_vs2026.py"},
    "1.3":   {"2022": "tools/legacy/build_plugin_zlib13_vs2022.py",
               "2026": "tools/legacy/build_plugin_zlib13_vs2026.py"},
}


def main() -> int:
    parser = argparse.ArgumentParser(description="Build nsisunz NSIS plugin")
    parser.add_argument("--zlib-version", choices=["1.1.3", "1.3"], default="1.3",
                        help="zlib version to use (default: 1.3)")
    parser.add_argument("--toolset", choices=["2022", "2026", "auto"], default="auto",
                        help="Visual Studio toolset version (default: auto)")
    parser.add_argument("--version", action="store_true",
                        help="Print plugin version and exit")
    known, rest = parser.parse_known_args()

    if known.version:
        print((ROOT / "VERSION").read_text(encoding="utf-8-sig").strip())
        return 0

    ver = (ROOT / "VERSION").read_text(encoding="utf-8-sig").strip()
    print(f"{Colors.BOLD}{Colors.BRIGHT_CYAN}=== Building nsUnz v{ver} "
          f"(zlib {known.zlib_version}) ==={Colors.RESET}")

    toolset = known.toolset
    if toolset == "auto":
        toolset = "2026"

    script = ROOT / SCRIPTS[known.zlib_version][toolset]
    return subprocess.run([sys.executable, str(script)] + rest).returncode


if __name__ == "__main__":
    sys.exit(main())
