# UikoEngine
UikoEngine - NSIS UI Library

UikoEngine是基于DuiLib封装的一个NSIS界面库，可用于NSIS安装卸载过程的美化。
功能：
- xml书写界面，具体参考DuiLib;
- 全功能，可以模仿QQ安装包;

Example: doc/dui.nsi

NSIS开源控件交流群(127576804)，欢迎大家加入。