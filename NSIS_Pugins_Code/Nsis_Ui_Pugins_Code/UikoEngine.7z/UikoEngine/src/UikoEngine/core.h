
/*  CCore��ʼ��;
 *  Init();
 */
void _declspec(dllexport) Init( int type = 1 );
