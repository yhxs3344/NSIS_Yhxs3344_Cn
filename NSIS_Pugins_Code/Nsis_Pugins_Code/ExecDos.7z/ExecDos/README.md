# ExecDos ([NSIS](https://github.com/negrutiu/nsis) plugin)
It allows you to execute console programs and grab their output

#
This is a clone of the original project created by **Takhir Bedertdinov** and **Stuart 'Afrow UK' Welch**<br>
https://nsis.sourceforge.io/ExecDos_plug-in
