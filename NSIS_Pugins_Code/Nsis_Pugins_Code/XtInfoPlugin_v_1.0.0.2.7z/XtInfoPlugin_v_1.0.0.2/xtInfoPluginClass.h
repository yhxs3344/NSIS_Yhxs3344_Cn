// ==================================================================================
// NSIS xtInfoPlugin 1.2.1, Main Class
// Copyright 2004 Jari Berg Jensen. All Rights Reserved.
//
// DISCLAIMER
// Please feel free to do anything with the code as long as the copyright message above
// and this disclaimer is present in the file.
// ALL USE OF THIS CODE IS AT YOUR OWN RISK
// ==================================================================================

#include "C:/Program Files/NSIS/Contrib/ExDLL/exdll.h"
//#include "C:/Program Files/NSIS/Source/exehead/resource.h"

#pragma once

#ifndef __AFXWIN_H__
	//#error include 'stdafx.h' before including this file for PCH
#endif

// ==================================================================================
// CxtInfoPlugin Class
// ==================================================================================
class CxtInfoPlugin
{
public:
	CxtInfoPlugin();
	virtual ~CxtInfoPlugin();

public:
	int CompareVersion(CString v1, CString v2);
	void Execute(CString filename, CString commandLine, CString workingDirectory);
	CString GetInstaller();
	CString GetInstallerFileName();
	CString GetInstallerFullPath();
	CString GetInstallerRealPath(const char *filename);
	BOOL FileExists(const char *filename);
	BOOL CheckRegKey(HKEY hKey, const char *subKey);
	void SetRegValue(HKEY hKey, const char *subKey, const char *valueName, const char *valueData);
	CString QueryRegValue(HKEY hKey, const char *subKey, const char *valueName);
	CString QueryIniValue(const char *filename, const char *section, const char *key);
	CString GetFileVersion(const char *filename, int &major, int &minor, int &build, int &revision);
	CString GetLanguage();
	CString GetWindowsVersion();
	CString GetWindowsId();
	CString GetWindowsServicePackId();
	CString GetInternetExplorerVersion();
	CString GetInternetExplorerId();
	CString GetMDACVersion();
	CString GetMDACId();
	CString GetOLEDBVersion();
	CString GetOLEDBId();
	CString GetDotNetFrameworkVersion();
	CString GetDotNetFrameworkId();

	BOOL GetIdResult(CString function, CString result);
		
	BOOL IsWindowsNT3() {return GetIdResult("windows", "nt3");}
	BOOL IsWindowsNT4() {return GetIdResult("windows", "nt4");}
	BOOL IsWindows95() {return GetIdResult("windows", "95");}
	BOOL IsWindows98() {return GetIdResult("windows", "98");}
	BOOL IsWindowsME() {return GetIdResult("windows", "me");}
	BOOL IsWindowsXP() {return GetIdResult("windows", "xp");}
	BOOL IsWindows2000() {return GetIdResult("windows", "2000");}
	BOOL IsWindows2003() {return GetIdResult("windows", "2003");}
	
	BOOL IsDotNetFrameworkInstalled();
	BOOL IsAdministrator();
	
private:
	CString windowsId;

};