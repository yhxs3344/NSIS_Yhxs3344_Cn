// ==================================================================================
// NSIS xtInfoPlugin 1.2.1, Exporting Methods
// Copyright 2004 Jari Berg Jensen. All Rights Reserved.
//
// DISCLAIMER
// Please feel free to do anything with the code as long as the copyright message above
// and this disclaimer is present in the file.
// ALL USE OF THIS CODE IS AT YOUR OWN RISK
// ==================================================================================

#include "stdafx.h"
CxtInfoPlugin *xtInfoPlugin = new CxtInfoPlugin();

// ==================================================================================
// Compare Versions
// ==================================================================================
extern "C" void __declspec(dllexport) CompareVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	char v1[256];
	char v2[256];
	popstring(v2);
	popstring(v1);
	CString result;
	result.Format("%d", xtInfoPlugin->CompareVersion(v1, v2));
	pushstring(result.GetBuffer());
	//result.Format("%s\r\n%s", v1, v2);
	//MessageBox(NULL, s, "", MB_OK);
}

// ==================================================================================
// Get Installer (the filename, ie 'Setup.exe')
// ==================================================================================
extern "C" void __declspec(dllexport) GetInstaller(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetInstaller().GetBuffer());
}

// ==================================================================================
// Get Installer Full Path
// ==================================================================================
extern "C" void __declspec(dllexport) GetInstallerFullPath(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetInstallerFullPath().GetBuffer());
}

// ==================================================================================
// Get Installer File Name
// ==================================================================================
extern "C" void __declspec(dllexport) GetInstallerFileName(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetInstallerFileName().GetBuffer());
}

// ==================================================================================
// Get Windows Language
// ==================================================================================
extern "C" void __declspec(dllexport) GetLanguage(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetLanguage().GetBuffer());
}

// ==================================================================================
// Get Windows Version
// ==================================================================================
extern "C" void __declspec(dllexport) GetWindowsVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetWindowsVersion().GetBuffer());
}

// ==================================================================================
// Get Windows Id
// ==================================================================================
extern "C" void __declspec(dllexport) GetWindowsId(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetWindowsId().GetBuffer());
}

// ==================================================================================
// Get Windows Service Pack Id
// ==================================================================================
extern "C" void __declspec(dllexport) GetWindowsServicePackId(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetWindowsServicePackId().GetBuffer());
}

// ==================================================================================
// Get Internet Explorer Version
// ==================================================================================
extern "C" void __declspec(dllexport) GetInternetExplorerVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetInternetExplorerVersion().GetBuffer());
}

// ==================================================================================
// Get Internet Explorer Id
// ==================================================================================
extern "C" void __declspec(dllexport) GetInternetExplorerId(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetInternetExplorerId().GetBuffer());
}

// ==================================================================================
// Get Microsoft Data Access Components (MDAC) and ADO Version
// ==================================================================================
extern "C" void __declspec(dllexport) GetMDACVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetMDACVersion().GetBuffer());
}

// ==================================================================================
// Get Microsoft Data Access Components (MDAC) and ADO Id
// ==================================================================================
extern "C" void __declspec(dllexport) GetMDACId(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetMDACId().GetBuffer());
}


// ==================================================================================
// Get OLE DB Jet Version
// ==================================================================================
extern "C" void __declspec(dllexport) GetOLEDBVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetOLEDBVersion().GetBuffer());
}

// ==================================================================================
// Get OLE DB Jet Id
// ==================================================================================
extern "C" void __declspec(dllexport) GetOLEDBId(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetOLEDBId().GetBuffer());
}

// ==================================================================================
// Get .NET Framework Version
// ==================================================================================
extern "C" void __declspec(dllexport) GetDotNetFrameworkVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetDotNetFrameworkVersion().GetBuffer());
}

// ==================================================================================
// Get .NET Framework Id
// ==================================================================================
extern "C" void __declspec(dllexport) GetDotNetFrameworkId(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(xtInfoPlugin->GetDotNetFrameworkId().GetBuffer());
}

// ==================================================================================
// Get Id Result (true or false)
// ==================================================================================
char *GetIdResult(BOOL result)
{
	CString str(result == TRUE ? "true" : "false");
	return str.GetBuffer();
}

// ==================================================================================
// Is Windows Id ?
// ==================================================================================
extern "C" void __declspec(dllexport) IsWindowsNT3(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {EXDLL_INIT(); pushstring(GetIdResult(xtInfoPlugin->IsWindowsNT3()));}
extern "C" void __declspec(dllexport) IsWindowsNT4(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {EXDLL_INIT(); pushstring(GetIdResult(xtInfoPlugin->IsWindowsNT4()));}
extern "C" void __declspec(dllexport) IsWindows95(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {EXDLL_INIT(); pushstring(GetIdResult(xtInfoPlugin->IsWindows95()));}
extern "C" void __declspec(dllexport) IsWindows98(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {EXDLL_INIT(); pushstring(GetIdResult(xtInfoPlugin->IsWindows98()));}
extern "C" void __declspec(dllexport) IsWindowsME(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {EXDLL_INIT(); pushstring(GetIdResult(xtInfoPlugin->IsWindowsME()));}
extern "C" void __declspec(dllexport) IsWindowsXP(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {EXDLL_INIT(); pushstring(GetIdResult(xtInfoPlugin->IsWindowsXP()));}
extern "C" void __declspec(dllexport) IsWindows2000(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {EXDLL_INIT(); pushstring(GetIdResult(xtInfoPlugin->IsWindows2000()));}
extern "C" void __declspec(dllexport) IsWindows2003(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {EXDLL_INIT(); pushstring(GetIdResult(xtInfoPlugin->IsWindows2003()));}

// ==================================================================================
// Is .NET Framework Installed ?
// ==================================================================================
extern "C" void __declspec(dllexport) IsDotNetFrameworkInstalled(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(GetIdResult(xtInfoPlugin->IsDotNetFrameworkInstalled()));
}

// ==================================================================================
// Is User Administrator / Has Administrator Privilege
// ==================================================================================
extern "C" void __declspec(dllexport) IsAdministrator(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	pushstring(GetIdResult(xtInfoPlugin->IsAdministrator()));
}
