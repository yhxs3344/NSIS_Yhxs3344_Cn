// xtInfoPluginApp.h : main header file for the xtInfoPlugin DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// CxtInfoPluginApp
// See xtInfoPlugin.cpp for the implementation of this class
//

class CxtInfoPluginApp : public CWinApp
{
public:
	CxtInfoPluginApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};

HINSTANCE hInstance;


