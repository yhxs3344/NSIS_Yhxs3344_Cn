// ==================================================================================
// NSIS xtInfoPlugin 1.2.1, Main Class
// Copyright 2004 Jari Berg Jensen. All Rights Reserved.
//
// DISCLAIMER
// Please feel free to do anything with the code as long as the copyright message above
// and this disclaimer is present in the file.
// ALL USE OF THIS CODE IS AT YOUR OWN RISK
// ==================================================================================

#include "stdafx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define MAXBUFLEN 2048

// ==================================================================================
// Constructor
// ==================================================================================
CxtInfoPlugin::CxtInfoPlugin()
{
	windowsId.Empty();
}

// ==================================================================================
// Destructor
// ==================================================================================
CxtInfoPlugin::~CxtInfoPlugin()
{
}

// ==================================================================================
// Compare Versions
// ==================================================================================
int CxtInfoPlugin::CompareVersion(CString v1, CString v2)
{
	// ie. CompareVersion("2.50.4403.9", "2.50.4403.9") would return 0  (a == b)
	// ie. CompareVersion("2.50.4403.9", "2.71.9030.0") would return 1  (b > a)
	// ie. CompareVersion("2.71.9030.0", "2.50.4403.9") would return -1 (a > b)
	return v2.Compare(v1);
}

// ==================================================================================
// Execute Application
// ==================================================================================
void CxtInfoPlugin::Execute(CString filename, CString commandLine, CString workingDirectory)
{
	PROCESS_INFORMATION processInfo;
	STARTUPINFO startupInfo;

	ZeroMemory(&startupInfo, sizeof(startupInfo));
	startupInfo.cb = sizeof(startupInfo);

	//CreateProcess(
	if (CreateProcess(filename, commandLine.GetBuffer(), NULL, NULL, FALSE, 0, NULL, workingDirectory, &startupInfo, &processInfo))
	if (processInfo.hProcess)
	{
		DWORD status = WaitForSingleObject(processInfo.hProcess, INFINITE);
		if (processInfo.hThread)
			CloseHandle(processInfo.hThread);
		if (processInfo.hProcess)
			CloseHandle(processInfo.hProcess);
	}
}

// ==================================================================================
// Get Installer (the filename, ie 'Setup.exe')
// ==================================================================================
CString CxtInfoPlugin::GetInstaller()
{
	CString file(this->GetInstallerFileName());
	file.Replace(this->GetInstallerFullPath(), "");
	file.Replace("/", "\\");
	file.Replace("\\", "");
	file.Replace("\"", "");
	file.Replace("'", "");
	file.Trim();
	return file;
}

// ==================================================================================
// Get Installer File Name
// ==================================================================================
CString CxtInfoPlugin::GetInstallerFileName()
{
	char *fileName = new char[MAXBUFLEN];
	GetModuleFileName(GetModuleHandle(NULL), fileName, MAXBUFLEN);
	CString file(fileName);
	file.Trim();
	file.Replace("/", "\\");
	file.Replace("\\\\", "");
	file.Replace("\"", "");
	file.Replace("'", "");
	file.Trim();
	return file;
}

// ==================================================================================
// Get Installer Full Path
// ==================================================================================
CString CxtInfoPlugin::GetInstallerFullPath()
{
	char *fileName = new char[MAXBUFLEN];
	char *pathName = new char[MAXBUFLEN];
	char *filePart = new char[MAXBUFLEN];
	GetModuleFileName(GetModuleHandle(NULL), fileName, MAXBUFLEN);
	GetFullPathName(fileName, MAXBUFLEN, pathName, &filePart);
	CString path(pathName);
	path.Trim();
	path.Replace(filePart, "\\");
	path.Replace("/", "\\");
	path.Replace("\\\\", "");
	path.Replace("\"", "");
	path.Replace("'", "");
	path.Trim();
	return path;
}

// ==================================================================================
// Return Application Real Path
// ==================================================================================
CString CxtInfoPlugin::GetInstallerRealPath(const char *filename)
{
	CString path(this->GetInstallerFullPath());
	path.Append("\\");
	path.Append(filename);
	return path;
}

// ==================================================================================
// Check if file exists
// ==================================================================================
BOOL CxtInfoPlugin::FileExists(const char *filename)
{
	return (GetFileAttributes(filename) != INVALID_FILE_ATTRIBUTES) ? TRUE : FALSE;
}

// ==================================================================================
// Check if Registry Key is valid
// ==================================================================================
BOOL CxtInfoPlugin::CheckRegKey(HKEY hKey, const char *subKey)
{
 	HKEY key;
	LONG result = RegOpenKeyEx(hKey, subKey, 0, KEY_READ, &key);
	if (result == ERROR_SUCCESS)
	{
		RegCloseKey(key);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// ==================================================================================
// Set Registry Value
// ==================================================================================
void CxtInfoPlugin::SetRegValue(HKEY hKey, const char *subKey, const char *valueName, const char *valueData)
{
	DWORD bufLen = MAXBUFLEN;
	char data[MAXBUFLEN];
	
	sprintf(data, "%s", valueData);
	
 	HKEY key;
	LONG result = RegOpenKeyEx(hKey, subKey, 0, KEY_WRITE, &key);
	if (result == ERROR_SUCCESS)
	{
		RegSetValueEx(key, valueName, 0, REG_SZ, (BYTE*) data, lstrlen(data));
		RegCloseKey(key);
	}
	else
	{
	}
}

// ==================================================================================
// Query Registry Value
// ==================================================================================
CString CxtInfoPlugin::QueryRegValue(HKEY hKey, const char *subKey, const char *valueName)
{
	DWORD bufLen = MAXBUFLEN;
	char buf[MAXBUFLEN];
	char data[MAXBUFLEN];
 	HKEY key;
	LONG result = RegOpenKeyEx(hKey, subKey, 0, KEY_READ, &key);
	if (result == ERROR_SUCCESS)
	{
		RegQueryValueEx(key, valueName, NULL, NULL, (BYTE*) &buf, &bufLen);
		RegCloseKey(key);
		sprintf(data, "%s", buf);
	}
	else
	{
		sprintf(data, "");
	}

	CString str(data);
	return str;
}

// ==================================================================================
// Query Ini Value
// ==================================================================================
CString CxtInfoPlugin::QueryIniValue(const char *filename, const char *section, const char *key)
{
	CString str("");
	str.Empty();
	char buf[MAXBUFLEN];
	GetPrivateProfileString(section, key, "", buf, sizeof(buf), filename);
	str.Append(buf);
	return str;
}

// ==================================================================================
// Get File Version
// ==================================================================================
CString CxtInfoPlugin::GetFileVersion(const char *filename, int &major, int &minor, int &build, int &revision)
{
	DWORD vSize;
	DWORD vLen,langD;
	BOOL retVal;

	CString version("");
	version.Empty();
	LPVOID versionBuffer = NULL;
	LPVOID versionInfo = NULL;
	static char fileVersion[256];
	BOOL success = TRUE;
	
	major = 0;
	minor = 0;
	build = 0;
	revision = 0;
	
	vSize = GetFileVersionInfoSize(filename, &vLen);
	if (vSize) 
	{
		versionInfo = malloc(vSize+1);
		if (GetFileVersionInfo(filename, vLen, vSize, versionInfo))
		{            
			sprintf(fileVersion, "\\VarFileInfo\\Translation");
			retVal = VerQueryValue(versionInfo, fileVersion, &versionBuffer, (UINT *)&vLen);
			if (retVal && vLen == 4) 
			{
				memcpy(&langD, versionBuffer, 4);
				sprintf(fileVersion, "\\StringFileInfo\\%02X%02X%02X%02X\\FileVersion", (langD & 0xff00) >> 8, langD & 0xff, (langD & 0xff000000) >> 24, (langD & 0xff0000) >> 16);
			}
			else
			{
				sprintf(fileVersion, "\\StringFileInfo\\%04X04B0\\FileVersion", GetUserDefaultLangID());
			}
			
			retVal = VerQueryValue(versionInfo, fileVersion, &versionBuffer, (UINT *)&vLen);
			if (!retVal)
			{
				success = FALSE;
			}
		}
		else
		{ 
			success = FALSE;
		}
	}
	else
	{
		success = FALSE;
	}

	if (success)
	{
		if (vLen < 256)
		{
			strcpy(fileVersion, (char *)versionBuffer);
		}
		else 
		{
			strncpy(fileVersion, (char *)versionBuffer, 250);
			fileVersion[250] = 0;
		}
		// Fill Param values
		int fieldsExtracted = sscanf(fileVersion, "%d.%d.%d.%d", &major, &minor, &build, &revision);
		version.Format("%d.%d.%d.%d", major, minor, build, revision);
	}
	if (versionInfo)
	{
		free(versionInfo);
	}
	versionInfo = NULL;
	return version;
}

// ==================================================================================
// Get Windows Version
// ==================================================================================
CString CxtInfoPlugin::GetLanguage()
{
	char buf[2048];
	CString language("");
	language.Empty();
	LCID lcid = GetUserDefaultLCID();
	GetLocaleInfo(lcid, LOCALE_SENGLANGUAGE, buf, 2048);
	language.Format("%s", buf);
	return language;
}

// ==================================================================================
// Get Windows Version
// ==================================================================================
CString CxtInfoPlugin::GetWindowsVersion()
{
	CString version("");
	version.Empty();
	OSVERSIONINFO osvi;
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osvi);
	version.Format("%d.%d.%d.%d", osvi.dwMajorVersion, osvi.dwMinorVersion, osvi.dwBuildNumber, osvi.dwPlatformId);
	return version;
}

// ==================================================================================
// Get Windows Id
// ==================================================================================
CString CxtInfoPlugin::GetWindowsId()
{
	CString id("");
	id.Empty();

	OSVERSIONINFO osvi;
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osvi);

	if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 2)
		{
			// Windows 2003
			id.Format("2003");
		}
		else if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 1)
		{
			// Windows XP
			id.Format("xp");
		}
		else if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 0)
		{
			// Windows 2000
			id.Format("2000");
		}
		else
		{
			if (osvi.dwMajorVersion == 4)
			{
				// Windows NT4
				id.Format("nt4");
			}
			else
			{
				// Windows NT3
				id.Format("nt3");
			}
		}
	}
	else if(osvi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
	{
		if (osvi.dwMinorVersion < 10)
		{
			// Windows 95
			id.Format("95");
		}
		else if (osvi.dwMinorVersion < 90)
		{
			// Windows 98
			id.Format("98");
		}
		else
		{
			// Windows ME
			id.Format("me");
		}
	}
	
	return id;
}

// ==================================================================================
// Get Windows Service Pack Id
// ==================================================================================
CString CxtInfoPlugin::GetWindowsServicePackId()
{
	CString sp("");
	sp.Empty();

	OSVERSIONINFO osvi;
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osvi);

	if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		// Use default Service Pack string (will be overwritten if NT3 or NT4)
		sp.Format(osvi.szCSDVersion);
		
		if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 2)
		{
			// Windows 2003
		}
		else if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 1)
		{
			// Windows XP
		}
		else if (osvi.dwMajorVersion == 5 && osvi.dwMinorVersion == 0)
		{
			// Windows 2000
		}
		else
		{
			// Windows NT4
			if (osvi.dwMajorVersion == 4 && lstrcmpi(osvi.szCSDVersion, "Service Pack 6" ) == 0)
			{
				HKEY hKey = NULL;
				LONG result;

				// Test for SP6 versus SP6a.
				result = RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Hotfix\\Q246009", 0, KEY_QUERY_VALUE, &hKey);
				if (hKey)
				{
					RegCloseKey(hKey);
				}
				if (result == ERROR_SUCCESS)
				{
					//printf("Service Pack 6a (Build %d)\n", osvi.dwBuildNumber & 0xFFFF);
					sp.Format("6a");
				}
				else
				{
					// Windows NT 4.0 prior to SP6a
					//printf("%s (Build %d)\n", osvi.szCSDVersion, osvi.dwBuildNumber & 0xFFFF);
					sp.Format("6");
				}
			}
			else
			{
				// Windows NT3
			}
		}
	}
	else if(osvi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
	{
		// No Service Packs for Window 32 versions (95, 98, ME)
		sp.Format("");
	
		if (osvi.dwMinorVersion < 10)
		{
			// Windows 95
		}
		else if (osvi.dwMinorVersion < 90)
		{
			// Windows 98
		}
		else
		{
			// Windows ME
		}
	}
	
	// Convert to short format
	sp.MakeLower();
	sp.Replace(" ", "");
	sp.Replace("servicepack", "");
	sp.Replace("sp", "");
	
	return sp;
}


// ==================================================================================
// Get Internet Explorer Version
// ==================================================================================
CString CxtInfoPlugin::GetInternetExplorerVersion()
{
	int fieldsExtracted = 0;
	int major, minor, build, revision = 0;
	CString version("");
	version.Empty();

	// Get Internet Explorer version from MSHTML.DLL in system directory (only way to get correct versions prior to 5.0)
	LPTSTR lpszSystemInfo;
	TCHAR tchBuffer[1024];
	lpszSystemInfo = tchBuffer;
	if (GetSystemDirectory(lpszSystemInfo, MAX_PATH+1))
	{
		CString mshtmlFileName("");
		mshtmlFileName.Format("%s\\mshtml.dll", lpszSystemInfo);
		if (this->FileExists(mshtmlFileName))
		{
			this->GetFileVersion(mshtmlFileName.GetBuffer(), major, minor, build, revision);
			//CString info("");
			//info.Format("mshtml.dll was found (%d.%d.%d.%d)", major, minor, build, revision);
			//MessageBox(NULL, info, "", MB_OK);
		}
	}

	// Now we don't have the version yet, let's try alternative method from System Registry Database
	if (major == 0)
	{
		CString versionString = this->QueryRegValue(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Internet Explorer", "Version");
		fieldsExtracted = sscanf(versionString, "%d.%d.%d.%d", &major, &minor, &build, &revision);
	}
	
	version.Format("%d.%d.%d.%d", major, minor, build, revision);
	return version;
}

// ==================================================================================
// Get Internet Explorer Id
// ==================================================================================
CString CxtInfoPlugin::GetInternetExplorerId()
{
	int fieldsExtracted = 0;
	int major, minor, build, revision;
	CString id("");
	id.Empty();
	
	fieldsExtracted = sscanf(this->GetInternetExplorerVersion(), "%d.%d.%d.%d", &major, &minor, &build, &revision);

	if (major == 4 && minor >= 40 && minor < 70) id.Format("1.0");
	if (major == 4 && minor >= 40 && minor < 70 && build >= 500) id.Format("2.0");
	if (major == 4 && minor >= 70 && build >= 1100) id.Format("3.0");
	if (major == 4 && minor >= 70 && build >= 1200) id.Format("3.01");
	if (major == 4 && minor >= 70 && build >= 1300) id.Format("3.02");
	if (major == 4 && minor >= 71) id.Format("4.0");
	if (major == 4 && minor >= 72) id.Format("4.01");
	if (major == 5 && minor == 0 && build < 2900) id.Format("5.0");
	if (major == 5 && minor == 0 && build >= 2900) id.Format("5.01");
	if (major == 5 && minor >= 50) id.Format("5.5");
	if (major == 6) id.Format("6.0");
	if (major == 7) id.Format("7.0");
	if (major > 7) id.Format("only the future will tell ;)");

	/*
	4.40.308         Internet Explorer 1.0 (Plus! for Windows 95)
	4.40.520         Internet Explorer 2.0
	4.70.1155        Internet Explorer 3.0
	4.70.1158        Internet Explorer 3.0 (Windows 95 OSR2)
	4.70.1215        Internet Explorer 3.01
	4.70.1300        Internet Explorer 3.02 and 3.02a
	4.71.544         Internet Explorer 4.0 Platform Preview 1.0 (PP1)
	4.71.1008.3      Internet Explorer 4.0 Platform Preview 2.0 (PP2)
	4.71.1712.6      Internet Explorer 4.0
	4.72.2106.8      Internet Explorer 4.01
	4.72.3110.8      Internet Explorer 4.01 Service Pack 1 (Windows 98)
	4.72.3612.1713   Internet Explorer 4.01 Service Pack 2 
	5.00.0518.10     Internet Explorer 5 Developer Preview (Beta 1)
	5.00.0910.1309   Internet Explorer 5 Beta (Beta 2)
	5.00.2014.0216   Internet Explorer 5
	5.00.2314.1003   Internet Explorer 5 (Office 2000)
	5.00.2614.3500   Internet Explorer 5 (Windows 98 Second Edition)
	5.00.2516.1900   Internet Explorer 5.01 (Windows 2000 Beta 3, build 5.00.2031)
	5.00.2919.800    Internet Explorer 5.01 (Windows 2000 RC1, build 5.00.2072)
	5.00.2919.3800   Internet Explorer 5.01 (Windows 2000 RC2, build 5.00.2128)
	5.00.2919.6307   Internet Explorer 5.01 (Office 2000 SR-1)
	5.00.2920.0000   Internet Explorer 5.01 (Windows 2000, build 5.00.2195)
	5.00.3103.1000   Internet Explorer 5.01 SP1 (Windows 2000 SP1)
	5.00.3105.0106   Internet Explorer 5.01 SP1 (Windows 95/98 and Windows NT 4.0)
	5.00.3314.2101   Internet Explorer 5.01 SP2 (Windows 95/98 and Windows NT 4.0)
	5.00.3315.1000   Internet Explorer 5.01 SP2 (Windows 2000 SP2)
	5.00.3502.1000   Internet Explorer 5.01 SP3 (Windows 2000 SP3 only)
	5.00.3700.1000   Internet Explorer 5.01 SP4 (Windows 2000 SP4 only)
	5.50.3825.1300   Internet Explorer 5.5 Developer Preview (Beta)
	5.50.4030.2400   Internet Explorer 5.5 & Internet Tools Beta
	5.50.4134.0100   Internet Explorer 5.5 for Windows Me (4.90.3000)
	5.50.4134.0600   Internet Explorer 5.5
	5.50.4308.2900   Internet Explorer 5.5 Advanced Security Privacy Beta
	5.50.4522.1800   Internet Explorer 5.5 Service Pack 1
	5.50.4807.2300   Internet Explorer 5.5 Service Pack 2
	6.00.2462.0000   Internet Explorer 6 Public Preview (Beta)
	6.00.2479.0006   Internet Explorer 6 Public Preview (Beta) Refresh
	6.00.2600.0000   Internet Explorer 6 (Windows XP)
	6.00.2800.1106   Internet Explorer 6 Service Pack 1 (Windows XP SP1)
	6.00.3663.0000   Internet Explorer 6 for Microsoft Windows Server 2003 RC1 
	6.00.3718.0000   Internet Explorer 6 for Windows Server 2003 RC2
	6.00.3790.0000   Internet Explorer 6 for Windows Server 2003 (released)
	*/
	
	return id;
}

// ==================================================================================
// Get .Net Framework Version
// ==================================================================================
CString CxtInfoPlugin::GetDotNetFrameworkVersion()
{
	CString version("");
	version.Empty();
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v1.0")) version.Format("1.0.3705");
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v1.1")) version.Format("1.1.4322");
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v1.2")) version.Format("1.2.0"); // We don't have build versions yet, sorry!
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v2.0")) version.Format("2.0.0"); // We don't have build versions yet, sorry!
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v2.1")) version.Format("2.1.0"); // We don't have build versions yet, sorry!
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v2.2")) version.Format("2.2.0"); // We don't have build versions yet, sorry!

	return version;
}

// ==================================================================================
// Get .Net Framework Id
// ==================================================================================
CString CxtInfoPlugin::GetDotNetFrameworkId()
{
	CString id("");
	id.Empty();
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v1.0")) id.Format("1.0");
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v1.1")) id.Format("1.1");
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v1.2")) id.Format("1.2");
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v2.0")) id.Format("2.0");
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v2.1")) id.Format("2.1");
	if (this->CheckRegKey(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\.NETFramework\\policy\\v2.2")) id.Format("2.2");
	return id;
}

// ==================================================================================
// Get Microsoft Data Access Components (MDAC) and ADO Version
// ==================================================================================
CString CxtInfoPlugin::GetMDACVersion()
{
	int fieldsExtracted = 0;
	int major, minor, build, revision = 0;
	CString version("");
	version.Empty();

	// Get MDAC version from MSADO15.DLL in the Common Files Directory
	CString commonFilesDir = QueryRegValue(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion", "CommonFilesDir");
	CString adoFileName(commonFilesDir + "\\System\\ado\\msado15.dll");
	if (this->FileExists(adoFileName))
	{
		this->GetFileVersion(adoFileName.GetBuffer(), major, minor, build, revision);
		//CString info("");
		//info.Format("msado15.dll was found (%d.%d.%d.%d)", major, minor, build, revision);
		//MessageBox(NULL, info, "", MB_OK);
	}

	// Now we don't have the version yet, let's try alternative method from System Registry Database
	if (major == 0)
	{
	}
	
	version.Format("%d.%d.%d.%d", major, minor, build, revision);
	return version;
}

// ==================================================================================
// Get Microsoft Data Access Components (MDAC) and ADO Id
// ==================================================================================
CString CxtInfoPlugin::GetMDACId()
{
	int fieldsExtracted = 0;
	int major, minor, build, revision = 0;
	CString id("");
	CString version("");
	id.Empty();
	version = this->GetMDACVersion();
	fieldsExtracted = sscanf(version, "%d.%d.%d.%d", &major, &minor, &build, &revision);
	id.Format("%d.%d", major, minor);
	id.Delete(3, 100);
	return id;
}

// ==================================================================================
// Get OLE DB Jet Version
// ==================================================================================
CString CxtInfoPlugin::GetOLEDBVersion()
{
	int fieldsExtracted = 0;
	int major, minor, build, revision = 0;
	CString version("");
	version.Empty();

	// Get MDAC version from MSADO15.DLL in the Common Files Directory
	CString commonFilesDir = QueryRegValue(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion", "CommonFilesDir");
	CString oledbFileName(commonFilesDir + "\\System\\Ole DB\\oledb32.dll");
	if (this->FileExists(oledbFileName))
	{
		this->GetFileVersion(oledbFileName.GetBuffer(), major, minor, build, revision);
		//CString info("");
		//info.Format("oledb32.dll was found (%d.%d.%d.%d)", major, minor, build, revision);
		//MessageBox(NULL, info, "", MB_OK);
		//if ((major == 2 && minor >= 50) || (major > 2))
	}

	// Now we don't have the version yet, let's try alternative method from System Registry Database
	if (major == 0)
	{
	}
	
	version.Format("%d.%d.%d.%d", major, minor, build, revision);
	return version;
}

// ==================================================================================
// Get OLE DB Jet Id
// ==================================================================================
CString CxtInfoPlugin::GetOLEDBId()
{
	int fieldsExtracted = 0;
	int major, minor, build, revision = 0;
	CString id("");
	CString version("");
	id.Empty();
	version = this->GetOLEDBVersion();
	fieldsExtracted = sscanf(version, "%d.%d.%d.%d", &major, &minor, &build, &revision);
	id.Format("%d.%d", major, minor);
	id.Delete(3, 100);
	return id;
}

// ==================================================================================
// Get Id Result (true or false)
// ==================================================================================
BOOL CxtInfoPlugin::GetIdResult(CString function, CString result)
{
	if (function.CompareNoCase("windows") == 0)
	{
		if (windowsId.IsEmpty()) windowsId = GetWindowsId();
		return windowsId.CompareNoCase(result) == 0 ? TRUE : FALSE;
	}
	return FALSE;
}

// ==================================================================================
// Is .NET Framework Installed ?
// ==================================================================================
BOOL CxtInfoPlugin::IsDotNetFrameworkInstalled()
{
	return !this->GetDotNetFrameworkId().IsEmpty() ? true : false;
}

// ==================================================================================
// Is User Administrator / Has Administrator Privilege
// ==================================================================================
// 15.12.2008 tommi@rouvali.com changed InfoBuffer size to 8192. Original value 1024
// caused broblems is user belongs to domain with a lot of groups.
BOOL CxtInfoPlugin::IsAdministrator()
{
	if (this->IsWindows95() || this->IsWindows98() || this->IsWindowsME())
	{
		return TRUE;
	}

	BOOL fRet = TRUE;
	HANDLE hProcess = INVALID_HANDLE_VALUE;
	HANDLE hAccessToken = INVALID_HANDLE_VALUE;
	UCHAR InfoBuffer[8192] = {0};
	PTOKEN_GROUPS ptgGroups = (PTOKEN_GROUPS)InfoBuffer;
	DWORD dwInfoBufferSize = 0;
	PSID psidAdministrators = NULL;
	SID_IDENTIFIER_AUTHORITY siaNtAuthority = SECURITY_NT_AUTHORITY;
	UINT x = 0;

	hProcess = GetCurrentProcess();

	if (!OpenProcessToken(hProcess, TOKEN_READ, &hAccessToken))
		return FALSE;

	if (!GetTokenInformation( hAccessToken,TokenGroups, InfoBuffer, 8192, &dwInfoBufferSize))
		return FALSE;

	fRet = AllocateAndInitializeSid(&siaNtAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &psidAdministrators);
	if (!fRet)
		return FALSE;

	for (x = 0; x < ptgGroups->GroupCount; x++)
	{
		if (EqualSid(psidAdministrators, ptgGroups->Groups[x].Sid))
		{
			FreeSid(psidAdministrators);
			return TRUE;
		}
	}

	FreeSid(psidAdministrators);
	return FALSE;
} 

