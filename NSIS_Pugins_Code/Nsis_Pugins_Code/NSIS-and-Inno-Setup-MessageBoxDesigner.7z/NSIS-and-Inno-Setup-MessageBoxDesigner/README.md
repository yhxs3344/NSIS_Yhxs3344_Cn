
<table>
  <tbody>
    <tr>
      <td><img width=128 height=128 src="https://i3.imageban.ru/out/2019/03/23/c4d7061ab9308765dccad5d86818a174.png"></td>
 <td><h1>NSIS and Inno Setup MessageBox Designer</h1></td>
    </tr>
  </tbody>
</table>
 
<span style="font-weight: bold;"></span>
<table style="text-align: left; width: 1072px; height: 202px;"
 border="0" cellpadding="2" cellspacing="2">
  <tbody>
    <tr>
      <td><span style="font-weight: bold;">Standalone
user friendly (GUI) application for fast and easy creating of:</span>
      <ul>
        <li style="text-align: left;"><img
 src="https://www.visual-installer.com/images/nsis.png"
 alt="NSISProject icon" border="0"> NSIS MessageBox-es
        </li>
        <li style="text-align: left;"><img
 src="https://www.visual-installer.com/images/innosetup.png"
 alt="InnoSetupProject icon" border="0"> Inno Setup
MessageBox-es </li>
        <li style="text-align: left;">It is free and
open-source</li>
        <li style="text-align: left;">You do not need to
manually write the code, only select design of your desired MessageBox
and appropriate code is generated</li>
        <li style="text-align: left;">It is also possible
to preview the MessageBox so you immediately see how it looks like and
define its result (which button was clicked)</li>
        <li style="text-align: left;">The result can be
copied into clipboard and pasted directly into script with no further
changes</li>
        <li style="text-align: left;">See the installation
system manual for details about MessageBox function syntax and usage</li>
        <li style="text-align: left;">Contains all
features, no limitations!</li>
        <li style="text-align: left;">This tool does not
require any installation or administrator right.</li>
      </ul>
      </td>
      <td><img style="width: 100%; height: 100%;" src="https://i4.imageban.ru/out/2019/03/23/c5915af2791a5b3500d7251ea2ca7cea.png"></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>
