﻿using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("unSigned, s. r. o.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © 2016 - 2018 unSigned")]
[assembly: AssemblyDescription("MessageBox Designer")]
[assembly: AssemblyFileVersion("1.1.0.1")]
[assembly: AssemblyProduct("MessageBox Designer")]
[assembly: AssemblyTitle("MessageBox Designer")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.1.0.1")]
[assembly: CompilationRelaxations(8)]
[assembly: ComVisible(false)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: Guid("023a967e-9f99-4293-84a2-3b6f7c5b3671")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
