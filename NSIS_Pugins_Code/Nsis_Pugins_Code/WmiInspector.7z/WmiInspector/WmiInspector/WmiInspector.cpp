/******************************************************************************
* Wmi plugin v1.0															  *
*																			  *
*   Laurent Kieliszak (l0k1), Montpellier, France							  *
*																			  *
* Started on 04-17-2008														  *
******************************************************************************/

/******************************************************************************
/* Includes																	  *
******************************************************************************/
#ifndef _WIN32_DCOM
#define _WIN32_DCOM
#endif

#include <windows.h>
#include <string.h>
#include <objbase.h>
#include <atlbase.h>
#include <iostream>
#include <stdio.h>
#include <Wbemidl.h>
#include <comutil.h>
#include <comdef.h>

#pragma comment(lib, "wbemuuid.lib")

/******************************************************************************
/* Defines																	  *
******************************************************************************/
// for NSIS stack
#define EXDLL_INIT()				\
{									\
	g_stacktop		= stacktop;		\
	g_variables		= variables;	\
	g_stringsize	= string_size;	\
}
#define	MAX_STRLEN	1024
/******************************************************************************
/* NSIS stack structure														  *
******************************************************************************/
typedef struct _stack_t {
	struct	_stack_t *next;
	char	text[MAX_STRLEN];
} stack_t;
/******************************************************************************
/* Global values															  *
******************************************************************************/
// for NSIS stack
stack_t			**g_stacktop;
char			*g_variables;
unsigned int	g_stringsize;
// for plugin
HINSTANCE		g_hInstance;
char			wmiError[MAX_STRLEN]={0};
char			wmiResult[MAX_STRLEN]={0};
/******************************************************************************
* FUNCTION NAME: pushstring													  *
*     PARAMETER: STR														  *
*		PURPOSE: Removes the element from the top of the NSIS stack and puts  *
*				 it in the buffer.											  * 
*		 RETURN: TRUE if stack is empty, FALSE if value is loaded.			  *
******************************************************************************/
int popstring(char *str)
{
	stack_t *th;

	if (!g_stacktop || !*g_stacktop) return 1;

	th=(*g_stacktop);
	lstrcpy(str,th->text);
	*g_stacktop = th->next;
	GlobalFree((HGLOBAL)th);

	return 0;
}
/******************************************************************************
* FUNCTION NAME: pushstring													  *
*	  PARAMETER: STR														  *
*		PURPOSE: Adds an element to the top of the NSIS stack				  * 
******************************************************************************/
void pushstring(const char *str)
{
	stack_t *th;

	if (!g_stacktop) return;
	
	th=(stack_t*)GlobalAlloc(GPTR, sizeof(stack_t)+g_stringsize);
	lstrcpyn(th->text,str,g_stringsize);
	th->next=*g_stacktop;
	
	*g_stacktop=th;
}
/******************************************************************************
* FUNCTION NAME: SetError													  *
*	 PARAMETERS: MESSAGE, HRES												  *
*		PURPOSE: Compose the error message with the error code returned by	  *
*				 WMI.														  *
******************************************************************************/
void SetError(const _bstr_t message, const long hres)
{
	char buf[MAX_STRLEN]={0};

	strcpy_s(wmiError, message);
	sprintf_s(buf," Error code = 0x%ld",hres);
	strcat_s(wmiError,buf);
}
/******************************************************************************
* INTERNAL FUNCTION: wmiRequest												  *
*		 PARAMETERS: NAMESPACE, TABLE, VALUE								  *
*			PURPOSE: Retrieve the requested value of the table in the correct *
*					 namespace with WMI calls.						   		  *
*			 RETURN: TRUE if value is found, FALSE if error occurs.			  *
******************************************************************************/
bool wmiRequest(const _bstr_t& _namespace, const _bstr_t& _table, const _bstr_t& _value, const _bstr_t& _where)
{
	HRESULT	hres;
    // Obtain the initial locator to WMI.
    CComPtr< IWbemLocator > locator;
    hres = CoCreateInstance	(
							CLSID_WbemLocator,             
							NULL, 
							CLSCTX_INPROC_SERVER, 
							IID_IWbemLocator, 
							reinterpret_cast< void** >( &locator )
							);
    if (FAILED(hres))
    {
        SetError("Failed to create IWbemLocator object.", hres);
        return false;
    }
    // Connect to WMI through the IWbemLocator::ConnectServer method.
    CComPtr< IWbemServices > service;
    const _bstr_t _path = "ROOT\\" + _namespace;
	hres = locator->ConnectServer	(
								_path,							// Object path of WMI namespace
								NULL,							// User name. NULL = current user
								NULL,							// User password. NULL = current
								NULL,							// Locale. NULL indicates current
								WBEM_FLAG_CONNECT_USE_MAX_WAIT, // Security flags.
								NULL,							// Authority (e.g. Kerberos)
								NULL,							// Context object 
								&service						// pointer to IWbemServices proxy
								);
	if (FAILED(hres))
	{
		SetError("Could not connect.", hres);
		return false;
	}
	// Set security levels on the proxy
    hres = CoSetProxyBlanket	(
								service,						// Indicates the proxy to set
								RPC_C_AUTHN_WINNT,				// RPC_C_AUTHN_xxx
								RPC_C_AUTHZ_NONE,				// RPC_C_AUTHZ_xxx
								NULL,							// Server principal name 
								RPC_C_AUTHN_LEVEL_CALL,			// RPC_C_AUTHN_LEVEL_xxx 
								RPC_C_IMP_LEVEL_IMPERSONATE,	// RPC_C_IMP_LEVEL_xxx
								NULL,							// client identity
								EOAC_NONE						// proxy capabilities 
								);
    if (FAILED(hres))
    {
        SetError("Could not set proxy blanket.", hres);
		return false;
    }
	// Use the IWbemServices pointer to make requests of WMI.
    CComPtr< IEnumWbemClassObject > enumerator;
	_bstr_t _request;
	if(_where != _bstr_t(""))
	{
		_request = "SELECT * FROM " + _table + " WHERE " + _where;
	}
	else
	{
		_request = "SELECT * FROM " + _table;
	}
	hres = service->ExecQuery	(
								bstr_t("WQL"), 
								_request,
								WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, 
								NULL,
								&enumerator
								);    
    if (FAILED(hres))
    {
        SetError("Query failed.", hres);
        return false;
    }
    // Get the data from the query.
    CComPtr< IWbemClassObject > value = NULL;
	ULONG uReturn = 0;
	while (enumerator)
    {
		//hres = 
        enumerator->Next(WBEM_INFINITE, 1L, &value, &uReturn);
        if(0 == uReturn)
        {
            break;
        }
		_variant_t var;
        // Get the value of the property
        hres = value->Get(_value, 0, &var, 0, 0);
		if(FAILED(hres))
		{
			SetError("Unable to find requested value.", hres);
			return false;
		}
		_bstr_t str;
		char *cvar;
		switch (var.vt)
		{
			case VT_EMPTY: // nothing
			case VT_NULL: // SQL style Null
				sprintf_s(wmiResult, "");
				break;
			case VT_UI1: // unsigned char
				sprintf_s(wmiResult, "%u", var.cVal);
				break;
			case VT_UI2: // unsigned short	
				sprintf_s(wmiResult, "%u", var.iVal);
				break;
			case VT_UI4: // unsigned long
				sprintf_s(wmiResult, "%u", var.ulVal);
				break;
			case VT_I2: // 2 byte signed int
				
			case VT_I4: // 4 byte signed int
				sprintf_s(wmiResult, "%i", var.lVal);
				break;
			case VT_BOOL: // True=-1, False=0
				sprintf_s(wmiResult, "%s", (var.boolVal) ? "TRUE" : "FALSE");
				break;
			case VT_BSTR: // OLE Automation string 
				str = var.bstrVal;
				cvar=str;
				strcpy_s(wmiResult,cvar);
				break;
			default: 
				sprintf_s(wmiResult, "UNHANDLED VARIANT TYPE (%i)", (int)var.vt);
				break;
        }
    }
	return true;
}
/******************************************************************************
* INTERNAL FUNCTION: StackResult											  *
*		  PARAMETER: RESULT													  *
*			PURPOSE: Stack returned value for NSIS plugin		 			  * 
******************************************************************************/
void StackResult(bool result)
{
	switch(result)
		{
			case true: 
					pushstring(wmiResult);
					pushstring("ok");		
					break;
			case false: 
					pushstring(wmiError);
					pushstring("error");
				break;
		}
}
/******************************************************************************
* EXTERNAL FUNCTION: Request							  					  *
*		 PARAMETERS: NAMESPACE, TABLE, ITEM									  *
*			PURPOSE: Return the value of the named item from the table in the *
*					 specified namespace.						  		 	  *
******************************************************************************/
extern "C"
void __declspec(dllexport) Request(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	char wminamespace[MAX_STRLEN]={0};
	char wmitable[MAX_STRLEN]={0};
	char wmivalue[MAX_STRLEN]={0};

	EXDLL_INIT();
	{
		popstring(wminamespace);
		popstring(wmitable);
		popstring(wmivalue);
		StackResult(wmiRequest(_bstr_t(wminamespace), _bstr_t(wmitable), _bstr_t(wmivalue), ""));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: OS														  *
*			PURPOSE: Return the caption (short name) of the OS from the		  *
*					 Win32_OperatingSystem table.					 		  * 
******************************************************************************/
extern "C"
void __declspec(dllexport) OS(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	{
		StackResult(wmiRequest("CIMV2", "Win32_OperatingSystem", "Caption", ""));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: OSVersion												  *
*			PURPOSE: Return the version (number) of the OS from the			  *
*					 Win32_OperatingSystem table.							  * 
******************************************************************************/
extern "C"
void __declspec(dllexport) OSVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	{
		StackResult(wmiRequest("CIMV2", "Win32_OperatingSystem", "Version", ""));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: FullOS													  *
*			PURPOSE: Return the caption (short name) + version + Service pack *
*					 number (if any) of the OS from the Win32_OperatingSystem *
*					 table.													  *
******************************************************************************/
extern "C"
void __declspec(dllexport) FullOS(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	char name[MAX_STRLEN]={0};
	char version[MAX_STRLEN]={0};
	char spMaj[MAX_STRLEN]={0};
	char spMin[MAX_STRLEN]={0};
	char result[MAX_STRLEN]={0};

	EXDLL_INIT();
	{
		StackResult(wmiRequest("CIMV2", "Win32_OperatingSystem", "Caption", ""));
		popstring(result);
		if(!strcmp(result,"ok"))
		{
			popstring(name);
			StackResult(wmiRequest("CIMV2", "Win32_OperatingSystem", "Version", ""));
			popstring(result);
			if(!strcmp(result,"ok"))
			{
				popstring(version);
				StackResult(wmiRequest("CIMV2", "Win32_OperatingSystem", "ServicePackMajorVersion", ""));
				popstring(result);
				if(!strcmp(result,"ok"))
				{
					popstring(spMaj);
					StackResult(wmiRequest("CIMV2", "Win32_OperatingSystem", "ServicePackMinorVersion", ""));
					popstring(result);
					if(!strcmp(result,"ok"))
					{
						popstring(spMin);
						strcat_s(name," version : ");
						strcat_s(name,version);
						if(strcmp(spMaj,""))
						{
							strcat_s(name," service pack : ");
							strcat_s(name,spMaj);
							if(strcmp(spMin,""))
							{
								strcat_s(name,".");
								strcat_s(name,spMin);
							}
							else
							{
								strcat_s(name,".0");
							}
						}
						pushstring(name);
						pushstring("ok");
					}
					else
					{
						pushstring("error");	
					}
				}
				else
				{
					pushstring("error");	
				}
			}
			else
			{
				pushstring("error");	
			}
		}
		else
		{
			pushstring("error");
		}
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: CPU													  *
*			PURPOSE: Return the Caption (product description) of the CPU from *
*					 the Win32_Processor table.								  * 
******************************************************************************/
extern "C"
void __declspec(dllexport) CPU(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	{
		StackResult(wmiRequest("CIMV2", "Win32_Processor", "Caption", ""));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: Resolution												  *
*			PURPOSE: Return the desktop resolution from the	Win32_Processor	  *
*					 table.													  *
******************************************************************************/
extern "C"
void __declspec(dllexport) Resolution(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	char width[MAX_STRLEN]={0};
	char height[MAX_STRLEN]={0};
	char resolution[MAX_STRLEN]={0};
	char result[MAX_STRLEN]={0};

	EXDLL_INIT();
	{
		StackResult(wmiRequest("CIMV2", "Win32_DesktopMonitor", "ScreenWidth", ""));
		popstring(result);
		if(!strcmp(result,"ok"))
		{
			popstring(width);
			if(strcmp(width,""))
			{
				StackResult(wmiRequest("CIMV2", "Win32_DesktopMonitor", "ScreenHeight", ""));
				popstring(result);
				if(!strcmp(result,"ok"))
				{
					popstring(height);
					strcpy_s(resolution,width);
					strcat_s(resolution,"x");
					strcat_s(resolution,height);
					pushstring(resolution);
					pushstring("ok");
				}
				else
				{
					pushstring("error");
				}
			}
			else
			{
				popstring(result);
				pushstring("Unknown");
				pushstring("ok");
			}
		}
		else
		{
			pushstring("error");
		}
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: UserName												  *
*			PURPOSE: Return the user name that is logged on currently from	  *
*					 the Win32_Processor table.								  * 
******************************************************************************/
extern "C"
void __declspec(dllexport) UserName(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	{
		StackResult(wmiRequest("CIMV2", "Win32_ComputerSystem", "UserName", ""));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: ShortUserName											  *
*			PURPOSE: Return the last part of the user name that is logged on  *
*					 currently from the Win32_Processor table.				  * 
******************************************************************************/
extern "C"
void __declspec(dllexport) ShortUserName(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	{
		if(wmiRequest("CIMV2", "Win32_ComputerSystem", "UserName", ""))
		{
			char savedString[MAX_STRLEN]={0};
			char shortUser[MAX_STRLEN]={0};
			char *nexttoken;
			strcpy_s(savedString, wmiResult);
			strtok_s(wmiResult ,"\\", &nexttoken);
			if(wmiResult != NULL)
			{
				strncpy_s(shortUser, strlen(savedString) - strlen(wmiResult), &savedString[strlen(wmiResult) + 1], strlen(savedString) - strlen(wmiResult));
				pushstring(shortUser);
			}
			else
			{
				pushstring(savedString);
			}
			pushstring("ok");		
		}
		else
		{
			pushstring(wmiError);
			pushstring("error");
		}
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: SID													  *
*			PURPOSE: Return the SID (Security Identifier) of the provided	  *
*					 user from the Win32_Processor table.					  * 
******************************************************************************/
extern "C"
void __declspec(dllexport) UserSID(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	char username[MAX_STRLEN]={0};
	EXDLL_INIT();
	{
		popstring(username);
		StackResult(wmiRequest("CIMV2", "Win32_UserAccount", "SID", "Name = '" + _bstr_t(username) + "'"));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: AntiVirus									  			  *
*			PURPOSE: Return the antivirus software name from the			  *
*					 AntiVirusProduct table in the SecurityCenter namespace.  *
******************************************************************************/
extern "C"
void __declspec(dllexport) AntiVirus(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	{
		StackResult(wmiRequest("SecurityCenter", "AntiVirusProduct", "DisplayName", ""));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: FireWall												  *
*			PURPOSE: Return the firewall software name from the				  *
*					 FirewallProduct table in the SecurityCenter namespace.	  *
******************************************************************************/
extern "C"
void __declspec(dllexport) FireWall(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	{
		StackResult(wmiRequest("SecurityCenter", "FirewallProduct", "DisplayName", ""));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: SQLVersion											  *
*			PURPOSE: Return the version (number) of the SQL Server installed  *
*					 instance from the Win32_Service table.					  *
******************************************************************************/
extern "C"
void __declspec(dllexport) SQLVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	{
		StackResult(wmiRequest("Microsoft\\SqlServer\\ComputerManagement", "SqlServiceAdvancedProperty", "PropertyStrValue", "SQLServiceType = 1 AND PropertyName = 'VERSION'"));
	}
}
/******************************************************************************
* EXTERNAL FUNCTION: FullSQLVersion											  *
*			PURPOSE: Return the Version + Service pack + Edition name of the  *
*					 SQL Server installed instance from the Win32_Service	  *
*					 table.													  *
******************************************************************************/
extern "C"
void __declspec(dllexport) FullSQLVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
	char name[MAX_STRLEN]={0};
	char version[MAX_STRLEN]={0};
	char level[MAX_STRLEN]={0};
	char edition[MAX_STRLEN]={0};
	char result[MAX_STRLEN]={0};
	EXDLL_INIT();
	{
		StackResult(wmiRequest("Microsoft\\SqlServer\\ComputerManagement", "SqlServiceAdvancedProperty", "PropertyStrValue", "SQLServiceType = 1 AND PropertyName = 'VERSION'"));
		popstring(result);
		if(!strcmp(result,"ok"))
		{
			strcat_s(name,"SQL version : ");
			popstring(version);
			strcat_s(name,version);
			StackResult(wmiRequest("Microsoft\\SqlServer\\ComputerManagement", "SqlServiceAdvancedProperty", "PropertyStrValue", "SQLServiceType = 1 AND PropertyName = 'SPLEVEL'"));
			popstring(result);
			if(!strcmp(result,"ok"))
			{
				popstring(level);
				if(strcmp(level, ""))
				{
					strcat_s(name," Level : ");
					strcat_s(name, level);
				}
				StackResult(wmiRequest("Microsoft\\SqlServer\\ComputerManagement", "SqlServiceAdvancedProperty", "PropertyStrValue", "SQLServiceType = 1 AND PropertyName = 'SKUNAME'"));
				popstring(result);
				if(!strcmp(result,"ok"))
				{
					popstring(edition);
					if(strcmp(edition, ""))
					{
						strcat_s(name," Edition : ");
						strcat_s(name, edition);
					}
				}
			}
			pushstring(name);
			pushstring("ok");
		}
		else
		{
			pushstring("error");
		}
	}
}
/******************************************************************************
* FUNCTION:	DllMain															  *
*  PURPOSE:	Entry point.													  *
******************************************************************************/
BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	g_hInstance=hInst;

	return TRUE;
}