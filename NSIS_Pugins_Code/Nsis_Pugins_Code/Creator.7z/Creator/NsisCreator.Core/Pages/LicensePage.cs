﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsisCreator
{
  public class LicensePage : PageBase
  {
    public LicensePage()
      : base(PageType.License)
    {

    }
  }
}
