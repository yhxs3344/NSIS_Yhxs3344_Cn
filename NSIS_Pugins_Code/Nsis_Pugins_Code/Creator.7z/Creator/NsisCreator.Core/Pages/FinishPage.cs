﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsisCreator
{
  public class FinishPage : PageBase
  {
    public FinishPage()
      : base(PageType.Finish)
    {

    }
  }
}
