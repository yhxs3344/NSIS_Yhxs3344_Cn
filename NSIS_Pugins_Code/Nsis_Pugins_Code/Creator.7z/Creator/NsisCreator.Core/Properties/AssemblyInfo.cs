using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Allgemeine Informationen �ber eine Assembly werden �ber die folgenden 
// Attribute gesteuert. �ndern Sie diese Attributwerte, um die Informationen zu �ndern,
// die mit einer Assembly verkn�pft sind.
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Durch Festlegen von ComVisible auf "false" werden die Typen in dieser Assembly unsichtbar 
// f�r COM-Komponenten. Wenn Sie auf einen Typ in dieser Assembly von 
// COM zugreifen m�ssen, legen Sie das ComVisible-Attribut f�r diesen Typ auf "true" fest.
[assembly: ComVisible(false)]

// Die folgende GUID bestimmt die ID der Typbibliothek, wenn dieses Projekt f�r COM verf�gbar gemacht wird
[assembly: Guid("FD89006B-D7F2-451A-B3D7-6B04CD85C714")]

// Versionsinformationen f�r eine Assembly bestehen aus den folgenden vier Werten:
//
//      Hauptversion
//      Nebenversion 
//      Buildnummer
//      Revision
//
// Sie k�nnen alle Werte angeben oder die standardm��igen Build- und Revisionsnummern 
// �bernehmen, indem Sie "*" eingeben:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
