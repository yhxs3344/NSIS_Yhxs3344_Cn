nsis-dcrypt
===========

Unicode version of a well-known library DcryptDLL for NSIS Installer
