/*
 * SpiderBanner plugin for NSIS
 *
 * 2006-2007, 2010-2011, 2013-2014, 2016 MouseHelmet Software.
 *
 * ProgressClass.h
 */

/*	After all the testing and optimizing, turns
out this is the only one I actually need. */
HWND CreateProgressBar(HINSTANCE hInst, HWND owner);