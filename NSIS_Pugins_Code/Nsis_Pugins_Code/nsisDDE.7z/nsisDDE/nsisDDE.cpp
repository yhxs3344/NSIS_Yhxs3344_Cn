/*
nsisDDE -- Small NSIS plugin to sends DDE client requests
Web site: http://wiz0u.free.fr/prog/nsisDDE

Copyright (c) 2005-2010 Olivier Marcoux

This software is provided 'as-is', without any express or implied warranty. In no event will the authors be held liable for any damages arising from the use of this software.

Permission is granted to anyone to use this software for any purpose, including commercial applications, and to alter it and redistribute it freely, subject to the following restrictions:

    1. The origin of this software must not be misrepresented; you must not claim that you wrote the original software. If you use this software in a product, an acknowledgment in the product documentation would be appreciated but is not required.

    2. Altered source versions must be plainly marked as such, and must not be misrepresented as being the original software.

    3. This notice may not be removed or altered from any source distribution.
*/
#include <windows.h>
#include <tchar.h>
#include <shlwapi.h>
#include "exdll.h"

#define CLASSNAME	"nsisDDEClass"
#define WINDOWTITLE	"nsisDDE Window"

HINSTANCE g_hInstance;

enum WhichServer {
	all,
	first,
	last
};

struct Params {
	WhichServer wServ;
	const TCHAR *command;
	int serverCount;
	HWND serverDdeWnd;
};

// Note: We are creating an ANSI DDE client window, not Unicode (to be compatible with Win9x)
// This means that DDE execute strings are to be posted as ANSI, even if the server has
// registered an Unicode window. (Unicode DDE servers must be able to process ANSI requests
// if they detect the DDE client window is ANSI with IsWindowUnicode)
// MFC42 has a bug in CFrameWnd::OnDDEExecute if compiled with UNICODE because it assumes
// the request is in Unicode. If your application is using MFC42 in Unicode, you should
// have your own OnDDEExecute and add the following lines before the lstrcpyn:
//	#ifdef UNICODE
//		if (!IsWindowUnicode((HWND) wParam))
//			MultiByteToWideChar(CP_ACP, 0, (LPCSTR) lpsz, -1, szCommand, _MAX_PATH);
//		else
//	#endif
void PostCommandToServer(HWND clientDdeWnd, HWND serverDdeWnd, Params *params)
{
	HGLOBAL hCommands;
#ifdef UNICODE
	if (!IsWindowUnicode(serverDdeWnd)) // we are Unicode but remote server is not Unicode => we need an ANSI command string
	{
		// globally allocate the ANSI command string
		int cch = WideCharToMultiByte(CP_ACP, 0, params->command, -1, NULL, 0, NULL, NULL);
		hCommands = GlobalAlloc(GMEM_DDESHARE, cch);
		char *lpsz = (char *) GlobalLock(hCommands);
		WideCharToMultiByte(CP_ACP, 0, params->command, -1, lpsz, cch, NULL, NULL);
	}
	else
#endif
	{
		// globally allocate the command string
		int cch = lstrlen(params->command)+1;
		hCommands = GlobalAlloc(GMEM_DDESHARE, cch*sizeof(TCHAR));
		TCHAR *lpsz = (TCHAR *) GlobalLock(hCommands);
		lstrcpy(lpsz, params->command);
	}
	GlobalUnlock(hCommands);
	// post the DDE execute string
	::PostMessage(serverDdeWnd, WM_DDE_EXECUTE, (WPARAM) clientDdeWnd, (LPARAM) hCommands);
}

LRESULT CALLBACK DdeWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_DDE_ACK)
	{	// Response to WM_DDE_INITIATE
		Params *params = (Params*) GetWindowLongPtr(hWnd, GWL_USERDATA);
		switch (params->wServ)
		{
		case all:	
			params->serverCount++; // increment server counter and post command to all of them
			PostCommandToServer(hWnd, (HWND) wParam, params); 
			break;
		case first:	
			if (params->serverDdeWnd == NULL) // just save the first HWND that responded
				params->serverDdeWnd = (HWND) wParam; 
			break;
		case last:	
			params->serverDdeWnd = (HWND) wParam; // just save the last HWND that responded
			break;
		}
		// free atom parameters
		GlobalDeleteAtom(LOWORD(lParam));
		GlobalDeleteAtom(HIWORD(lParam));
		return 0L;
	}
	else
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

int ExecuteDDE(HINSTANCE hInstance, TCHAR *appName, TCHAR *command, ATOM aTopic = 0, UINT waitMax = 2, WhichServer wServ = first)
{
	int result = 0; // variable that will be pushed back to NSIS
	Params params;
	params.wServ = wServ;

	// create a temporary window class for our DDE client window
	WNDCLASS wndClass;
	wndClass.style = 0;
	wndClass.lpfnWndProc = DdeWndProc;
	wndClass.cbClsExtra = 0;
	wndClass.cbWndExtra = 0;
	wndClass.hInstance = hInstance;
	wndClass.hIcon = NULL;
	wndClass.hCursor = NULL;
	wndClass.hbrBackground = NULL;
	wndClass.lpszMenuName = NULL;
	wndClass.lpszClassName = _T(CLASSNAME);
	::RegisterClass(&wndClass);

	// create the DDE client window
	HWND clientDdeWnd = ::CreateWindow(_T(CLASSNAME), _T(WINDOWTITLE), WS_POPUP|WS_OVERLAPPED, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
	if (!clientDdeWnd)
		result = -3; // Could not create DDE window
	else
	{		
		ATOM aApp = ::GlobalAddAtom(appName);
		if (aTopic == 0) 
			aTopic = ::GlobalAddAtom(_T("system"));

		params.command = command;
		params.serverDdeWnd = NULL;
		params.serverCount = 0;

		SetWindowLongPtr(clientDdeWnd, GWL_USERDATA, (LONG_PTR) &params);

		// broadcast to contact the DDE server(s)
		// to prevent hang out, we timeout after waitMax/2 seconds
		DWORD dwResult;
		if (::SendMessageTimeout(HWND_BROADCAST, WM_DDE_INITIATE, (WPARAM) clientDdeWnd, MAKELONG(aApp, aTopic), SMTO_NORMAL, waitMax*500, &dwResult))
		{
			// broadcast done, DDE servers synchronous answers have already been
			// handled by DdeWndProc
			if ((params.wServ != all) && (params.serverDdeWnd != NULL))
			{ 
				// option /first or /last was selected => DdeWndProc did just remember the
				// first or last server HWND
				params.serverCount = 1;
				// post command to the server HWND saved by DdeWndProc
				PostCommandToServer(clientDdeWnd, params.serverDdeWnd, &params);
			}

            params.serverCount *= 2; // we expect WM_DDE_ACK & WM_DDE_TERMINATE answers for all servers

			// check if commands and conversation end have being ACK'd by the servers
			// we give them waitMax/2 seconds to answer
			MSG msg;
			for (UINT waitCount = 0; waitCount < waitMax*5; waitCount++)
			{
				// try to peek a DDE message from our DDE client window's message queue
				while (::PeekMessage(&msg, clientDdeWnd, WM_DDE_FIRST, WM_DDE_LAST, PM_REMOVE))
				{	
					if (msg.message == WM_DDE_ACK) // got a reply to our DDE_EXECUTE message
					{
						UINT uiLow, uiHi;
						UnpackDDElParam(WM_DDE_ACK, msg.lParam, &uiLow, &uiHi);
						// free memory associated with parameters
						GlobalFree((HGLOBAL) uiHi);
						FreeDDElParam(WM_DDE_ACK, msg.lParam);
						if (((DDEACK*) &uiLow)->fAck) // is it a positive reply ?
							result++; // increment success counter
						--params.serverCount; // decrement server counter
                        ::PostMessage((HWND) msg.wParam, WM_DDE_TERMINATE, (WPARAM) clientDdeWnd, 0); // end DDE conversation
					}
					else if (msg.message == WM_DDE_TERMINATE) // reply to our DDE_TERMINATE
					{
						if (--params.serverCount == 0) // decrement server counter
							break; // got all of them
					}
				}
				if (params.serverCount == 0) break; // got all server replies
				// wait a little before checking message queue again
				Sleep(100);
			}
		}
		// cleaning window and window class
		::DestroyWindow(clientDdeWnd);
	}
	::UnregisterClass(_T(CLASSNAME), hInstance);
    return result;
}


extern "C" void __declspec(dllexport) Execute(HWND hwndParent, int string_size, TCHAR *variables, stack_t **stacktop)
{
	EXDLL_INIT();
	
	WhichServer wServ = first;
	UINT waitMax = 2; // max number of seconds to wait

	ATOM aTopic = 0;

	// parse command line for 2 non-optional arguments
	TCHAR argv[2][1000];
	int argc = 0;
	while ((argc < 2) && (popstring(argv[argc]) == 0))
	{
		if (argv[argc][0] == '/')
		{
			if (lstrcmpi(argv[argc], _T("/ALL")) == 0)
				wServ = all; // send request to all matching servers
			else if (lstrcmpi(argv[argc], _T("/FIRST")) == 0)
				wServ = first; // send request only to the first matching server that reply
			else if (lstrcmpi(argv[argc], _T("/LAST")) == 0)
				wServ = last; // send request only to the last matching server that reply
			else if (StrCmpNI(argv[argc], _T("/TOPIC="), 7) == 0)
			{ // override default "System" topic
				if (aTopic) ::GlobalDeleteAtom(aTopic);
				aTopic = ::GlobalAddAtom(argv[argc]+7);
			}
			else if (StrCmpNI(argv[argc], _T("/TIMEOUT="), 9) == 0)
			{ // override default timeout
				waitMax = StrToInt(argv[argc]+9);
			}
			else
			{
				pushstring(_T("-1")); // Invalid option parameter
				return;
			}
		}
		else
			argc++;
	}

	if (argc < 2) 
	{
		pushstring(_T("-2")); // Not enough parameters
		return;
	}

    int result = ExecuteDDE(g_hInstance, argv[0], argv[1], aTopic, waitMax, wServ);

	// push the result back to NSIS
	wsprintf(argv[0], _T("%d"), result);
	pushstring(argv[0]);
}

extern "C" BOOL WINAPI main(HINSTANCE hInstance, DWORD dwReason, LPVOID)
{
	g_hInstance = hInstance;
	return TRUE;
}
