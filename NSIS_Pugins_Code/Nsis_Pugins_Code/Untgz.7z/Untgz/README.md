untgz
=====

NSIS <http://nsis.sf.net> plugin used to extract files from tar files.

Supports standard NSIS and Unicode NSIS.  Plugin supports uncompressed tarballs and optionally ones compressed with gzip, bzip2, or lzma.

*.tar
*.tar.gz (*.tgz)
*.tar.bz2 (*.tbz/*.tbz2)
*.tar.lzma (*.tlz)

Limited support for long file names and extensions.
Todo better support for tar variations including pax support.

Please feel free to email me - PerditionC@gmail.com
October 2012
