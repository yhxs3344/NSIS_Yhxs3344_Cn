NsisMultiUser MUI2 Limited Demo, based on the Modern User Interface 2

Features:
- does not fully uninstall previously installed version - only the additional components are removed (except Core files)

Limitations:
- because new versions can add more components, downgrading is not secure - old version will not uninstall new components
- if previous version is installed, user can not set new installation folder (disabled in interface)
- supports only MULTIUSER_INSTALLMODE_ALLOW_BOTH_INSTALLATIONS = 1
