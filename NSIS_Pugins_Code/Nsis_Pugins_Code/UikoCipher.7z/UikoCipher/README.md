# UikoCipher
UikoCipher - NSIS Cipher Library
https://github.com/cdcdx/UikoCipher
UikoCipher是一个NSIS加密库，可用于加密解密，编码解码。
功能：
- RSA加解密
- AES加解密
- Base64编解码
- ASCII编解码
- url编码字符串编解码
- unicode编码字符串编解码
- MD5编码/MD5随机码
- CRC32编码
- SHA1编码