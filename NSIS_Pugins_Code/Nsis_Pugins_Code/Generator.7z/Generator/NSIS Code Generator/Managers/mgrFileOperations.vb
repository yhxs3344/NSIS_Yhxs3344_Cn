﻿Imports System.IO

Public Class mgrFileOperations

    Function ReadFolder(ByVal strPath As String, ByRef objFiles As ArrayList, ByRef strRootPath As String) As Boolean
        Dim objDirectories As DirectoryInfo
        Dim objFileObject As clsFileObject
        Dim objDirectory As DirectoryInfo
        Dim strCurrentFile As String

        If Directory.Exists(strPath) Then
            For Each strCurrentFile In Directory.GetFiles(strPath)
                objFileObject = New clsFileObject
                With objFileObject
                    .Name = Path.GetFileName(strCurrentFile)
                    .Path = Path.GetDirectoryName(strCurrentFile)
                    .RootPath = strRootPath
                    .Type = clsFileObject.eTypes.File
                End With
                objFiles.Add(objFileObject)
            Next

            objDirectories = New DirectoryInfo(strPath)
            For Each objDirectory In objDirectories.GetDirectories
                objFileObject = New clsFileObject
                With objFileObject
                    .Name = objDirectory.Name
                    .Path = objDirectory.FullName
                    .RootPath = strRootPath
                    .Type = clsFileObject.eTypes.Directory
                    If objDirectory.GetFiles.Count = 0 Then
                        .Empty = True
                    End If
                End With
                objFiles.Add(objFileObject)
                ReadFolder(objDirectory.FullName, objFiles, strRootPath)
            Next
        Else
            MsgBox("The specified path does not exist!")
            Return False
        End If

        Return True
    End Function

    Function BrowseFolder() As String
        Dim objDialog As New FolderBrowserDialog

        objDialog.RootFolder = Environment.SpecialFolder.Desktop

        If objDialog.ShowDialog = DialogResult.OK Then
            Return objDialog.SelectedPath
        End If
        Return String.Empty
    End Function


End Class
