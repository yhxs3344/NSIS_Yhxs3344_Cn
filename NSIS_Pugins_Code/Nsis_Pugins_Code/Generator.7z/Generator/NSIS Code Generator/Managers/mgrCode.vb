﻿Public Class mgrCode

    Function ReadyHeader(ByVal objSettings As clsSettings)
        Dim strModdedHeader As String
        strModdedHeader = My.Resources.NSI_Header.Replace("[name]", objSettings.Name)
        strModdedHeader = strModdedHeader.Replace("[instdir]", objSettings.InstDir)
        Return strModdedHeader
    End Function

    Function ReadyFooter(ByVal objSettings As clsSettings)
        Dim strModdedFooter As String
        strModdedFooter = My.Resources.NSI_Footer.Replace("[name]", objSettings.Name)
        strModdedFooter = strModdedFooter.Replace("[exe]", objSettings.Exe)
        strModdedFooter = strModdedFooter.Replace("[args]", objSettings.Args)
        strModdedFooter = strModdedFooter.Replace("[icon]", objSettings.Icon)
        Return strModdedFooter
    End Function

    Function GenerateCode(ByVal arlFileObjects As ArrayList) As ArrayList
        Dim arlGeneratedCode As New ArrayList
        Dim obj As clsFileObject

        For Each obj In arlFileObjects
            If obj.Type = clsFileObject.eTypes.Directory Then
                arlGeneratedCode.Add(vbTab & "${CreateDirectory} ""$INSTDIR\" & obj.Name & """")
                If Not obj.Empty Then
                    arlGeneratedCode.Add(vbTab & "${SetOutPath} ""$INSTDIR\" & obj.Name & """")
                End If
            End If

            If obj.Type = clsFileObject.eTypes.File Then
                arlGeneratedCode.Add(vbTab & "${File} """ & obj.Path & """" & " " & """" & obj.Name & """")
            End If
        Next

        Return arlGeneratedCode
    End Function
End Class
