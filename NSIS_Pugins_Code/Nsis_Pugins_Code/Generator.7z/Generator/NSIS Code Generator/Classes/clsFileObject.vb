﻿Public Class clsFileObject

    Public Enum eTypes As Integer
        File = 0
        Directory = 1
    End Enum

    Private mstrName As String
    Private mstrPath As String
    Private mstrRootPath As String
    Private mblnEmpty As Boolean = False
    Private mintType As eTypes

    Property Name As String
        Get
            If Type = eTypes.File Then
                Return mstrName
            Else
                mstrName = mstrPath.Remove(0, mstrRootPath.Length + 1)
                Return mstrName
            End If
        End Get
        Set(ByVal value As String)
            mstrName = value
        End Set
    End Property
    Property Path As String
        Get
            Return mstrPath
        End Get
        Set(value As String)
            mstrPath = value
        End Set
    End Property
    Property RootPath As String
        Get
            Return mstrRootPath
        End Get
        Set(value As String)
            mstrRootPath = value
        End Set
    End Property
    Property Empty As Boolean
        Get
            Return mblnEmpty
        End Get
        Set(value As Boolean)
            mblnEmpty = value
        End Set
    End Property
    Property Type As eTypes
        Get
            Return mintType
        End Get
        Set(value As eTypes)
            mintType = value
        End Set
    End Property

End Class
