﻿Public Class clsSettings

    Private mstrName As String = String.Empty
    Private mstrInstDir As String = String.Empty
    Private mstrExe As String = String.Empty
    Private mstrArgs As String = String.Empty
    Private mstrIcon As String = String.Empty

    Property Name As String
        Get
            Return mstrName
        End Get
        Set(value As String)
            mstrName = value
        End Set
    End Property

    Property InstDir As String
        Get
            Return mstrInstDir
        End Get
        Set(value As String)
            mstrInstDir = value
        End Set
    End Property

    Property Exe As String
        Get
            Return mstrExe
        End Get
        Set(value As String)
            mstrExe = value
        End Set
    End Property

    Property Args As String
        Get
            Return mstrArgs
        End Get
        Set(value As String)
            mstrArgs = value
        End Set
    End Property

    Property Icon As String
        Get
            Return mstrIcon
        End Get
        Set(value As String)
            mstrIcon = value
        End Set
    End Property
End Class
