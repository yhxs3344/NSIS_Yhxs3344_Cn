﻿Imports System.Threading

Public Class Main
    Dim intProgress As Decimal
    Dim strFiles As String
    Dim strHeader As String
    Dim strFooter As String
    Dim mobjSettings As New clsSettings

    Private Sub Main_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        txtCode.ReadOnly = True
        tsProgress.Maximum = 100
    End Sub

    Private Sub btnGo_Click(sender As System.Object, e As System.EventArgs) Handles btnGo.Click
        tsProgress.Value = 0
        txtCode.Text = String.Empty
        strFiles = String.Empty
        txtPath.Enabled = False
        btnGo.Enabled = False
        btnBrowser.Enabled = False
        bwMain.RunWorkerAsync()
    End Sub

    Private Sub btnBrowser_Click(sender As System.Object, e As System.EventArgs) Handles btnBrowser.Click
        Dim objfile As New mgrFileOperations
        txtPath.Text = objfile.BrowseFolder()
    End Sub

    Private Sub DisplayCode()
        Dim mgrFileOperations As New mgrFileOperations
        Dim mgrCode As New mgrCode
        Dim arlFileObjects As New ArrayList
        Dim arlGeneratedCode As ArrayList
        Dim intFileCounter As Integer
        Dim obj As Object
        Dim strRootPath As String
        Dim intTotalRecords As Integer

        strRootPath = txtPath.Text
        If mgrFileOperations.ReadFolder(txtPath.Text, arlFileObjects, strRootPath) = False Then
            Exit Sub
        End If

        tsLabel2.Text = "Building File Header..."
        strHeader = mgrCode.ReadyHeader(mobjSettings)

        tsLabel2.Text = "Building File List..."
        arlGeneratedCode = mgrCode.GenerateCode(arlFileObjects)
        intTotalRecords = arlGeneratedCode.Count
        tsLabel2.Text = "Generating Code..."

        For Each obj In arlGeneratedCode
            strFiles = strFiles & obj.ToString
            intFileCounter += 1
            intProgress = Int(intFileCounter / intTotalRecords * 100)
            bwMain.ReportProgress(intProgress)
            If intFileCounter <> arlGeneratedCode.Count Then strFiles = strFiles & vbCrLf
        Next

        tsLabel2.Text = "Building File Footer..."
        strFooter = mgrCode.ReadyFooter(mobjSettings)

        tsLabel2.Text = "Coded Generated to Clipboard!"
    End Sub

    Private Sub bwMain_DoWork(sender As System.Object, e As System.ComponentModel.DoWorkEventArgs) Handles bwMain.DoWork
        DisplayCode()
    End Sub

    Private Sub bwMain_ProgressChanged(sender As System.Object, e As System.ComponentModel.ProgressChangedEventArgs) Handles bwMain.ProgressChanged
        tsLabel.Text = Str(intProgress) & "%"
        tsProgress.Value = intProgress
    End Sub

    Private Sub bwMain_RunWorkerCompleted(sender As System.Object, e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles bwMain.RunWorkerCompleted
        txtPath.Enabled = True
        btnGo.Enabled = True
        btnBrowser.Enabled = True
        txtCode.Text = strHeader & vbCrLf & strFiles & vbCrLf & strFooter
        If strFiles.Length > 0 Then Clipboard.SetText(txtCode.Text)
    End Sub

    Private Sub btnSettings_Click(sender As System.Object, e As System.EventArgs) Handles btnSettings.Click
        Dim frm As New frmSettings
        frm.mobjSettings = mobjSettings
        If frm.ShowDialog() = Windows.Forms.DialogResult.OK Then
            mobjSettings = frm.mobjSettings
        End If
    End Sub
End Class
