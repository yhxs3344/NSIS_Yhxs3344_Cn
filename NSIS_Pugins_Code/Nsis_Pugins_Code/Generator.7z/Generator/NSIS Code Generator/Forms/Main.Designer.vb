﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtPath = New System.Windows.Forms.TextBox()
        Me.btnGo = New System.Windows.Forms.Button()
        Me.txtCode = New System.Windows.Forms.TextBox()
        Me.btnBrowser = New System.Windows.Forms.Button()
        Me.ssMain = New System.Windows.Forms.StatusStrip()
        Me.tsProgress = New System.Windows.Forms.ToolStripProgressBar()
        Me.tsLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tsLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.bwMain = New System.ComponentModel.BackgroundWorker()
        Me.btnSettings = New System.Windows.Forms.Button()
        Me.ssMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtPath
        '
        Me.txtPath.Location = New System.Drawing.Point(12, 12)
        Me.txtPath.Name = "txtPath"
        Me.txtPath.Size = New System.Drawing.Size(617, 20)
        Me.txtPath.TabIndex = 0
        '
        'btnGo
        '
        Me.btnGo.Location = New System.Drawing.Point(734, 10)
        Me.btnGo.Name = "btnGo"
        Me.btnGo.Size = New System.Drawing.Size(38, 23)
        Me.btnGo.TabIndex = 3
        Me.btnGo.Text = "Go"
        Me.btnGo.UseVisualStyleBackColor = True
        '
        'txtCode
        '
        Me.txtCode.Location = New System.Drawing.Point(12, 47)
        Me.txtCode.Multiline = True
        Me.txtCode.Name = "txtCode"
        Me.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtCode.Size = New System.Drawing.Size(760, 490)
        Me.txtCode.TabIndex = 4
        Me.txtCode.TabStop = False
        Me.txtCode.WordWrap = False
        '
        'btnBrowser
        '
        Me.btnBrowser.Location = New System.Drawing.Point(635, 9)
        Me.btnBrowser.Name = "btnBrowser"
        Me.btnBrowser.Size = New System.Drawing.Size(24, 23)
        Me.btnBrowser.TabIndex = 1
        Me.btnBrowser.Text = "..."
        Me.btnBrowser.UseVisualStyleBackColor = True
        '
        'ssMain
        '
        Me.ssMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsProgress, Me.tsLabel, Me.tsLabel2})
        Me.ssMain.Location = New System.Drawing.Point(0, 540)
        Me.ssMain.Name = "ssMain"
        Me.ssMain.Size = New System.Drawing.Size(784, 22)
        Me.ssMain.SizingGrip = False
        Me.ssMain.TabIndex = 4
        Me.ssMain.Text = "ssMain"
        '
        'tsProgress
        '
        Me.tsProgress.Name = "tsProgress"
        Me.tsProgress.Size = New System.Drawing.Size(100, 16)
        '
        'tsLabel
        '
        Me.tsLabel.Name = "tsLabel"
        Me.tsLabel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.tsLabel.Size = New System.Drawing.Size(39, 17)
        Me.tsLabel.Text = "Ready"
        '
        'tsLabel2
        '
        Me.tsLabel2.Name = "tsLabel2"
        Me.tsLabel2.Size = New System.Drawing.Size(628, 17)
        Me.tsLabel2.Spring = True
        Me.tsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'bwMain
        '
        Me.bwMain.WorkerReportsProgress = True
        '
        'btnSettings
        '
        Me.btnSettings.Location = New System.Drawing.Point(665, 10)
        Me.btnSettings.Name = "btnSettings"
        Me.btnSettings.Size = New System.Drawing.Size(63, 23)
        Me.btnSettings.TabIndex = 2
        Me.btnSettings.Text = "Settings"
        Me.btnSettings.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 562)
        Me.Controls.Add(Me.btnSettings)
        Me.Controls.Add(Me.ssMain)
        Me.Controls.Add(Me.btnBrowser)
        Me.Controls.Add(Me.txtCode)
        Me.Controls.Add(Me.btnGo)
        Me.Controls.Add(Me.txtPath)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.Text = "NSIS Code Generator"
        Me.ssMain.ResumeLayout(False)
        Me.ssMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtPath As System.Windows.Forms.TextBox
    Friend WithEvents btnGo As System.Windows.Forms.Button
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents btnBrowser As System.Windows.Forms.Button
    Friend WithEvents ssMain As System.Windows.Forms.StatusStrip
    Friend WithEvents tsLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tsProgress As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents bwMain As System.ComponentModel.BackgroundWorker
    Friend WithEvents tsLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents btnSettings As System.Windows.Forms.Button

End Class
