﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtShortcutArgs = New System.Windows.Forms.TextBox()
        Me.txtInstDir = New System.Windows.Forms.TextBox()
        Me.txtIconPath = New System.Windows.Forms.TextBox()
        Me.txtShortcutExe = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblInstallDir = New System.Windows.Forms.Label()
        Me.lblShortcutExe = New System.Windows.Forms.Label()
        Me.lblShorcutArgs = New System.Windows.Forms.Label()
        Me.lblIconPath = New System.Windows.Forms.Label()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(14, 30)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(238, 20)
        Me.txtName.TabIndex = 0
        '
        'txtShortcutArgs
        '
        Me.txtShortcutArgs.Location = New System.Drawing.Point(14, 147)
        Me.txtShortcutArgs.Name = "txtShortcutArgs"
        Me.txtShortcutArgs.Size = New System.Drawing.Size(238, 20)
        Me.txtShortcutArgs.TabIndex = 3
        '
        'txtInstDir
        '
        Me.txtInstDir.Location = New System.Drawing.Point(14, 69)
        Me.txtInstDir.Name = "txtInstDir"
        Me.txtInstDir.Size = New System.Drawing.Size(238, 20)
        Me.txtInstDir.TabIndex = 1
        '
        'txtIconPath
        '
        Me.txtIconPath.Location = New System.Drawing.Point(15, 186)
        Me.txtIconPath.Name = "txtIconPath"
        Me.txtIconPath.Size = New System.Drawing.Size(238, 20)
        Me.txtIconPath.TabIndex = 4
        '
        'txtShortcutExe
        '
        Me.txtShortcutExe.Location = New System.Drawing.Point(15, 108)
        Me.txtShortcutExe.Name = "txtShortcutExe"
        Me.txtShortcutExe.Size = New System.Drawing.Size(238, 20)
        Me.txtShortcutExe.TabIndex = 2
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(11, 14)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(38, 13)
        Me.lblName.TabIndex = 5
        Me.lblName.Text = "Name:"
        '
        'lblInstallDir
        '
        Me.lblInstallDir.AutoSize = True
        Me.lblInstallDir.Location = New System.Drawing.Point(11, 53)
        Me.lblInstallDir.Name = "lblInstallDir"
        Me.lblInstallDir.Size = New System.Drawing.Size(82, 13)
        Me.lblInstallDir.TabIndex = 6
        Me.lblInstallDir.Text = "Install Directory:"
        '
        'lblShortcutExe
        '
        Me.lblShortcutExe.AutoSize = True
        Me.lblShortcutExe.Location = New System.Drawing.Point(12, 92)
        Me.lblShortcutExe.Name = "lblShortcutExe"
        Me.lblShortcutExe.Size = New System.Drawing.Size(119, 13)
        Me.lblShortcutExe.TabIndex = 7
        Me.lblShortcutExe.Text = "Shortcut Exe: (Relative)"
        '
        'lblShorcutArgs
        '
        Me.lblShorcutArgs.AutoSize = True
        Me.lblShorcutArgs.Location = New System.Drawing.Point(12, 131)
        Me.lblShorcutArgs.Name = "lblShorcutArgs"
        Me.lblShorcutArgs.Size = New System.Drawing.Size(109, 13)
        Me.lblShorcutArgs.TabIndex = 8
        Me.lblShorcutArgs.Text = "Shortcut Arguements:"
        '
        'lblIconPath
        '
        Me.lblIconPath.AutoSize = True
        Me.lblIconPath.Location = New System.Drawing.Point(12, 170)
        Me.lblIconPath.Name = "lblIconPath"
        Me.lblIconPath.Size = New System.Drawing.Size(104, 13)
        Me.lblIconPath.TabIndex = 9
        Me.lblIconPath.Text = "Icon Path: (Relative)"
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(97, 212)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 5
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(178, 212)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 6
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'frmSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(266, 247)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.lblIconPath)
        Me.Controls.Add(Me.lblShorcutArgs)
        Me.Controls.Add(Me.lblShortcutExe)
        Me.Controls.Add(Me.lblInstallDir)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtShortcutExe)
        Me.Controls.Add(Me.txtIconPath)
        Me.Controls.Add(Me.txtInstDir)
        Me.Controls.Add(Me.txtShortcutArgs)
        Me.Controls.Add(Me.txtName)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSettings"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "Settings"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtShortcutArgs As System.Windows.Forms.TextBox
    Friend WithEvents txtInstDir As System.Windows.Forms.TextBox
    Friend WithEvents txtIconPath As System.Windows.Forms.TextBox
    Friend WithEvents txtShortcutExe As System.Windows.Forms.TextBox
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents lblInstallDir As System.Windows.Forms.Label
    Friend WithEvents lblShortcutExe As System.Windows.Forms.Label
    Friend WithEvents lblShorcutArgs As System.Windows.Forms.Label
    Friend WithEvents lblIconPath As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
End Class
