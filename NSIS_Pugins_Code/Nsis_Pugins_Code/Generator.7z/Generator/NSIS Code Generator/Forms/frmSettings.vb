﻿Public Class frmSettings

    Public mobjSettings As clsSettings

    Private Sub LoadControls()
        txtName.Text = mobjSettings.Name
        txtInstDir.Text = mobjSettings.InstDir
        txtShortcutExe.Text = mobjSettings.Exe
        txtShortcutArgs.Text = mobjSettings.Args
        txtIconPath.Text = mobjSettings.Icon
    End Sub

    Private Sub SaveControls()
        mobjSettings.Name = txtName.Text
        mobjSettings.InstDir = txtInstDir.Text
        mobjSettings.Exe = txtShortcutExe.Text
        mobjSettings.Args = txtShortcutArgs.Text
        mobjSettings.Icon = txtIconPath.Text
    End Sub

    Private Sub frmSettings_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        LoadControls()
    End Sub

    Private Sub btnSave_Click(sender As System.Object, e As System.EventArgs) Handles btnSave.Click
        SaveControls()
        DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub
End Class