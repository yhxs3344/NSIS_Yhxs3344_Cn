// stdafx.cpp : source file that includes just the standard includes
//	UIlib.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "StdAfx.h"

#pragma comment( lib, "winmm.lib" )
#pragma comment( lib, "comctl32.lib" )
