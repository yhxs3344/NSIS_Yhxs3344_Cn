# UikoTCP
UikoTCP - NSIS NetWork Library

UikoTCP是一个NSIS网络库，可用于网络检测，系统参数获取。
功能：
- CheckPort
- CheckURL
- FindProcess
- KillProcess
- GetLocalHostName
- GetSysLanguage
- GetSysVersion
- GetSysBit
- GetProvidesRight
- FileExist