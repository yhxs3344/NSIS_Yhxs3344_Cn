# TaskbarProgress ([NSIS](https://github.com/negrutiu/nsis) plugin)
It displays the installation progress in Windows' taskbar

#
This is a clone of the original project created by **Anders**<br>
https://nsis.sourceforge.io/TaskbarProgress_plug-in
