﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NSISInfoWriter")]
[assembly: AssemblyDescription("NSIS Script Writer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Babaev Evgeniy")]
[assembly: AssemblyProduct("NSISInfoWriter")]
[assembly: AssemblyCopyright("Copyright © 2015-2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("4d38f522-60b2-493b-83df-32ff96b515b6")]

[assembly: AssemblyVersion("1.3.316.5913")]
[assembly: AssemblyFileVersion("1.3.314.5913")]