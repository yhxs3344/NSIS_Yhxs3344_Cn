//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dumpstate.rc
//
// copyright (c) andrew francis, 2003. all rights reserved.
// see readme.txt for license conditions
//
#define IDC_POP                         2
#define IDD_STATE                       101
#define IDD_EDITSTRING                  102
#define IDD_FLAGS                       103
#define IDC_VARS                        1000
#define IDC_STACK                       1001
#define IDC_INSERT                      1002
#define IDC_REMOVE                      1003
#define IDC_EDITNAME                    1004
#define IDC_UP                          1004
#define IDC_EDITVALUE                   1005
#define IDC_DOWN                        1005
#define IDC_COPYALL                     1006
#define IDC_FLAGS                       1007
#define IDC_INFO                        1008
#define IDC_LIST                        IDC_VARS

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
