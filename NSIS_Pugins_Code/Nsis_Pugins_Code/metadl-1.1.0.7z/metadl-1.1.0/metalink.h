#ifndef _METALINK_H
#define _METALINK_H

/* Used to store hashes */

typedef struct {
    char md5[33];
    char sha1[41];
    char has_md5;
    char has_sha1;
} hashdata;

/* Metalink structures */

typedef struct {
    char *identity;
    int num_files;
    struct metafile *first_file;
    struct metafile *last_file;
} metalink;

typedef struct metafile {
    char *filename;
    double size;
    hashdata hashes;
    int num_mirrors;
    struct metamirror *first_mirror;
    struct metamirror *last_mirror;
    double chunk_length;
    int num_chunks;
    struct metachunk *first_chunk;
    struct metachunk *last_chunk;
    struct metafile *next;
} metafile;

typedef struct metamirror {
    char *url;
    struct metamirror *next;
} metamirror;

typedef struct metachunk {
    char *hash;
    struct metachunk *next;
} metachunk;

/* Functions */

metalink* metalink_parse_file(char *filename);

metalink* create_metalink();
void metalink_add_file(metalink *ml, metafile *file);
void metalink_remove_file(metalink *ml);
void metalink_free(metalink *ml);

metafile* create_metafile();
metamirror* metafile_add_mirror(metafile *file);
void metalink_remove_mirror(metafile *file);
void metafile_free_mirrors(metafile *file);
metachunk* metafile_add_chunk(metafile *file);
void metalink_remove_chunk(metafile *file);
void metafile_free_chunks(metafile *file);

int ends_with(char *str, char *str_end);

#endif
