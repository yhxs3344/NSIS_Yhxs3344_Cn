# NSIS-ApplicationID
NSIS Plugin for setting ApplicationID on shortcuts
https://github.com/connectiblutz/NSIS-ApplicationID
Fork of initial ApplicationID plugin by Mike Anchor/jmathies