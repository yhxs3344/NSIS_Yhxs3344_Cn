

KillProcWMI , is an NSIS plugin based on the original KillProc plugin. KillProcWMI uses WMI to acheive the same results, which avoids problems with 32bit processes not being able to kill 64 bit processes.

All Code is freely provided, no guarantees or warranties about its quality, use at your own risk.

Jared Allen.
ChironexSoftware.com