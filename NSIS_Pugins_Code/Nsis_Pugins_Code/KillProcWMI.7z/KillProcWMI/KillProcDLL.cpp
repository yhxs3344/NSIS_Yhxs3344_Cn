
#include "stdafx.h"


HINSTANCE g_hInstance;
HWND g_hwndParent;

BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	g_hInstance=(struct HINSTANCE__ *)hInst;	
	return TRUE;
}

int KillProcWithWMI(const char *szToTerminate, const char* action)
{
	
	HRESULT hr = CoInitialize( NULL );
	if ( FAILED( hr ) )
	{
		ATLTRACE("CoInitialize failed");
		return hr;
	}

	hr = CoInitializeSecurity( NULL, // we're not a server
							   -1, // we're not a server
							   NULL, // dito
							   NULL, // reserved
							   RPC_C_AUTHN_LEVEL_DEFAULT, // let DCOM decide
							   RPC_C_IMP_LEVEL_IMPERSONATE,
							   NULL,
							   EOAC_NONE,
							   NULL );
	if ( FAILED( hr ) )
	{
		ATLTRACE("CoInitializeSecurity failed");
		//return hr;
	}

	USES_CONVERSION;

	int result = 0;	
	// connect to WMI
	CComPtr< IWbemLocator > locator;
	hr = CoCreateInstance( CLSID_WbemAdministrativeLocator, NULL,
						CLSCTX_INPROC_SERVER,
						IID_IWbemLocator, reinterpret_cast< void** >( &locator ) );
	if ( FAILED( hr ) )
	{
		ATLTRACE("Instantiation of IWbemLocator failed");
		return hr;
	}

	// connect to local service with current credentials
	CComPtr< IWbemServices > service;
	hr = locator->ConnectServer( L"root\\cimv2", NULL, NULL, NULL,
								 WBEM_FLAG_CONNECT_USE_MAX_WAIT,
								 NULL, NULL, &service );
	if ( SUCCEEDED( hr ) )
	{
		//set WMI namespace security
        hr = CoSetProxyBlanket(service, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE,
                                        NULL, RPC_C_AUTHN_LEVEL_DEFAULT, RPC_C_IMP_LEVEL_IMPERSONATE,
                                        NULL, EOAC_NONE);
		if ( FAILED( hr ) )
		{
			ATLTRACE("Failed to set proxy blanket 1");
			return hr;
		}

		WCHAR str[256];
		memset(str,0,sizeof(WCHAR) * 256);
		wsprintfW(str,L"SELECT * FROM Win32_Process WHERE Name = '%s'", A2W(szToTerminate));

		ATLTRACE(L"WMI Query: %s", str);

		// execute a query
		CComPtr<IEnumWbemClassObject> enumerator;
		hr = service->ExecQuery( L"WQL", str, WBEM_FLAG_FORWARD_ONLY, NULL, &enumerator );
		if ( SUCCEEDED( hr ) )
		{
			// read the first instance from the enumeration (only one on single processor machines)
			CComPtr<IWbemClassObject> enumItem = NULL;
			ULONG retcnt;			
			hr = enumerator->Next( WBEM_INFINITE, 1L, reinterpret_cast<IWbemClassObject**>( &enumItem ), &retcnt );
		
			if ( SUCCEEDED( hr ) )
			{
				do
				{
					if ( retcnt > 0 )
					{					
						_bstr_t MethodName = (L"Terminate");
						BSTR ParameterName = SysAllocString(L"Reason");
						BSTR ClassName = SysAllocString(L"Win32_Process");

						_bstr_t CreateMethodName = L"Create";

						CComPtr<IWbemClassObject> pClass;
						hr = service->GetObject(ClassName, 0, NULL, &pClass, NULL);
						if ( FAILED( hr ) )
						{
							ATLTRACE("Instantiation of IWbemLocator failed");
							return hr;
						}

						CComPtr<IWbemClassObject> pInParamsDefinition;
						CComPtr<IWbemClassObject> pOutMethod;
						hr = pClass->GetMethod(MethodName, 0, &pInParamsDefinition, &pOutMethod);
						if ( FAILED( hr ) )
						{
							ATLTRACE("Instantiation of IWbemLocator failed");
							return hr;
						}

						_variant_t var_val;
						hr = enumItem->Get( L"Handle", 0, &var_val, NULL, NULL );
						if ( FAILED( hr ) )
						{
							ATLTRACE("Instantiation of IWbemLocator failed");
							return hr;
						}
						wsprintfW(str,L"Win32_Process.Handle=\"%d\"", (int)var_val);
						BSTR ClassNameInstance = SysAllocString(str);
						
						hr = enumItem->Get( L"ExecutablePath", 0, &var_val, NULL, NULL );
						if ( FAILED( hr ) )
						{
							ATLTRACE("Instantiation of IWbemLocator failed");
							return hr;
						}
						wsprintfW(str, L"\"%s\"", var_val.bstrVal);
						BSTR CmdLine = SysAllocString(str);

						
						
						CComPtr<IWbemClassObject> pClassInstance;
						hr = pInParamsDefinition->SpawnInstance(0, &pClassInstance);
						if ( FAILED( hr ) )
						{
							ATLTRACE("Instantiation of IWbemLocator failed");
							return hr;
						}

						// Create the values for the in parameters
						VARIANT pcVal;
						VariantInit(&pcVal);
						V_VT(&pcVal) = VT_I4;

						// Store the value for the in parameters
						hr = pClassInstance->Put(L"Reason", 0, &pcVal, 0);
						if ( FAILED( hr ) )
						{
							ATLTRACE("Instantiation of IWbemLocator failed");
							return hr;
						}

						// Execute Method
						

						hr = service->ExecMethod(ClassNameInstance, MethodName, 0, NULL, pClassInstance, NULL, NULL);
						if ( FAILED( hr ) )
						{
							ATLTRACE("Instantiation of IWbemLocator failed");
							return hr;
						}						
					
						if(stricmp(action , "restart") == 0)
						{		
						
							pInParamsDefinition.Release();
							pOutMethod.Release();
							pClassInstance.Release();

							hr = pClass->GetMethod(CreateMethodName, 0, &pInParamsDefinition, &pOutMethod);
							if ( FAILED( hr ) )
							{
								ATLTRACE("Instantiation of IWbemLocator failed");
								return hr;
							}
														
							hr = pInParamsDefinition->SpawnInstance(0, &pClassInstance);
							if ( FAILED( hr ) )
							{
								ATLTRACE("Instantiation of IWbemLocator failed");
								return hr;
							}

							// Create the values for the in parameters
							VARIANT pcVal;
							VariantInit(&pcVal);
							V_VT(&pcVal) = VT_BSTR;
							pcVal.bstrVal = CmdLine;

							// Store the value for the in parameters
							hr = pClassInstance->Put(L"CommandLine", 0, &pcVal, 0);
							if ( FAILED( hr ) )
							{
								ATLTRACE("Instantiation of IWbemLocator failed");
								return hr;
							}

							wsprintfW(str,L"Win32_Process");
							ClassNameInstance = SysAllocString(str);

							// Execute Method
							hr = service->ExecMethod(ClassNameInstance, CreateMethodName, 0, NULL, pClassInstance, NULL, NULL);
							if ( FAILED( hr ) )
							{
								ATLTRACE("Instantiation of IWbemLocator failed");
								return hr;
							}			


						}

						enumItem.Release();
					}
					else
					{
						ATLTRACE(L"Enumeration empty, %s", str);
						break;
					}					
										
				}while(SUCCEEDED(hr = enumerator->Next(WBEM_INFINITE, 1L, reinterpret_cast<IWbemClassObject**>(&enumItem),&retcnt )));
			}
			else
			{
				ATLTRACE("Error in iterating through enumeration");
				result = -1;
			}
		}
		else
		{
			ATLTRACE("Query failed");
			result = -1;
		}
	}
	else
	{
		ATLTRACE("Couldn't connect to service");
		result = -1;
	}
	
	
	return result;
}


extern "C" __declspec(dllexport) void KillProc(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
	char parameter[200];
	char parameter2[200];
	char temp[64];
	int value;
	g_hwndParent=hwndParent;
  EXDLL_INIT();
  {
		popstring(parameter);
		popstring(parameter2);

		value=KillProcWithWMI(parameter, parameter2);
		setuservariable(INST_R0, itoa(value, temp, 10));
	}
}