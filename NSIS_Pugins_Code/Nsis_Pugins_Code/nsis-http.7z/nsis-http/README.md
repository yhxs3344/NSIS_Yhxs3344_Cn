# nsis-http
NSIS installer plug-in to read and write local machine configuration.

