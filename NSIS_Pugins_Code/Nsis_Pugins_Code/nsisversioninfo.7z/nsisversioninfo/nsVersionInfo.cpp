/*
  nsVersionInfo.cpp
  2008 - S�bastien Kirche
  Idea / structure of the plugin inspired by nsPerl by Fabien POTENCIER
*/

#include <windows.h>
#include <commctrl.h>
#include "exdll.h"
#include <VersionInfo.h>

static void LogMessage(const char *pStr);

HINSTANCE g_hInstance;
HWND g_hwndParent;
HWND g_hwndList;

#define NSMETHOD_INIT(parent) {\
	g_hwndParent = parent; \
	EXDLL_INIT(); \
	g_hwndList = FindWindowEx(FindWindowEx(g_hwndParent, NULL, L"#32770", NULL), NULL, L"SysListView32", NULL); }

typedef enum {
	Signature,
	StrucVersion,
	FileVersion,
	ProductVersion,
	FileFlagsMask,
	FileFlags,
	FileOS,
	FileType,
	FileSubtype,
	FileDate
} fixedValues;

//TODO : remove that method (used to preliminar tests)
void __declspec(dllexport) log(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {
	NSMETHOD_INIT(hwndParent);
	{
		char *msg = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
		popstring(msg);
		LogMessage(msg);
		GlobalFree(msg);
	}
}

/*
 * geFixedValue - return a value in the FixedFileInfo part of the version resource
 * 
 * For the moment, only working with ProductVersion + FileVersion
 * the other values are not useful to me
 */
void getFixedValue(fixedValues val){
	char *file = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
	popstring(file);
	size_t size = mbstowcs(NULL, file, 0);
	wchar_t *wfile = (wchar_t *)GlobalAlloc(GPTR, (size + 1) * sizeof( wchar_t ));
	if (wfile){
		size = mbstowcs(wfile, file, size + 1);
		if (size != (size_t) (-1)){ // if -1 => conversion problem
			
			CVersionInfo vi((const wchar_t*)wfile, NULL, 0xFFFF);
			
			VS_FIXEDFILEINFO &fixed = vi.GetFixedFileInfo();
			char *str = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
			switch (val){
				case ProductVersion:
					sprintf(str, "%d.%d.%d.%d", HIWORD(fixed.dwProductVersionMS), LOWORD(fixed.dwProductVersionMS), HIWORD(fixed.dwProductVersionLS), LOWORD(fixed.dwProductVersionLS));
					break;
				case FileVersion:
					sprintf(str, "%d.%d.%d.%d", HIWORD(fixed.dwFileVersionMS), LOWORD(fixed.dwFileVersionMS), HIWORD(fixed.dwFileVersionLS), LOWORD(fixed.dwFileVersionLS));
					break;
				default:
					//TODO : implement the other values ?
					break;
			}
			pushstring(str);
			GlobalFree(str);
		}
		GlobalFree(wfile);
	}
	//LogMessage(msg);
	GlobalFree(file);
}

/*
 * setFixedValue - set a value in the FixedFileInfo part of the version resource
 * 
 * For the moment, only working with ProductVersion + FileVersion
 * the other values are not useful to me
 */
void setFixedValue(fixedValues val){
	char *file = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
	popstring(file);
	size_t size = mbstowcs(NULL, file, 0);
	wchar_t *wfile = (wchar_t *)GlobalAlloc(GPTR, (size + 1) * sizeof( wchar_t ));
	if (wfile){
		size = mbstowcs(wfile, file, size + 1);
		if (size != (size_t) (-1)){ // if -1 => conversion problem
			
			CVersionInfo vi((const wchar_t*)wfile);
			
			VS_FIXEDFILEINFO &fixed = vi.GetFixedFileInfo();
			WORD val1, val2;
			char *param = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
			char *str = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
			switch (val){
				case ProductVersion:
					popstring(param);
					val1 = atoi(param);
					popstring(param);
					val2 = atoi(param);
					fixed.dwProductVersionMS = MAKELONG(val2, val1);
					popstring(param);
					val1 = atoi(param);
					popstring(param);
					val2 = atoi(param);
					fixed.dwProductVersionLS = MAKELONG(val2, val1);

					//sprintf(str, "%d.%d.%d.%d", HIWORD(fixed.dwProductVersionMS), LOWORD(fixed.dwProductVersionMS), HIWORD(fixed.dwProductVersionLS), LOWORD(fixed.dwProductVersionLS));
					sprintf(str,"%d", 0);
					break;
				case FileVersion:
					popstring(param);
					val1 = atoi(param);
					popstring(param);
					val2 = atoi(param);
					fixed.dwFileVersionMS = MAKELONG(val2, val1);
					popstring(param);
					val1 = atoi(param);
					popstring(param);
					val2 = atoi(param);
					fixed.dwFileVersionLS = MAKELONG(val2, val1);
					//sprintf(str, "%d.%d.%d.%d", HIWORD(fixed.dwFileVersionMS), LOWORD(fixed.dwFileVersionMS), HIWORD(fixed.dwFileVersionLS), LOWORD(fixed.dwFileVersionLS));
					sprintf(str,"%d", 0);
					break;
				default:
					sprintf(str, "%d", -1);
					break;
			}
			vi.ToFile(wfile);
			pushstring(str);
			GlobalFree(str);
			GlobalFree(param);
		}
		GlobalFree(wfile);
	}
	//LogMessage(msg);
	GlobalFree(file);
}

/* 
 * getFixedProductVersion - return the ProductVersion from the FixedFileInfo part of the version resource
 * 
 */
void __declspec(dllexport) getFixedProductVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {
	NSMETHOD_INIT(hwndParent);
	{
		getFixedValue(ProductVersion);
	}
}

/* 
 * getFixedFileVersion - return the FileVersion from the FixedFileInfo part of the version resource
 * 
 */
void __declspec(dllexport) getFixedFileVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {
	NSMETHOD_INIT(hwndParent);
	{
		getFixedValue(FileVersion);
	}
}

/* 
 * getFixedProductVersion - set the ProductVersion in the FixedFileInfo part of the version resource
 * 
 */
void __declspec(dllexport) setFixedProductVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {
	NSMETHOD_INIT(hwndParent);
	{
		setFixedValue(ProductVersion);
	}
}

/* 
 * setFixedFileVersion - set the FileVersion in the FixedFileInfo part of the version resource
 * 
 */
void __declspec(dllexport) setFixedFileVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {
	NSMETHOD_INIT(hwndParent);
	{
		setFixedValue(FileVersion);
	}
}

/*
 * getStringFileInfo - return a StringFileInfo from the version resource
 * 
 * If the string does not exist, return an empty string
 * 
 */
void __declspec(dllexport) getStringFileInfo(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {	
	NSMETHOD_INIT(hwndParent);
	{
		char *file = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
		popstring(file);
		size_t filesize = mbstowcs(NULL, file, 0);
		wchar_t *wfile = (wchar_t *)GlobalAlloc(GPTR, (filesize + 1) * sizeof( wchar_t ));
		if (wfile) 
			mbstowcs(wfile, file, filesize + 1);

		char *str = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
		popstring(str);
		size_t strsize = mbstowcs(NULL, str, 0);
		wchar_t *wstr = (wchar_t *)GlobalAlloc(GPTR, (strsize + 1) * sizeof( wchar_t ));
		if (wstr)
			mbstowcs(wstr, str, strsize + 1);

		if ((filesize != (size_t) (-1)) && (strsize != (size_t) (-1)) ){ // if -1 => conversion problem
			
			CVersionInfo vi((const wchar_t*)wfile);
			

			/*
			VS_FIXEDFILEINFO &fixed = vi.GetFixedFileInfo();
			char *str = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
			switch (val){
				case ProductVersion:
					sprintf(str, "%d.%d.%d.%d", HIWORD(fixed.dwProductVersionMS), LOWORD(fixed.dwProductVersionMS), HIWORD(fixed.dwProductVersionLS), LOWORD(fixed.dwProductVersionLS));
					break;
				case FileVersion:
					sprintf(str, "%d.%d.%d.%d", HIWORD(fixed.dwFileVersionMS), LOWORD(fixed.dwFileVersionMS), HIWORD(fixed.dwFileVersionLS), LOWORD(fixed.dwFileVersionLS));
					break;
			}
			*/
			char *ret = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
			wstring infoval = vi[wstr];
			OutputDebugString(L"Retour de l'appel get string file info");
			OutputDebugString(infoval.c_str());
			wcstombs(ret, infoval.c_str(), sizeof(char) * g_stringsize + 1);
			pushstring(ret);
			GlobalFree(ret);
		}
		GlobalFree(file);
		GlobalFree(wfile);
		GlobalFree(str);
		GlobalFree(wstr);
	}
}


/*
 * setStringFileInfo - set a StringFileInfo into the version resource
 * 
 * If the string does not exist already, it is added
 * 
 */
void __declspec(dllexport) setStringFileInfo(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {	
	NSMETHOD_INIT(hwndParent);
	{
		char *file = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
		popstring(file);
		size_t filesize = mbstowcs(NULL, file, 0);
		wchar_t *wfile = (wchar_t *)GlobalAlloc(GPTR, (filesize + 1) * sizeof( wchar_t ));
		if (wfile) 
			mbstowcs(wfile, file, filesize + 1);

		char *str = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
		popstring(str);
		size_t strsize = mbstowcs(NULL, str, 0);
		wchar_t *wstr = (wchar_t *)GlobalAlloc(GPTR, (strsize + 1) * sizeof( wchar_t ));
		if (wstr)
			mbstowcs(wstr, str, strsize + 1);

		char *val = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
		popstring(val);
		size_t valsize = mbstowcs(NULL, val, 0);
		wchar_t *wval = (wchar_t *)GlobalAlloc(GPTR, (valsize + 1) * sizeof( wchar_t ));
		if (wval)
			mbstowcs(wval, val, valsize + 1);

		if ((filesize != (size_t) (-1)) && (strsize != (size_t) (-1)) && (valsize != (size_t) (-1)) ){ // if -1 => conversion problem
			
			CVersionInfo vi((const wchar_t*)wfile);
			vi[wstr] = wval;
			vi.Save();
			
			//check if ok
			char *ret = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
			wstring infoval = vi[wstr];
			OutputDebugString(L"Retour de l'appel set string file info");
			OutputDebugString(infoval.c_str());
			wcstombs(ret, infoval.c_str(), sizeof(char) * g_stringsize + 1);
			pushstring(ret);
			GlobalFree(ret);
		}
		GlobalFree(file);
		GlobalFree(wfile);
		GlobalFree(str);
		GlobalFree(wstr);
		GlobalFree(val);
		GlobalFree(wval);
	}
}

void __declspec(dllexport) getLibVersion(HWND hwndParent, int string_size, char *variables, stack_t **stacktop) {	
	NSMETHOD_INIT(hwndParent);
	{
		char *str = (char *)GlobalAlloc(GPTR, sizeof(char) * g_stringsize + 1);
		sprintf(str, "%s", CVersionInfo::GetLibVersion());
		pushstring(str);
		GlobalFree(str);
	}
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved) {
	g_hInstance = (HINSTANCE)hInst;
	if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
		//do what you want at init time
	}
	if (ul_reason_for_call == DLL_THREAD_DETACH || ul_reason_for_call == DLL_PROCESS_DETACH) {
		//clean up code
	}

	return TRUE;
}

// Tim Kosse's LogMessage
static void LogMessage(const char *pStr) {
	LVITEM item = {0};
	int nItemCount;
	if (!g_hwndList) return;
	if (!lstrlenA(pStr)) return;
	nItemCount = SendMessage(g_hwndList, LVM_GETITEMCOUNT, 0, 0);
	item.mask = LVIF_TEXT;
#ifndef UNICODE
	item.pszText = (char *)pStr;
#else
	size_t size = mbstowcs(NULL, pStr, 0);
	wchar_t *wstr = (wchar_t *)GlobalAlloc(GPTR, (size + 1) * sizeof( wchar_t ));
	if (wstr){
		size = mbstowcs(wstr, pStr, size + 1);
		if (size != (size_t) (-1)) // if -1 => conversion problem
			item.pszText = wstr;
	}
#endif
	item.cchTextMax = 0;
	item.iItem = nItemCount;
	ListView_InsertItem(g_hwndList, &item);
	ListView_EnsureVisible(g_hwndList, item.iItem, 0);
#ifdef UNICODE
	GlobalFree(wstr);
#endif
}
