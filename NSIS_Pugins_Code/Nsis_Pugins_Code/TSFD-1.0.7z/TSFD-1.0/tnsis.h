#ifndef _TNSIS_H_
#define _TNSIS_H_

#include <windows.h>

#define EXDLL_INIT() {  \
	g_stringsize=string_size; \
g_stacktop=stacktop; }

typedef struct _stack_t {
	struct _stack_t *next;
	char text[1]; // this should be the length of string_size
} stack_t;

extern int g_stringsize;
extern stack_t **g_stacktop;

int __stdcall popstring(char *str, int size);
void __stdcall pushstring(const char *str);

typedef struct {
	int autoclose;
	int all_user_var;
	int exec_error;
	int abort;
	int exec_reboot;
	int reboot_called;
	int XXX_cur_insttype; // deprecated
	int XXX_insttype_changed; // deprecated
	int silent;
	int instdir_error;
	int rtl;
	int errlvl;
	int alter_reg_view;
} exec_flags_type;

typedef struct {
	exec_flags_type *exec_flags;
	int (__stdcall *ExecuteCodeSegment)(int, HWND);
	void (__stdcall *validate_filename)(char *);
} extra_parameters;

#endif