#define _MERGE_DATA_

#include "AggressiveOptimize.h"

#include <windows.h>
#include <shlobj.h>

#include "tnsis.h"

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}

void __declspec(dllexport) SelectFileDialog(HWND hwndParent, int string_size, char *variables, stack_t **stacktop, extra_parameters *extra)
{
	OPENFILENAME ofn={0,}; // XXX WTF
	int save;
	char type[5];
	char path[1024];
	char filter[1024];
	char currentDirectory[1024];
	char initialDir[1024];
	DWORD gfa;
	
	EXDLL_INIT();
	
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hwndParent;
	ofn.lpstrFilter = filter;
	ofn.lpstrFile = path;
	ofn.nMaxFile  = sizeof(path);
	//ofn.Flags = pField->nFlags & (OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_CREATEPROMPT | OFN_EXPLORER);
	ofn.Flags = OFN_CREATEPROMPT | OFN_EXPLORER;
	
	popstring(type, sizeof(type));
	popstring(path, sizeof(path));
	popstring(filter, sizeof(filter));
	
	save = !lstrcmpi(type, "save");
	
	gfa = GetFileAttributes(path);
	if (gfa != (DWORD)-1 && gfa & FILE_ATTRIBUTE_DIRECTORY)
	{
		lstrcpy(initialDir, path);
		ofn.lpstrInitialDir = initialDir;
		path[0] = '\0';
	}
	
	if (!filter[0])
	{
		lstrcpy(filter, "All Files|*.*");
	}
	
	{
		// Convert the filter to the format required by Windows: NULL after each
		// item followed by a terminating NULL
		char *p = filter;
		while (*p) // XXX take care for 1024
		{
			if (*p == '|')
			{
				*p++ = 0;
			}
			else
			{
				p = CharNext(p);
			}
		}
		p++;
		*p = 0;
	}
	
	GetCurrentDirectory(sizeof(currentDirectory), currentDirectory); // save working dir
	
	if ((save ? GetSaveFileName(&ofn) : GetOpenFileName(&ofn)))
	{
		pushstring(path);
	}
	else if (CommDlgExtendedError() == FNERR_INVALIDFILENAME)
	{
		*path = '\0';
		
		if ((save ? GetSaveFileName(&ofn) : GetOpenFileName(&ofn)))
		{
			pushstring(path);
		}
		else
		{
			pushstring("");
		}
	}
	else
	{
		pushstring("");
	}
	
	// restore working dir
	// OFN_NOCHANGEDIR doesn't always work (see MSDN)
	SetCurrentDirectory(currentDirectory);
}