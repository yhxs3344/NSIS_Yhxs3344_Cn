#pragma once
#ifndef _WIN32_IE			// Allow use of features specific to IE 6.0 or later.
#define _WIN32_IE 0x0600
#endif

#include <windows.h>
#include <sqloledb.h>
#include <comutil.h>
#include <TCHAR.h>


