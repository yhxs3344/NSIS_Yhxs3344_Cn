//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by stack.rc
//
#define IDD_DIALOG                      1001
#define IDC_NSIS_LIST_LABEL             2001
#define IDC_NSIS_LIST                   2002
#define IDC_PRIVAT_LIST_LABEL           2003
#define IDC_PRIVAT_LIST                 2004
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11001
#define _APS_NEXT_COMMAND_VALUE         12001
#define _APS_NEXT_CONTROL_VALUE         13002
#define _APS_NEXT_SYMED_VALUE           14001
#endif
#endif
