﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MoveDirectory")]
[assembly: AssemblyProduct("MoveDirectory")]
[assembly: AssemblyCompany("mribi")]
[assembly: AssemblyCopyright("Copyright © mribi 2016")]
[assembly: AssemblyDescription("MoveDirectory")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("685a47a7-2493-4d4f-b54d-10179691e78f")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
