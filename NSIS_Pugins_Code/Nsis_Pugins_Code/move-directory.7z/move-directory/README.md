# nsis-move-directory
A NSIS MoveDirectory tool
