To compile the Grey Album Downloader:

0) Install the NullSoft Installer System
1) Unzip this archive
2) Unzip ContribAndPlugins.zip to C:\Program Files\NSIS (or the
   appropriate directory for your installation)
3) Compile nsisbt.exe by right clicking on nsisbt.nsi and selecting
   "Compile NSIS Script"
4) Compile GreyAlbumDownloader.exe by right clicking on
   GreyAlbumDownloader.nsi and selecting "Compile NSIS Script"
