﻿/*

The MIT License (MIT)
---------------------

Sysintegrator

Copyright © 2018 cyfrost <cyrus.frost@hotmail.com>

Permission is hereby granted, free of charge, to any person obtaining 
a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR AND CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

*/


using System;
using Microsoft.Win32;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Windows.Forms;
using System.Reflection;

namespace Sysinternals_Integrator
{
    class Program
    {

        public string appname = Assembly.GetExecutingAssembly().GetName().Name;
        public string copyright = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).LegalCopyright;
        static Type t = typeof(AssemblyDescriptionAttribute);
       
        static AssemblyDescriptionAttribute a = (AssemblyDescriptionAttribute)AssemblyDescriptionAttribute.GetCustomAttribute(Assembly.GetExecutingAssembly(), t);
        public string desc = a.Description;
        public string version = Assembly.GetExecutingAssembly().GetName().Version.ToString() + " (build " + DateTime.Now.ToString("Myy") + ")";






        #region PublicVarsDeclarations
        string auPath = null;
        string pePath = null;
        public int arch = 0;
        public static bool x86home = false;
        public string home = null;
        public string bin = null;
        string sPath = null;
        string apath = null;
        string apath32 = null;
        string ppath = null;
        string ppath32 = null;
#endregion
    void WriteConfig(string tname)
        {
            try {
            #region RegistryInvokes
            RegistryKey keyMain = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals");
            RegistryKey keyAutoruns = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Autoruns");
            RegistryKey keyAutorunsVT = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Autoruns\VirusTotal");
            RegistryKey keyPE = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer");
            RegistryKey keyPEVT = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\VirusTotal");
            RegistryKey keyPEDLLCMap = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DLLColumnMap");
            RegistryKey keyPEDLLC = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DLLColumns");
            RegistryKey keyPEHDLCMap = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\HandleColumnMap");
            RegistryKey keyPEHDLC = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\HandleColumns");
            RegistryKey keyPEPRCMap = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap");
            RegistryKey keyPEPRC = Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns");
            #endregion
            if (tname == "Autoruns")
            {
                if (keyAutoruns == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\AutoRuns");
                if (keyAutorunsVT == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\AutoRuns\VirusTotal");
                Console.WriteLine(@" ** Writing Configuration under key: HKCU\Software\Sysinternals\Autoruns");
                System.Threading.Thread.Sleep(2000);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Autoruns", true).SetValue("EulaAccepted", 1, RegistryValueKind.DWord);
                Console.WriteLine(@" ** Added entry #1");
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Autoruns", true).SetValue("verifysignatures", 1, RegistryValueKind.DWord);
                Console.WriteLine(@" ** Added entry #2");
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Autoruns", true).SetValue("checkvirustotal", 1, RegistryValueKind.DWord);
                Console.WriteLine(@" ** Added entry #3");
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Autoruns\VirusTotal", true).SetValue("VirusTotalTermsAccepted", 1, RegistryValueKind.DWord);
                Console.WriteLine(@" ** Added entry #4\nSuccess");
            }
            if (tname == "Process Explorer")
            {
                if (keyPE == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\Process Explorer");
                if (keyPEVT == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\Process Explorer\VirusTotal");
                if (keyPEDLLC == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\Process Explorer\DLLColumns");
                if (keyPEDLLCMap == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\Process Explorer\DLLColumnMap");
                if (keyPEHDLC == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\Process Explorer\HandleColumns");
                if (keyPEHDLCMap == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\Process Explorer\HandleColumnMap");
                if (keyPEPRC == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns");
                if (keyPEPRCMap == null)
                    Registry.CurrentUser.CreateSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap");
                Console.WriteLine(@" ** Writing Configuration under key: HKCU\Software\Sysinternals\Process Explorer");
                Console.WriteLine(" ** Adding 81 Entries...\nPlease wait...");
                System.Threading.Thread.Sleep(2000);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("EulaAccepted", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("ShowProcessTree", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("VerifySignatures", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("VirusTotalCheck", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("PrcessColumnCount", 21, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("TrayCPUHistory", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("ShowHeatmaps", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("ShowCpuFractions", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("ShowAllUsers", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("ProcessImageColumnWidth", 261, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("OneInstance", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("HighlightImmersive", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("ETWstandardUserWarning", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("DllSortDirection", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer", true).SetValue("DllColumnCount", 8, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\VirusTotal", true).SetValue("VirusTotalTermsAccepted", 1, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumnMap", true).SetValue("0", 26, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumnMap", true).SetValue("1", 42, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumnMap", true).SetValue("2", 1033, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumnMap", true).SetValue("3", 1111, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumnMap", true).SetValue("4", 1187, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumnMap", true).SetValue("5", 1670, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumnMap", true).SetValue("6", 25, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumnMap", true).SetValue("7", 30, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumns", true).SetValue("0", 110, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumns", true).SetValue("1", 180, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumns", true).SetValue("2", 140, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumns", true).SetValue("3", 300, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumns", true).SetValue("4", 100, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumns", true).SetValue("5", 100, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumns", true).SetValue("6", 100, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\DllColumns", true).SetValue("7", 100, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\HandleColumnMap", true).SetValue("0", 21, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\HandleColumnMap", true).SetValue("1", 22, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\HandleColumns", true).SetValue("0", 100, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\HandleColumns", true).SetValue("1", 450, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("0", 3, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("1", 1670, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("2", 1187, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("3", 1055, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("4", 1060, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("5", 1063, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("6", 4, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("7", 38, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("8", 1033, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("9", 19, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("10", 1061, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("11", 1032, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("12", 1656, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("13", 1190, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("14", 5, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("15", 1086, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("16", 1068, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("17", 1070, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("18", 1617, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("19", 1618, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("20", 1650, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("21", 1650, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumnMap", true).SetValue("22", 1650, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("0", 261, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("1", 131, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("2", 100, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("3", 40, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("4", 80, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("5", 80, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("6", 40, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("7", 150, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("8", 140, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("9", 100, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("10", 234, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("11", 260, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("12", 344, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("13", 70, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("14", 47, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("15", 137, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("16", 77, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("17", 59, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("18", 113, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("19", 117, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("20", 100, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("21", 117, RegistryValueKind.DWord);
                Registry.CurrentUser.OpenSubKey(@"Software\Sysinternals\Process Explorer\ProcessColumns", true).SetValue("22", 100, RegistryValueKind.DWord);
                Console.WriteLine(" ** DONE");
            }
        }
        catch (Exception e) {
                Console.WriteLine("\n\n*----* Exception: " + e.Message + "\nException Raw: " + e.ToString() + "\n\n");
                conExit();
            }
        }
    void RemoveExistingConfig() {
            try
            {
                Console.Clear();
                Registry.CurrentUser.DeleteSubKeyTree(@"Software\Sysinternals");
                Console.WriteLine("\n\n ** Removing any previous Sysinternals Tools configuration...");
                Console.WriteLine(" ** DONE.");
                conExit();
            }
            catch (Exception e) { Console.WriteLine("\nNo existing Configuration found...");
                conExit();
            }
        }
        int PostQuery(string query) {
            bool expr = false;
            Console.WriteLine(query);
            while (expr == false)
            {
                ConsoleKeyInfo xy = Console.ReadKey(true);
                if (xy.Key == ConsoleKey.Y)
                {
                    expr = true;
                    return 0; 
                }
                else if (xy.Key == ConsoleKey.N)
                {
                    expr = true;
                    return 1;
                }
                else
                {
                    Console.WriteLine("Unknown expression: " + xy.Key);
                    Console.WriteLine(query);
                }
            }
            return 20;
        }
        void conExit() {
            Console.WriteLine("\n\nPress any key to return...");
           // Console.ReadKey(true);
            return;
        }
        void DisplayMenu()
        {
            Console.Clear();
            Console.WriteLine("\n\n\t\t" + appname + "\n\t\t-------------------------\n\n" + desc +"\n\n\nOptions\n--------\n\n 1.  Download & run Autoruns");
            Console.WriteLine(" 2.  Download & run Process Explorer");
            Console.WriteLine(" 3.  Run Autoruns (Offline mode)");
            Console.WriteLine(" 4.  Run Process Explorer (Offline mode)");
            Console.WriteLine(" 5.  Integrate Autoruns & Process Explorer");
            Console.WriteLine(" 6.  Use another Sysinternals tool");
            Console.WriteLine(" 7.  Integrate another Sysinternals tool");
            Console.WriteLine(" 8.  Delete any existing Sysinternals tools configuration");
            Console.WriteLine(" 9.  Browse Sysinternals-live directory");
            Console.WriteLine(" 10. Restart Sysintegrator");
            Console.WriteLine(" 11. About");
            Console.WriteLine(" 12. Exit");

        }
        bool CheckForInternetConnection()
        {
            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
            catch
            {
                Console.Clear();
                Console.WriteLine("\n\n ** Error: internet access is required to perform this action");
                conExit();
                return false;
            }
        }
        void IntegrateTool(string fName) {
            string filters = "Executables|*.exe;*.cmd;*.bat;*.com;*.vbs;*.ps1";
            bool strCheck = false;
            string filePath = null;
            string ParentDir = null;
            string extType = null;
            string alias = null;
            string filename = null;
            if (fName == "Autoruns")
            {
                    if (File.Exists(auPath))
                        filePath = auPath;
                    else
                    {
                        Console.WriteLine(" ** Error: File not Found: " + auPath);
                        return;
                    }
            }
            if (fName == "Process Explorer") {
                    if (File.Exists(pePath))
                        filePath = pePath;
                    else
                    {
                        Console.WriteLine(" ** Error: File not Found: " + pePath);
                        return;
                    }
            }
            if (fName == "Custom") {
                OpenFileDialog sel = new OpenFileDialog();
                sel.Title = "Browse File";
                sel.Filter = filters;
                sel.CheckFileExists = true;
                DialogResult res = sel.ShowDialog();
                if (res == DialogResult.OK)
                {
                    filePath = sel.FileName;
                }
                else
                    return;
            }
            ParentDir = filePath.Substring(0, filePath.LastIndexOf(@"\"));
            extType = filePath.Substring(filePath.LastIndexOf("."));
            filename = filePath.Substring(filePath.LastIndexOf(@"\") + 1);
            Console.Clear();
            int r = PostQuery("\n\nWould you like to use a custom Alias for " + filename + "? (y/n)");
            if (r == 0)
            {
                while (strCheck == false)
                {
                    Console.WriteLine("\nEnter new alias for " + filename + ": ");
                    alias = Console.ReadLine();
                    if (alias.Contains(" ") == true)
                        Console.WriteLine(" ** Error: Alias cannot contain spaces or special characters or sysmbols. just a single Word of plain text");
                    else
                    {
                        if (!alias.Contains(".exe"))
                            alias = alias + ".exe";
                        strCheck = true;
                    }
                }
            }
            else alias = filename;
            Console.Clear();
            Console.WriteLine("\n\nFile Name: " + filename);
            Console.WriteLine("Path: " + ParentDir);
            Console.WriteLine("Extension: " + extType);
            Console.WriteLine("Environment Alias: " + alias);
            try
            {
                string n = (string)Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + alias).GetValue("");
                int res = PostQuery("\n\n ** Error: an Object already exists with the name: " + alias + ", you can either override it (or) use another alias.\n\nWould you like to override it? (y/n)");
                if (res == 0)
                {
                    Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + alias).Close();
                    Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + alias, true).SetValue("", filePath);
                    Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + alias, true).SetValue("Path", ParentDir + @"\");
                    Console.WriteLine(" ** Set environment alias.....Success\nDONE");
                }
            }
            catch (NullReferenceException e) {
                Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + alias).Close();
                Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + alias, true).SetValue("", filePath);
                Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\" + alias, true).SetValue("Path", ParentDir + @"\");
                Console.WriteLine(" ** Set environment alias.....Success\nDONE");
            }
            conExit();
        }
        bool SysinternalsLive() {
            WebRequest request = WebRequest.Create("http://live.sysinternals.com");
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            if (response == null || response.StatusCode != HttpStatusCode.OK) {
                Console.Clear();
            Console.WriteLine(" ** There was an error resolving the web address: http://live.sysinternals.com \nThe website was either not found (or) currently unavailable. please try again later.");
            return false;
            }
            else
                return true;
        }
        string ToolExistsNetPath(string Executable) {
            bool ExistsinRoot = false;
            bool ExistsinToolDir = false;
            WebRequest RootDirCheck = WebRequest.Create("http://live.sysinternals.com/" + Executable);
            WebRequest ToolDirCheck = WebRequest.Create("http://live.sysinternals.com/Tools/" + Executable);
            try
            {
                Console.WriteLine("Receiving Response from server...");
                using (HttpWebResponse RootResponse = (HttpWebResponse)RootDirCheck.GetResponse()) { ExistsinRoot = true;
                    Console.WriteLine("**File found on Root directory"); }
            }
            catch (Exception e) {
                if (e.Message.Contains("Not found")) {
                    ExistsinRoot = false;
                }
            }
            try
            {
                Console.WriteLine("Receiving Response from server...");
                using (HttpWebResponse ToolDirResponse = (HttpWebResponse)ToolDirCheck.GetResponse()) {
                    ExistsinToolDir = true;
                        Console.WriteLine("**File found in <tools> directory"); }
            }
            catch (Exception e)
            {
                if (e.Message.Contains("Not found"))
                {
                    ExistsinToolDir = false;
                }
            }
            if (ExistsinToolDir == false && ExistsinRoot == false)
            {
                return "fourzerofour";
            }
            else if (ExistsinRoot ==true)
                return "Root";
            else if (ExistsinToolDir == true)
                return "ToolDir";
            else
                return null;
        }
        void DownloadTool(string Tool, bool UseShadowCopy, string CustomToolRefName)
        {
                string sPath = null;
                string apath = bin + @"\autoruns64.exe";
                string apath32 = bin + @"\autoruns.exe";
                string ppath = bin + @"\procexp64.exe";
                string ppath32 = bin + @"\procexp.exe";
            WebClient client = new WebClient();
            WebRequest.DefaultWebProxy = null;
                if (Tool == "Autoruns")
                {
                    if (UseShadowCopy == true)
                    {
                        switch (arch)
                        {
                            case 0:
                                Console.Clear();
                                Console.WriteLine("\n\n ** Fatal error occured, Unknown architecture: " + arch + "\n\n Press any key to exit...");
                                Console.ReadKey(true);
                                Environment.Exit(0);
                                break;
                            case 32:
                                if (!File.Exists(apath32))
                                {
                                    Console.Clear();
                                    Console.WriteLine(" ** Error: File not found: " + apath32);
                                    conExit();
                                    return;
                                }
                                sPath = apath32;
                                break;
                            case 64:
                                if (!File.Exists(apath))
                                {
                                    Console.Clear();
                                    Console.WriteLine(" ** Error: File not found: " + apath);
                                    conExit();
                                    return;
                                }
                                sPath = apath;
                                break;
                        }
                    Console.Clear();
                    int res = PostQuery("\n\nWould you like to add initial configuration? (y/n)");
                    if (res == 0)
                    {
                        Console.WriteLine(" ** Writing configuration for autoruns...");
                        WriteConfig("Autoruns");
                    }
                    Console.WriteLine(" ** Starting " + sPath);
                    Process.Start(sPath);
                    conExit();
                }
                    else {
                    if (CheckForInternetConnection() && SysinternalsLive())
                    {
                        switch (arch)
                        {
                            case 0:
                                Console.Clear();
                                Console.WriteLine("\n\n ** Fatal error occured, Unknown architecture: " + arch + "\n\n Press any key to exit...");
                                Console.ReadKey(true);
                                Environment.Exit(0);
                                break;
                            case 32:
                                Console.Clear();
                                Console.WriteLine(" ** Connecting to https://live.sysinternals.com/...\n ** Sending GET\nDownloading autoruns.exe.....(~700k)\nPlease wait...");
                                client.DownloadFile("https://live.sysinternals.com/autoruns.exe", apath32);
                                Console.WriteLine(" ** GET OK\nDownloaded to: '" + apath32 + "'");
                                sPath = apath32;
                                break;
                            case 64:
                                Console.Clear();
                                Console.WriteLine(" ** Connecting to https://live.sysinternals.com/...\n ** Sending GET\nDownloading autoruns64.exe.....(~825k)\nPlease wait...");
                                client.DownloadFile("https://live.sysinternals.com/autoruns64.exe", apath);
                                Console.WriteLine(" ** GET OK\nDownloaded to: '" + apath + "'");
                                sPath = apath;
                                break;
                        }
                        int res = PostQuery("\n\nWould you like to add initial configuration? (y/n)");
                        if (res == 0)
                        {
                            Console.WriteLine(" ** Writing configuration for autoruns...");
                            WriteConfig("Autoruns");
                        }
                        Console.WriteLine("Starting " + sPath);
                        Process.Start(sPath);
                        conExit();
                    }
                    }
                }
                if (Tool == "Process Explorer")
                {
                if (UseShadowCopy == true)
                {
                    switch (arch)
                    {
                        case 0:
                            Console.Clear();
                            Console.WriteLine("\n\n ** Fatal error occured, Unknown architecture: " + arch + "\n\n Press any key to exit...");
                            Console.ReadKey(true);
                            Environment.Exit(0);
                            break;
                        case 32:
                            if (!File.Exists(ppath32))
                            {
                                Console.Clear();
                                Console.WriteLine(" ** Error: File not found: " + ppath32);
                                conExit();
                                return;
                            }
                            sPath = ppath32;
                            break;
                        case 64:
                            if (!File.Exists(ppath))
                            {
                                Console.Clear();
                                Console.WriteLine(" ** Error: File not found: " + ppath);
                                conExit();
                                return;
                            }
                            sPath = ppath;
                            break;
                    }
                    int res = PostQuery("\n\nWould you like to add initial configuration? (y/n)");
                    if (res == 0)
                    {
                        Console.WriteLine(" ** Writing configuration for Process Explorer...");
                        WriteConfig("Process Explorer");
                    }
                    Console.WriteLine(" ** Starting " + sPath);
                    Process.Start(sPath);
                    conExit();
                }
                else {
                    if (CheckForInternetConnection() && SysinternalsLive())
                    {
                        switch (arch)
                        {
                            case 0:
                                Console.Clear();
                                Console.WriteLine("\n\n ** Fatal error occured, Unknown architecture: " + arch + "\n\n Press any key to exit...");
                                Console.ReadKey(true);
                                Environment.Exit(0);
                                break;
                            case 32:
                                Console.Clear();
                                Console.Clear();
                                Console.WriteLine(" ** Connecting to https://live.sysinternals.com/...\n ** Sending GET\nDownloading procexp.exe.....(~2648k)\nPlease wait...");
                                client.DownloadFile("https://live.sysinternals.com/procexp.exe", ppath32);
                                Console.WriteLine("GET OK\nDownloaded to: '" + ppath32 + "'");
                                sPath = ppath32;
                                break;
                            case 64:
                                Console.Clear();
                                Console.Clear();
                                Console.WriteLine(" ** Connecting to https://live.sysinternals.com/...\n ** Sending GET\nDownloading procexp64.exe.....(~1419k)\nPlease wait...");
                                client.DownloadFile("https://live.sysinternals.com/procexp64.exe", ppath);
                                Console.WriteLine(" ** GET OK\n ** Downloaded to: '" + ppath + "'");
                                sPath = ppath;
                                break;
                        }
                        int res = PostQuery("\n\nWould you like to add initial configuration? (y/n)");
                        if (res == 0)
                        {
                            Console.WriteLine(" ** Writing configuration for Process Explorer...");
                            WriteConfig("Process Explorer");
                        }
                        Console.WriteLine(" ** Starting " + sPath);
                        Process.Start(sPath);
                        conExit();
                    }
                }
                }
                if (Tool == "Custom") {
                Console.WriteLine("\n\n**Checking...");
                if (CheckForInternetConnection() && SysinternalsLive())
                {
                    Console.WriteLine("**Connection Verified.");
                    if (ToolExistsNetPath(CustomToolRefName) == "Root")
                    {
                        Console.WriteLine(" ** Connecting to https://live.sysinternals.com/...\n ** Sending GET\nDownloading " + CustomToolRefName + ".....\nPlease wait...");
                        client.DownloadFile("http://live.sysinternals.com/" + CustomToolRefName, bin + @"\" + CustomToolRefName);
                        Console.WriteLine(" ** DONE\n ** Saved to: " + bin + @"\" + CustomToolRefName);
                        int res = PostQuery("\nWould you like to open " + CustomToolRefName + "? (y/n)");
                        if (res == 0)
                        {
                            Console.WriteLine(" ** Starting " + bin + @"\" + CustomToolRefName);
                            Process.Start(bin + @"\" + CustomToolRefName);
                        }
                    }
                    else if (ToolExistsNetPath(CustomToolRefName) == "ToolDir")
                    {
                        Console.WriteLine(" ** Connecting to https://live.sysinternals.com/...\n ** Sending GET\nDownloading " + CustomToolRefName + ".....\nPlease wait...");
                        client.DownloadFile("http://live.sysinternals.com/tools/" + CustomToolRefName, bin + @"\" + CustomToolRefName);
                        Console.WriteLine(" ** DONE\n ** Saved to: " + bin + @"\" + CustomToolRefName);
                        int res = PostQuery("\nWould you like to open: " + CustomToolRefName + "? (y/n)");
                        if (res == 0)
                        {
                            Console.WriteLine(" ** Starting " + bin + @"\" + CustomToolRefName);
                            Process.Start(bin + @"\" + CustomToolRefName);
                        }
                    }
                    else if (ToolExistsNetPath(CustomToolRefName) == "fourzerofour") {
                        Console.WriteLine("\n\n**Error: " + CustomToolRefName + " does not exist.");
                    }
                }
                conExit();
            }
        }
        
        
        [STAThread]
        static void Main(string[] args)
        {
            Console.Title = "Sysintegrator for Windows";
            
            Program npObj = new Program();
            npObj.home = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            npObj.home += @"\Sysintegrator";
            npObj.bin = npObj.home + @"\bin";
            npObj.apath = npObj.bin + @"\autoruns64.exe";
            npObj.apath32 = npObj.bin + @"\autoruns.exe";
            npObj.ppath = npObj.bin + @"\procexp64.exe";
            npObj.ppath32 = npObj.bin + @"\procexp.exe";
            Directory.CreateDirectory(npObj.bin);
            RegistryKey rkIdentifier = Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0");
            if (rkIdentifier.GetValue("Identifier").ToString().IndexOf("64") > 0) npObj.arch = 64;
            else if (rkIdentifier.GetValue("Identifier").ToString().IndexOf("86") > 0 || rkIdentifier.GetValue("Identifier").ToString().IndexOf("32") > 0) npObj.arch = 32;
            else npObj.arch = 0;
            if (npObj.arch == 32) {
                npObj.auPath = npObj.apath32;
                npObj.pePath = npObj.ppath32;
            }
            else if (npObj.arch == 64) {
                npObj.auPath = npObj.apath;
                npObj.pePath = npObj.ppath;
            }
            do
            {
                npObj.DisplayMenu();
                Console.WriteLine("\nSelect>");
                string c = Console.ReadLine();
                c = c.Trim();
                switch (c)
                {
                    case "1":
                        Console.Clear();
                        Console.WriteLine("Please wait...");
                        npObj.DownloadTool("Autoruns", false, null);
                        break;
                    case "2":
                        Console.Clear();
                        Console.WriteLine("Please wait...");
                        npObj.DownloadTool("Process Explorer", false, null);
                        break;
                    case "3":
                        npObj.DownloadTool("Autoruns", true, null);
                        break;
                    case "4":
                        npObj.DownloadTool("Process Explorer", true, null);
                        break;
                    case "5":
                        npObj.IntegrateTool("Autoruns");
                        npObj.IntegrateTool("Process Explorer");
                        break;
                    case "6":
                        Console.Clear();
                        Console.WriteLine("\n\nDownload Tool:\n---------------\n\nEnter the file name: \n(Note: file extension must be specified)\n(example: autoruns.exe)");
                        string RefName = Console.ReadLine();
                        npObj.DownloadTool("Custom", false, RefName);
                        break;
                    case "7":
                        npObj.IntegrateTool("Custom");
                        break;
                    case "8":
                        npObj.RemoveExistingConfig();
                        break;
                    case "9":
                        Process.Start("https://live.sysinternals.com");
                        break;
                    case "10":
                        Application.Restart();
                        Environment.Exit(0);
                        break;
                    case "11":
                        

                        Sysintegrator.about ab = new Sysintegrator.about();
                        ab.ShowDialog();
                        
                        
                        break;
                    case "12":
                        Environment.Exit(0);
                        break;
                   
                }

            } while (Console.ReadKey(true).Key != ConsoleKey.Escape);
            Environment.Exit(0);
        }
    }
}
