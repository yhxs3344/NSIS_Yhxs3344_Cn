﻿/*

The MIT License (MIT)
---------------------

Sysintegrator

Copyright © 2018 cyfrost <cyrus.frost@hotmail.com>

Permission is hereby granted, free of charge, to any person obtaining 
a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies
or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR AND CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

*/



using System;
using System.Drawing;
using System.Windows.Forms;

namespace Sysintegrator
{
    public partial class about : Form
    {
        private static Sysinternals_Integrator.Program ob = new Sysinternals_Integrator.Program();
        public about()
        {
            InitializeComponent();
            richTextBox1.KeyDown += delegate(object sender, KeyEventArgs e) { if (e.KeyCode == Keys.Enter) Close(); };
            appname.Text = ob.appname;
            build.Text = "version " + ob.version;
            author.Text = ob.copyright;
            button1.Select();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void about_Load(object sender, EventArgs e)
        {
            richTextBox1.BackColor = Color.White;
            this.Focus();
            button1.Focus();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
