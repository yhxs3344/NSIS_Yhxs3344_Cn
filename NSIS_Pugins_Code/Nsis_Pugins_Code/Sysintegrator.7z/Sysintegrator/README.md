# Sysintegrator

[![build_status](https://img.shields.io/badge/build-passing-brightgreen.svg)](https://github.com/cyfrost/Sysintegrator/releases/latest)
[![GitHub release](https://img.shields.io/badge/current%20release-v0.1-blue.svg)](https://github.com/cyfrost/Sysintegrator/releases/latest)
[![license](https://img.shields.io/badge/license-MIT-orange.svg)](https://github.com/cyfrost/Sysintegrator/blob/master/LICENSE)
[![HitCount](http://hits.dwyl.com/cyfrost/Sysintegrator.svg)](http://hits.dwyl.com/cyfrost/Sysintegrator)

Use latest Windows Sysinternals tools with additional features.


## Download

Download the latest release from [here](https://github.com/cyfrost/Sysintegrator/releases/latest).

Compatible from Windows XP through 10.


## Screencaps

![img](https://i.imgur.com/IIYRqYm.png)


## Build Instructions

Use Visual Studio 2012 or higher.


## License

Copyright (c) 2018 cyfrost.

Licensed under the [MIT License](https://github.com/cyfrost/Sysintegrator/blob/master/LICENSE).
