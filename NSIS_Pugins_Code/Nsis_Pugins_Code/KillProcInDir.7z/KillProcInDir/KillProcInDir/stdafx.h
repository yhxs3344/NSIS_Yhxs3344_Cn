#ifndef __STDAFX_H__
#define __STDAFX_H__

#include <windows.h>
#include "exdll.h"

#endif