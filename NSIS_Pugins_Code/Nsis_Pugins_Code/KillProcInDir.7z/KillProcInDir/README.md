# KillProcInDir
A NSIS plugin which can kill processes launched from a given directory.
https://github.com/Wunf/KillProcInDir