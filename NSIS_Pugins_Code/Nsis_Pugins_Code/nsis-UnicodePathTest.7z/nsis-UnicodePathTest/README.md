NSIS Unicode Path Test plugin with added support to distinguish paths that fit into CP_ACP from 'full' Unicode ones.

