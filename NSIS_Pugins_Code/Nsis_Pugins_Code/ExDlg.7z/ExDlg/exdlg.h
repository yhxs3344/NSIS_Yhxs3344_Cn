// exdlg.h
// Peter Windridge 2001.

#define DIR_BROWSE_CLASS "_dirbrowse"
#define FILE_BROWSE_CLASS "_filebrowse"

