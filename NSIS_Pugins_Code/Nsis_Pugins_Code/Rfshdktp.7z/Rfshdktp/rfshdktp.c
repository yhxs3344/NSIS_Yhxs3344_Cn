#include <windows.h>
#include <shlobj.h>
#include "..\exdll\exdll.h"


HINSTANCE g_hInstance;

HWND g_hwndParent;

void __declspec(dllexport) refreshDesktop(HWND hwndParent, int string_size, 
                                      char *variables, stack_t **stacktop)
{
  g_hwndParent=hwndParent;

  EXDLL_INIT();

  // Usage:

  // rfshdktp::refreshDesktop

  {
	LPITEMIDLIST  pIDList; // Pointer to the Item Identifier List
    SHGetSpecialFolderLocation(NULL, CSIDL_DESKTOP, &pIDList);
    SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, pIDList,0);
  }
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
  g_hInstance=hInst;
	return TRUE;
}
