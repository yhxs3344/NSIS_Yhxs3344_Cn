ToolTips 1.0

Functions:

a) Classic: Typical Win32 Tooltips style.
b) Modern: Ballon style of the tooltip will be display (Need Internet Explorer 5.x).

See example "ToolTips.nsi"
