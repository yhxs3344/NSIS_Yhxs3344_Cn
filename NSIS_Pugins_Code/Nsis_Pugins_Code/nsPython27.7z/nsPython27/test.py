import nsis
nsis.log("code file")
