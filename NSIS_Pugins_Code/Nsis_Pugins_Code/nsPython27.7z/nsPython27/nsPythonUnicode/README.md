nsPythonUnicode
===============

nsPythonUnicode plugin for [Unicode NSIS](http://www.scratchpaper.com/).

Based on: [NsPython](http://nsis.sourceforge.net/NsPython_plug-in)

How to compile
==============

You can compile this project using Visual Studio.
Set up include path and library path to your local instance of Python.

Build dll file.

Download binary
===============

nsPythonUnicode.dll is available aslo for [download](http://georgik.sinusgear.com/wp-content/nsis/nsPythonUnicode.zip).
You need to add also msvcr100.dll.

How to call functions from NSIS
===============================

nsPythonUnicode::exec "import this"


