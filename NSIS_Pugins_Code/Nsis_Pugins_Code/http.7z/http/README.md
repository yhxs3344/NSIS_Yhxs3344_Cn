# nsis-http
NSIS installer plug-in to make HTTP requests
