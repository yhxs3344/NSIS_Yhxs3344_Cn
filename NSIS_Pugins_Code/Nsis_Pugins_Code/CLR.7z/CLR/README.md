# NSIS CLR Loader - v0.5

A NSIS plugin to Load CLR assemblies (.NET Framework) and run methods on classes

Currently in an early stage of development, but will be a very active project.  

You can also check out the [original source](http://nsis.sourceforge.net/Call_.NET_DLL_methods_plug-in)

