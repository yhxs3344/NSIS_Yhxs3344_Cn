# NSIS-ApplicationID
NSIS Plugin for setting ApplicationID on shortcuts

Fork of initial ApplicationID plugin by Mike Anchor/jmathies