NSIS Automatic File List Generator
===============

This tool helps adding to NSIS project multiple files very quickly.  
By using a GUI it allows recursive directory listing.  

===============  

Download: [NSIS FileSeeker.exe](https://github.com/ogero/NSIS-FileSeeker/raw/master/Output/MingW/NSIS%20FileSeeker.exe)  
![image](https://raw.githubusercontent.com/ogero/NSIS-FileSeeker/master/screenshot.png)
