NsisPackage
=======
https://github.com/pile-contributors/nsispackage
https://github.com/pile-contributors/nsispackage-helpers
NsisPackage pile.
