## NSIS pcre
###### An NSIS plugin providing Perl compatible regular expression functions unicode and ansi, x64 and x86.
https://github.com/mazinsw/NSISpcre
This plugin was compiled using Falcon C++ 3.3 rc

The pcre source code is available separately from http://www.pcre.org/.

## License

Please see the [license file](/LICENSE) for more information.