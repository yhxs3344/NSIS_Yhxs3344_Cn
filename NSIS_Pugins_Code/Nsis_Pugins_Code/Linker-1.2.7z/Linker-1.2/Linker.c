#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "nsis/pluginapi.h"

// Linker 1.2 by Slappy (graphical-installer.com)
// Added Visual Studio 2010 solution and project (in VC10 directory)
// Added transparent background for text

// URL control from http://catch22.net/tuts/urlctrl.asp
#include "URLCtrl.h"


void __declspec(dllexport) Link(HWND hwndParent, int string_size, 
                                TCHAR *variables, stack_t **stacktop,
                                extra_parameters *extra)
{
  EXDLL_INIT();

  {
    TCHAR szURL[1024];
    HWND hwLabel;

    hwLabel = (HWND) popint();
    
    if (popstring(szURL))
      return;

    if (hwLabel == NULL)
      return;

    urlctrl_set(hwLabel , szURL, NULL, NULL, UCF_KBD | UCF_FIT);
  }
}

void __declspec(dllexport) Unload(HWND hwndParent, int string_size, 
                                  TCHAR *variables, stack_t **stacktop,
                                  extra_parameters *extra)
{
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}
