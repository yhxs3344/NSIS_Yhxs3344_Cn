# IpConfig2
https://github.com/arielvega/IpConfig2
A new version of the old IpConfig Plugin for NSIS

Original documentation: https://nsis.sourceforge.io/IpConfig_plugin

Original files: https://nsis.sourceforge.io/mediawiki/images/c/c1/IpConfig.zip

Thanks to the work by [JPdeRuiter](http://forums.winamp.com/member.php?s=6f1e68ae0ed0802de6d7e3395b229453&u=220722 "JPdeRuiter Profile on WinAmp Forum") to make the awesome original plugin
