
#define IDD_DLGZIP1            101
#define IDD_DLGZIP2            102

#define IDD_POPUP              201

#define IDC_ZIPINFO           1000
#define IDC_ZIPPROG           1001
#define IDC_CANCELZIP         1002
