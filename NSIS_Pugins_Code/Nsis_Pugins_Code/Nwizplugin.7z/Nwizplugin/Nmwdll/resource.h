
#define IDD_DLGNSIS            101

#define IDC_OUTPUTTEXT         1001
