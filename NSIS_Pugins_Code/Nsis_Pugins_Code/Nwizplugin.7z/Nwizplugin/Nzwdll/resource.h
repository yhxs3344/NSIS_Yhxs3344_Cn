#define PERCENT
//#define PROG_BAR

#define IDD_DLGNSIS            101
#define IDD_DLGZIP             102

#define IDD_POPUP              201

#ifndef PROG_BAR
 #define IDC_ZIPINFO            1000
#endif
#define IDC_OUTPUTTEXT         1001
#define IDC_CANCELZIP          1002

#ifdef PROG_BAR
 #define IDC_ZIPPROG           1000
#endif
