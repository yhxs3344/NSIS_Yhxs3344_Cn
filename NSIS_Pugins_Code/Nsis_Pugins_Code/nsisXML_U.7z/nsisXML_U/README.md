nsisXML
https://github.com/WayneFei/nsisXML