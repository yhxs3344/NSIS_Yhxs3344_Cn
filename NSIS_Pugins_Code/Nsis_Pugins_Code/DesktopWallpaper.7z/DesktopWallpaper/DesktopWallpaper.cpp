#include <vector>

#include <windows.h>
#include <shlobj.h>
#include <shlwapi.h>
#pragma comment(lib, "shlwapi.lib")

#include "nsis/plugin.h"

static HMODULE g_hModule = nullptr;

static UINT_PTR PluginCallback(NSPIM msg)
{
	return 0;
}

static HRESULT IDW_SetPosition(UINT wallpaperPosition)
{
	HRESULT hr;

	IDesktopWallpaper *pdw = nullptr;
	hr = CoCreateInstance(CLSID_DesktopWallpaper, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&pdw));
	if (hr == S_OK)
	{
		hr = pdw->SetPosition(static_cast<DESKTOP_WALLPAPER_POSITION>(wallpaperPosition));
		pdw->Release();
	}

	return hr;
}

static HRESULT IDW_SetWallpaper(LPCWSTR pszWallpaper, POINT pt, BOOL bAllMonitors)
{
	HRESULT hr;

	IDesktopWallpaper *pdw = nullptr;
	hr = CoCreateInstance(CLSID_DesktopWallpaper, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&pdw));
	if (hr == S_OK)
	{
		UINT nMonitors;
		hr = pdw->GetMonitorDevicePathCount(&nMonitors);
		if ((hr == S_OK) && (nMonitors > 1) && !bAllMonitors)
		{
			BOOL bResult = FALSE;
			for (UINT nIndex = 0; !bResult && (nIndex < nMonitors); nIndex++)
			{
				PWSTR pwszMonitor = nullptr;
				hr = pdw->GetMonitorDevicePathAt(nIndex, &pwszMonitor);
				if (hr == S_OK)
				{
					RECT rc = { 0 };
					hr = pdw->GetMonitorRECT(pwszMonitor, &rc);
					if ((hr == S_OK) && (bResult = PtInRect(&rc, pt)))
					{
						hr = pdw->SetWallpaper(pwszMonitor, pszWallpaper);
					}
					CoTaskMemFree(pwszMonitor);
				}
			}
			if (!bResult)
			{
				hr = pdw->SetWallpaper(nullptr, pszWallpaper);
			}
		}
		else
		{
			hr = pdw->SetWallpaper(nullptr, pszWallpaper);
		}

		pdw->Release();
	}

	return hr;
}

static HRESULT IDW_SetSlideshow(IShellItemArray *psia, LONG nMillis)
{
	HRESULT hr;

	IDesktopWallpaper *pdw = nullptr;
	hr = CoCreateInstance(CLSID_DesktopWallpaper, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&pdw));
	if (hr == S_OK)
	{
		hr = pdw->SetSlideshow(psia);
		if (hr == S_OK)
		{
			DESKTOP_SLIDESHOW_OPTIONS slideshowOptions;
			UINT nTickCount;
			hr = pdw->GetSlideshowOptions(&slideshowOptions, &nTickCount);
			if (hr == S_OK)
			{
				hr = pdw->SetSlideshowOptions(slideshowOptions, (nMillis > 0) ? nMillis : nTickCount);
			}
			else
			{
				hr = pdw->SetSlideshowOptions(static_cast<DESKTOP_SLIDESHOW_OPTIONS>(0), nMillis);
			}
		}
		pdw->Release();
	}

	return hr;
}

EXTERN_C __declspec(dllexport) void __cdecl SetPosition(HWND hwndParent, int nLength, TCHAR *var, stack_t **stacktop, extra_parameters *extra)
{
	extra->RegisterPluginCallback(g_hModule, PluginCallback);
	if (stacktop != nullptr)
	{
		if (*stacktop != nullptr)
		{
			stack_t *th = *stacktop;
			IDW_SetPosition(StrToInt(th->text));
			*stacktop = th->next;
			GlobalFree(th);
		}
	}
}

EXTERN_C __declspec(dllexport) void __cdecl SetWallpaper(HWND hwndParent, int nLength, TCHAR *var, stack_t **stacktop, extra_parameters *extra)
{
	extra->RegisterPluginCallback(g_hModule, PluginCallback);
	if (stacktop != nullptr)
	{
		WCHAR szPath[MAX_PATH];
		DWORD cchPath = ARRAYSIZE(szPath);
		BOOL bAllMonitor = FALSE;

		if (*stacktop != nullptr)
		{
			stack_t *th = *stacktop;
#if !defined(UNICODE) && !defined(_UNICODE)
			MultiByteToWideChar(CP_ACP, 0, th->text, -1, szPath, cchPath);
#else
			StrCpyNW(szPath, th->text, cchPath);
#endif
			*stacktop = th->next;
			GlobalFree(th);
		}

		if (*stacktop != nullptr)
		{
			stack_t *th = *stacktop;
			bAllMonitor = StrToInt(th->text);
			*stacktop = th->next;
			GlobalFree(th);
		}

		if (IsWindow(hwndParent))
		{
			if (IsWindowVisible(hwndParent))
			{
				RECT rc = { 0 };
				if (GetWindowRect(hwndParent, &rc))
				{
					POINT pt = { (rc.left + rc.right) / 2, (rc.top + rc.bottom) / 2 };
					IDW_SetWallpaper(szPath, pt, bAllMonitor);
				}
			}
			else
			{
				WINDOWPLACEMENT wndpl = { 0 };
				wndpl.length = sizeof(wndpl);
				if (GetWindowPlacement(hwndParent, &wndpl))
				{
					POINT pt = { (wndpl.rcNormalPosition.left + wndpl.rcNormalPosition.right) / 2, (wndpl.rcNormalPosition.top + wndpl.rcNormalPosition.bottom) / 2 };
					IDW_SetWallpaper(szPath, pt, bAllMonitor);
				}
			}
		}
		else
		{
			POINT pt = { 0 };
			if (GetCursorPos(&pt))
			{
				IDW_SetWallpaper(szPath, pt, bAllMonitor);
			}
		}
	}
}

EXTERN_C __declspec(dllexport) void __cdecl SetSlideshow(HWND hwndParent, int nLength, TCHAR *var, stack_t **stacktop, extra_parameters *extra)
{
	extra->RegisterPluginCallback(g_hModule, PluginCallback);
	if (stacktop != nullptr)
	{
		WCHAR szPath[MAX_PATH];
		DWORD cchPath = ARRAYSIZE(szPath);
		LONG nMillis = 0;

		if (*stacktop != nullptr)
		{
			stack_t *th = *stacktop;
#if !defined(UNICODE) && !defined(_UNICODE)
			MultiByteToWideChar(CP_ACP, 0, th->text, -1, szPath, cchPath);
#else
			StrCpyNW(szPath, th->text, cchPath);
#endif
			*stacktop = th->next;
			GlobalFree(th);
		}

		if (*stacktop != nullptr)
		{
			stack_t *th = *stacktop;
			nMillis = StrToInt(th->text);
			*stacktop = th->next;
			GlobalFree(th);
		}

		ITEMIDLIST *pidl = nullptr;
		HRESULT hr = SHParseDisplayName(szPath, nullptr, &pidl, 0, nullptr);
		if (hr == S_OK)
		{
			IShellItem *psi = nullptr;
			hr = SHCreateItemFromIDList(pidl, IID_PPV_ARGS(&psi));
			CoTaskMemFree(pidl);
			if (hr == S_OK)
			{
				IShellItemArray *psia = nullptr;
				hr = SHCreateShellItemArrayFromShellItem(psi, IID_PPV_ARGS(&psia));
				psi->Release();
				if (hr == S_OK)
				{
					IDW_SetSlideshow(psia, nMillis);
					psia->Release();
				}
			}
		}
	}
}

EXTERN_C BOOL CALLBACK _DllMainCRTStartup(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	switch (fdwReason) {
	case DLL_PROCESS_ATTACH:
		g_hModule = hinstDLL;
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		return TRUE;
	default:
		return TRUE;
	}
}
