NSISPlugin: Boilerplate Code for NSIS Plugin development. 

## Compile from source

Visual Studio 2013 Update 4 is required. To compile the source code run the following command:

```
build.bat
```

## References

* [Cannot open libc.lib](http://forums.winamp.com/showthread.php?s=&threadid=302413)
