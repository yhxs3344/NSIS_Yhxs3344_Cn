#pragma once

#include <windows.h>
#include <CommCtrl.h>
#include <stdio.h>
#include "nsis\pluginapi.h"
	

void DetailPrint(HWND hwndParent, char* line)
{
	LVITEM lvi = { 0 };  // Listbox structure
	HWND handle = NULL; // Handle to the listbox
	int count = 0;   // Number of lines in the Status listbox

	handle = FindWindowEx(hwndParent, NULL, "#32770", "");	// Find the Dialog Window
	handle = GetDlgItem(handle, 1016); // Get a handle to the listbox control
	count = SendMessage(handle, LVM_GETITEMCOUNT, 0, 0); // Get the number of lines already in the listbox

	memset (&lvi, 0, sizeof(lvi)); // Init listbox structure
	lvi.mask = LVIF_TEXT;
	lvi.iItem = count;
	lvi.pszText=line;

	SendMessage (handle, LVM_INSERTITEM, 0, (LPARAM)&lvi);	// Add LogString to the listbox
	SendMessage (handle, LVM_ENSUREVISIBLE, (WPARAM)count, (LPARAM)FALSE); // Scroll down
}