#include <windows.h>
#include "nsis\pluginapi.h"
#include "DetailPrint.h"

// Helper macros for NSIS plugin function exports
#define NSISFunction(NAME) \
  extern "C" void __declspec(dllexport) NAME(HWND hwndParent, int string_size, char* variables,stack_t** stacktop, extra_parameters* extra)

#define NSISInit() \
   { g_stringsize=string_size; g_stacktop=stacktop; g_variables=variables; g_hwndParent=hwndParent; extra->RegisterPluginCallback(g_hInstance, PluginCallback); }

HINSTANCE g_hInstance = NULL;
HWND g_hwndParent = NULL;

// Callback registered with extra_parameters->RegisterPluginCallback()
// NSIS calls this method before the plugin is unloaded. This is a good
// place to free the resources that the plugin may have acquired during 
// its lifetime.
static UINT_PTR PluginCallback(enum NSPIM msg)
{
	switch (msg)
	{
	case NSPIM::NSPIM_UNLOAD:
		// This is the last message a plugin gets, do final cleanup
		break;
	case NSPIM::NSPIM_GUIUNLOAD:
		// Called after .onGUIEnd
		break;
	}
	// Return value is ignored by NSIS
	return NULL;
}

// TODO: This is a sample function. Replace it with your own.
NSISFunction(alert)
{
	NSISInit();

	char buf[1024] = { 0 };
	popstringn(buf,1024);
	DetailPrint(g_hwndParent, buf);
    //MessageBox(g_hwndParent,buf,0,MB_OK);
	pushstring("Plugin Return Text");
}

// Main entry point for DLL. When the system starts or terminates a process or 
// thread, it calls the entry-point function for each loaded DLL using the 
// first thread of the process. The system also calls the entry-point function 
// for a DLL when it is loaded or unloaded using the LoadLibrary and FreeLibrary functions.
extern "C" BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		// A process is loading the DLL.
		break;
	case DLL_THREAD_ATTACH:
		// A process is creating a new thread.
		break;
	case DLL_THREAD_DETACH:
		// A thread exits normally.
		break;
	case DLL_PROCESS_DETACH:
		// A process unloads the DLL.
		break;
	}
	g_hInstance = (HINSTANCE)hInst;
	return TRUE;
}
