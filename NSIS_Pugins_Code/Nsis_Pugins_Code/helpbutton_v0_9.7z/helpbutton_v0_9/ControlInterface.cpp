// this file is used to allow the EmbeddedWebBrowser control to be used
// in the main 'c' source file (still to convert the header to provide both
// 'c' and 'c++' interfaces)
#include "AggressiveOptimize.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "EbeddedWebBrowser.h"
#include "ControlInterface.h"

EmbeddedWebBrowser *pHost;


void OpenWebBrowser(HWND hwnd, char* url){
	pHost = new EmbeddedWebBrowser(hwnd, url);
}

void CloseWebBrowser(){
	pHost->Release();
}

void SizeWebBrowser(HWND hwnd){
RECT rc;
	pHost->GetWindowPlace(hwnd, &rc);
	pHost->pInPlaceObject->SetObjectRects(&rc, &rc);
}