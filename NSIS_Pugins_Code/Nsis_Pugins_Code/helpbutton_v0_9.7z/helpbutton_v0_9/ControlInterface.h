#ifndef _CONTROLINTERFACE_H
#define _CONTROLINTERFACE_H

#ifdef __cplusplus
extern "C" {
#endif

void OpenWebBrowser(HWND hwnd, char* file);
void CloseWebBrowser(void);

void SizeWebBrowser(HWND hwnd);

#ifdef __cplusplus
}
#endif

#endif