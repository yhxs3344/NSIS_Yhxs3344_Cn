#ifndef _HELPBUTTON_H
#define _HELPBUTTON_H


// makes the window proc member to be correct if STRICT is defined or not
#ifdef STRICT
	#define PROC WNDPROC
#else
	#define PROC FARPROC
#endif

// menu indexes for the text window
#define	IDM_COPY		1000
#define	IDM_SELECTALL	IDM_COPY+1
#define	IDM_COPYALL		IDM_SELECTALL+1


// function prototypes where needed
LRESULT CALLBACK HookProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
BOOL CenterWindow(HWND ChildW);
BOOL RTFEDIT_OpenFile(HWND hRTF, char* file);
DWORD CALLBACK RTFEDIT_ReadStream(DWORD, LPBYTE, DWORD, LPDWORD);

unsigned int my_atoi(char *s);
void* my_memset(void* dest, int c, unsigned count);
#define ZeroMem(Destination,Length) my_memset(Destination,0,Length)


#endif