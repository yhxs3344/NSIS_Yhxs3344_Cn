#include "EbeddedWebBrowser.h"

// remove the inclusion of the crt - don't want the bloat :o)
void* operator new(size_t size){return(void*)LocalAlloc(LPTR, size);}
void operator delete(void *ptr){if(ptr){LocalFree(ptr);}}

// Gets the area of the control to fit correctly in the window passed
void EmbeddedWebBrowser::GetWindowPlace(HWND hwnd, LPRECT rc){
	GetClientRect(hwnd, rc);
	rc->right -= rc->left;
	rc->bottom -= rc->top;
	rc->left = rc->top = 0;
}

int EmbeddedWebBrowser::LocalToBSTR(BSTR pWide, LPTSTR pLocal, DWORD dwChars){
	*pWide = 0;
	#ifdef UNICODE
	lstrcpyn(pWide, pLocal, dwChars);
	#else
	MultiByteToWideChar(CP_ACP, 0, pLocal, -1, pWide, dwChars);
	#endif
	return lstrlenW(pWide);
}


EmbeddedWebBrowser::EmbeddedWebBrowser(HWND hwnd, char* url){
HRESULT ret;
IUnknown *pUnknown;            
IOleObject *pObject;
IWebBrowser2 *pWebBrowser;
RECT rc;
#define ARRAYSIZE(a)    (sizeof(a)/sizeof((a)[0]))
OLECHAR bstr[2*MAX_PATH];

    CoInitialize(0);

    m_dwRefCount = 1;
    m_hwndParent = hwnd;

    m_pClientSite = new ClientSite(this);
    m_pInPlaceSite = new InPlaceSite(this);

    ret = CoCreateInstance(CLSID_WebBrowser, NULL, CLSCTX_ALL, IID_IUnknown, (void**)(&pUnknown));

    ret = pUnknown->QueryInterface(IID_IOleObject, (void**)(&pObject));
    ret = pObject->SetClientSite(m_pClientSite);

	GetWindowPlace(hwnd, &rc);
    
    ret = pUnknown->QueryInterface(IID_IOleInPlaceObject, (void**)(&pInPlaceObject));
    ret = pInPlaceObject->SetObjectRects(&rc,&rc);
	if(pInPlaceObject){pInPlaceObject->Release();}

    ret = pObject->DoVerb(OLEIVERB_INPLACEACTIVATE,0,m_pClientSite,0,hwnd,&rc);
    pObject->Release();

	// get the WebBrowser control's interface
    ret = pUnknown->QueryInterface(IID_IWebBrowser2, (void**)&pWebBrowser);
    if(pUnknown){pUnknown->Release();}

	LocalToBSTR(bstr, url, ARRAYSIZE(bstr));

    // then open the url
    ret = pWebBrowser->Navigate(bstr/*L"F:\\Documents and Settings\\Darren\\Desktop\\NSIS\\Contrib\\HelpButton\\winampmb.htm"*/, NULL, NULL, NULL, NULL);
    if(pWebBrowser){pWebBrowser->Release();}
}

EmbeddedWebBrowser::~EmbeddedWebBrowser(){
    if(m_pClientSite) delete m_pClientSite;
    if(m_pInPlaceSite) delete m_pInPlaceSite;
	if(pInPlaceObject) delete pInPlaceObject;

    CoUninitialize();
}

ULONG STDMETHODCALLTYPE EmbeddedWebBrowser::AddRef(){return ++m_dwRefCount;}
ULONG STDMETHODCALLTYPE EmbeddedWebBrowser::Release(){
    if(!--m_dwRefCount){delete this;}
    return m_dwRefCount;
}
STDMETHODIMP EmbeddedWebBrowser::QueryInterface(REFIID riid, void ** ppvObject){
    if(ppvObject == NULL) return E_INVALIDARG;
    *ppvObject = NULL;

    if(riid == IID_IUnknown)
        *ppvObject = this;
    else if(riid == IID_IOleClientSite)
        *ppvObject = m_pClientSite;
    else if(riid == IID_IOleInPlaceSite)
        *ppvObject = m_pInPlaceSite;

    if(*ppvObject == NULL) return E_NOINTERFACE;
    AddRef();
    return S_OK;
}



ClientSite::ClientSite(EmbeddedWebBrowser* pFrameSite){m_pHost = pFrameSite;}
ClientSite::~ClientSite(){}

// IUnknown
STDMETHODIMP ClientSite::QueryInterface(REFIID iid, void ** ppvObject){return m_pHost->QueryInterface(iid, ppvObject);}
ULONG STDMETHODCALLTYPE ClientSite::AddRef(){return m_pHost->AddRef();}
ULONG STDMETHODCALLTYPE ClientSite::Release(){return m_pHost->Release();}

// IOleClientSite
STDMETHODIMP ClientSite::SaveObject(){return E_NOTIMPL;}
STDMETHODIMP ClientSite::GetMoniker(DWORD dwAssign, DWORD dwWhichMoniker, IMoniker ** ppmk){return E_NOTIMPL;}
STDMETHODIMP ClientSite::OnShowWindow(BOOL fShow){return E_NOTIMPL;}
STDMETHODIMP ClientSite::RequestNewObjectLayout(){return E_NOTIMPL;}
STDMETHODIMP ClientSite::GetContainer(LPOLECONTAINER FAR* ppContainer){return E_NOTIMPL;}
STDMETHODIMP ClientSite::ShowObject(){return S_OK;}



InPlaceSite::InPlaceSite(EmbeddedWebBrowser* pFrameSite){m_pHost = pFrameSite;}
InPlaceSite::~InPlaceSite(){}

// IUnknown
STDMETHODIMP InPlaceSite::QueryInterface(REFIID iid, void ** ppvObject){return m_pHost->QueryInterface(iid, ppvObject);}
ULONG STDMETHODCALLTYPE InPlaceSite::AddRef(){return m_pHost->AddRef();}
ULONG STDMETHODCALLTYPE InPlaceSite::Release(){return m_pHost->Release();}

// IOleWindow
HRESULT STDMETHODCALLTYPE InPlaceSite::GetWindow(HWND * phwnd){*phwnd = m_pHost->m_hwndParent; return S_OK;}
HRESULT STDMETHODCALLTYPE InPlaceSite::ContextSensitiveHelp(BOOL fEnterMode){return E_NOTIMPL;}

// IOleInPlaceSite
HRESULT STDMETHODCALLTYPE InPlaceSite::CanInPlaceActivate(void){return S_OK;}
HRESULT STDMETHODCALLTYPE InPlaceSite::OnInPlaceActivate(void){return S_OK;}
HRESULT STDMETHODCALLTYPE InPlaceSite::OnUIActivate(void){return S_OK;}
HRESULT STDMETHODCALLTYPE InPlaceSite::GetWindowContext(IOleInPlaceFrame **ppFrame,
                                                        IOleInPlaceUIWindow **ppDoc,
                                                        LPRECT lprcPosRect, LPRECT lprcClipRect,
                                                        LPOLEINPLACEFRAMEINFO lpFrameInfo){return S_OK;}
HRESULT STDMETHODCALLTYPE InPlaceSite::Scroll(SIZE scrollExtant){return E_NOTIMPL;}
HRESULT STDMETHODCALLTYPE InPlaceSite::OnUIDeactivate(BOOL fUndoable){return E_NOTIMPL;}
HRESULT STDMETHODCALLTYPE InPlaceSite::OnInPlaceDeactivate(void){return E_NOTIMPL;}
HRESULT STDMETHODCALLTYPE InPlaceSite::DiscardUndoState(void){return E_NOTIMPL;}
HRESULT STDMETHODCALLTYPE InPlaceSite::DeactivateAndUndo(void){return E_NOTIMPL;}
HRESULT STDMETHODCALLTYPE InPlaceSite::OnPosRectChange(LPCRECT lprcPosRect){return E_NOTIMPL;}
