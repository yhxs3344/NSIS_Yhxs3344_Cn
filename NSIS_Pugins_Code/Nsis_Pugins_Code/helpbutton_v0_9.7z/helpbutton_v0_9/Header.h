#ifndef _HEXDLL_H_
#define _HEXDLL_H_

#ifdef __cplusplus
extern "C" {
#endif

int WinMain2(HINSTANCE hInstance, char *htmlfile);
void main_test(char *htmlfile);
void main_test_2(HWND hwnd, char* file);
void dummy(HWND hwnd, char *htmlfile);
extern int loaded;

#ifdef __cplusplus
}
#endif

#endif