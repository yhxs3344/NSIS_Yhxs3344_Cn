//#include "AggressiveOptimize.h"	// gets the code a little bit smaller
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../exdll/exdll.h"
#include <richedit.h>
#include "ControlInterface.h"	// allows this file to access the 'c++' code
#include "HelpButton.h"

HINSTANCE g_hInstance = 0, richedit = 0;
HWND button = 0, info = 0;
BYTE registered = 0, file = 0, text_size = 0, wordwrap = 0;
PROC proc = 0;

// todo: turn into memory allocated
char window_text[1024], info_text[1024];


BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG reason, LPVOID lpNull){
	if(reason == DLL_PROCESS_ATTACH){
		DisableThreadLibraryCalls(hInst);
		// load the richedit dll
		richedit = 	LoadLibrary("riched32.dll");
	}
	else if(reason == DLL_PROCESS_DETACH){
		if(richedit){FreeLibrary(richedit);}
	}
	return TRUE;
}


// window proceedure for the info window (either text/rich text or html)
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp){

	if(msg == WM_SIZE){
		if(file != 2){
			SetWindowPos(GetDlgItem(hwnd,1),0,0,0,LOWORD(lp),HIWORD(lp),
						 SWP_NOZORDER|SWP_NOMOVE);
		}
		else{
			SizeWebBrowser(hwnd);
		}
	}

	else if(msg == WM_COMMAND){
		if(LOWORD(wp) == IDM_COPY || LOWORD(wp) == IDM_SELECTALL){
		CHARRANGE chr;
			chr.cpMin = 0;	chr.cpMax = -1;

			SendMessage(GetDlgItem(hwnd, 1), 
						(LOWORD(wp) == IDM_SELECTALL?EM_EXSETSEL:WM_COPY),
						0,(LPARAM)(LOWORD(wp) == IDM_SELECTALL ? &chr:0));
		}
	}

	else if(LOWORD(wp) == IDM_COPYALL){
		if(OpenClipboard(info)){
		int len=SendDlgItemMessage(info,1,WM_GETTEXTLENGTH,0,0);
		HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE,len+1);
			if(mem){
			char *existing_text = (char *)GlobalLock(mem);
				if(existing_text){
					EmptyClipboard();
					existing_text[0]=0;
					GetDlgItemText(hwnd, 1, existing_text, len+1);
					GlobalUnlock(mem);
					SetClipboardData(CF_TEXT,mem);
				}
			}
			CloseClipboard();
		}
	}

    else if(msg == WM_NOTIFY){
		if(((NMHDR*)lp)->code == EN_MSGFILTER){
			#define lpnmMsg ((MSGFILTER*)lp)
			if(WM_RBUTTONUP == lpnmMsg->msg || WM_KEYUP == lpnmMsg->msg && lpnmMsg->wParam == VK_APPS){
			HMENU hMenu = CreatePopupMenu();
			HWND edit = GetDlgItem(hwnd,1);
			POINT pt;
			RECT rc;
				GetCursorPos(&pt);
				MapWindowPoints(HWND_DESKTOP, edit, &pt, 1);

				GetClientRect(edit, &rc);

				if(!PtInRect(&rc, pt)){pt.x = pt.y = 0;}

				AppendMenu(hMenu,MF_STRING,IDM_COPY,"&Copy\t  (Ctrl+C)");
				AppendMenu(hMenu,MF_STRING,IDM_COPYALL,"Copy &All\t");
				AppendMenu(hMenu,MF_SEPARATOR,0,0);
				AppendMenu(hMenu,MF_STRING,IDM_SELECTALL,"&Select All\t  (Ctrl+A)");

				// ensures the menu appears in the correct place
				MapWindowPoints(edit, HWND_DESKTOP, &pt, 1);

				// shows the created menu for the selection options at the
				// current cursor position (or the top left corner if the
				// application key is pressed)
				TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON | 
								 TPM_RIGHTBUTTON, pt.x, pt.y, hwnd, 0);

				// destroys the menu once things have finished
				DestroyMenu(hMenu);
			}
		}
	}
	return DefWindowProc(hwnd, msg, wp, lp);
}


HWND CreateAWindow(char* classname, HWND parent, UINT id, UINT style, 
				   UINT styleex, int width, int height){
	return CreateWindowEx(styleex, classname,"",style,0,0,width,height,
						  parent,(HMENU)id,g_hInstance,0);
}


void PageCleanUp(void){
	if(IsWindow(info)){
		DestroyWindow(info);
		info = 0;
	}

	if(IsWindow(button)){
		DestroyWindow(button);
		button = 0;
	}
		
	// need this otherwise subsequent attempts fail to create a window
	if(registered){
		UnregisterClass("HelpButtonClass", g_hInstance);
	}
	registered = 0;
}


LRESULT CALLBACK HookProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp){

	// sent to the outer window to tell it to go to the next inner window
	#define WM_NOTIFY_OUTER_NEXT (WM_USER+0x8)
	if(msg == WM_NOTIFY_OUTER_NEXT){
		PageCleanUp();
		SetWindowLong(hwnd,GWL_WNDPROC,(LONG)proc);
		CallWindowProc(proc,hwnd,msg,wp,lp);
		return 0;
	}

	// F1 of the button was pressed -> need to get this all correctly
	// handled to remove the init issues and also the delays
	else if(msg == WM_HELP || 
			msg == WM_COMMAND && MAKEWPARAM(0xffff,BN_CLICKED) == wp){
		if(!IsWindow(info)){
		WNDCLASS wc;
		CHARFORMAT cf;
		HWND edit;

			ZeroMem(&wc, sizeof(wc));
			wc.style = CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS;
			wc.lpfnWndProc = (WNDPROC) WndProc; 
			wc.hInstance = g_hInstance; 
			wc.lpszClassName = "HelpButtonClass"; 
 
			if(!registered){
				if(!RegisterClass(&wc)){return 1;}
				// only allow the class to be registered once otherwise
				// the function will fail on subsequent attempts to load
				// the window again
				registered = 1;
			}

			info = CreateAWindow("HelpButtonClass",hwnd,0,
								 WS_OVERLAPPEDWINDOW,WS_EX_TOOLWINDOW,
								 300,300);

			// sets the needed window texts
			SetWindowText(info, window_text);

			if(file != 2){
				edit = CreateWindowEx(0,"RichEdit","",WS_CHILD|WS_VISIBLE|
									  WS_VSCROLL|ES_AUTOVSCROLL|ES_MULTILINE|
										  ES_NOHIDESEL|ES_READONLY|
									  (!wordwrap?ES_AUTOHSCROLL|WS_HSCROLL:0),
									  0,0,0,0,info,(HMENU)1,g_hInstance,0);

				SendMessage(edit,EM_SETEVENTMASK,0,
							ENM_SELCHANGE|ENM_MOUSEEVENTS|ENM_KEYEVENTS);

				// use the currently selected window font for a consistant look
				SendMessage(edit,WM_SETFONT,
							SendMessage(button,WM_GETFONT,0,0),MAKELPARAM(1,0));

				// gets the default font and will then set the text to the text
				// size passed in
				cf.cbSize = sizeof(cf);
				SendMessage(edit, EM_GETCHARFORMAT, 0, (LPARAM) &cf);
				if(text_size){
					cf.yHeight = text_size*20;
				}
				SendMessage(edit, EM_SETCHARFORMAT, 0, (LPARAM) &cf);

				if(file){
					if(!RTFEDIT_OpenFile(edit, info_text)){
						SetWindowText(edit, "Unable to read file");
					}
				}
				else{
					SetWindowText(edit, info_text);
				}
			}
			else{OpenWebBrowser(info, info_text);}

			CenterWindow(info);
			ShowWindow(info, SW_SHOW);

			// message loop so that the created window will work correctly
			if(IsWindow(info)){
			MSG umsg;

				while(PeekMessage(&umsg, info, 0, 0, PM_REMOVE)){
					if(umsg.message == WM_QUIT){
						if(file == 2){CloseWebBrowser();}
						// Repost the QUIT message so that it will be
						// retrieved by the primary GetMessage() loop
						PostQuitMessage(umsg.wParam);
						break;
					}
					// pass the message to the correct window, etc
					TranslateMessage(&umsg); 
			        DispatchMessage(&umsg); 
				}
			}
		}
		else{
			SetActiveWindow(info);
		}
	}

	return CallWindowProc(proc,hwnd,msg,wp,lp);
}


void __declspec(dllexport) end(HWND hwndParent, int string_size, char *variables, stack_t **stacktop){
	// need to ensure the window is correctly unsubclassed if it isn't
	// already just incase
	if(GetWindowLong(hwndParent, GWL_WNDPROC) == (LONG)HookProc){
		SetWindowLong(hwndParent,GWL_WNDPROC,(LONG)proc);		
	}
	PageCleanUp();
}


void __declspec(dllexport) show(HWND hwndParent, int string_size, char *variables, stack_t **stacktop){
char temp[1024], button_text[1024], *p, *t;
RECT r;
HDC hdc;
HFONT font = (HFONT)SendMessage(hwndParent, WM_GETFONT, 0, 0);
TEXTMETRIC tm;
SIZE Size;
int i = 0;

	EXDLL_INIT();

	// Clean up the page just incase it was called at a weird time and it
	// will also ensure that we are in a known state
	PageCleanUp();

	ZeroMem(&r, sizeof(r));

	popstring(t = p = temp);

	while(*p){
		if(*p == ',' || !*(p+1)){
			if(!i){
				*p = 0;
				r.left = my_atoi(t);
				t = p+1;
				i++;
			}
			else{
				r.top = my_atoi(t);
			}
		}
		p++;
	}

	popstring(button_text);
	popstring(window_text);
	popstring(info_text);

	
	// check if its a file or html or just use the text as normal
	lstrcpyn(temp, info_text, 7);
	if(!lstrcmpi(temp, "/file=")){
		lstrcpy(info_text, info_text+6);
		file = 1;
	}
	else if(!lstrcmpi(temp, "/html=")){
		lstrcpy(info_text, info_text+6);
		file = 2;
	}
	else{
		file = 0;
	}


	if(file != 2){
	int ret;
		for(i = 0; i < 2; i++){
			ret = popstring(temp);

			// gets the wordwrap status
			if(!lstrcmpi(temp, "wrap")){
				wordwrap = 1;	
			}
			// gets the font size
			else{
				text_size = my_atoi(temp);
			}
			if(ret){break;}
		}
	}

	// ensures that we get the correct extents by selecting the font
	// into the window's dc
	SelectObject(hdc = GetDC(hwndParent), font);
	GetTextMetrics(hdc, &tm);
	GetTextExtentPoint(hdc, button_text, lstrlen(button_text), &Size);
	ReleaseDC(hwndParent, hdc);

	if(*button_text){
		button = CreateWindowEx(WS_EX_TOPMOST|WS_EX_TRANSPARENT,"button",
								button_text,WS_VISIBLE|WS_CHILD|WS_TABSTOP|BS_PUSHBUTTON,
								r.left,r.top,(Size.cx + 4*tm.tmAveCharWidth),
								(Size.cy+tm.tmHeight-tm.tmDescent-1),
								hwndParent,(HMENU)0xffff,g_hInstance,0);
	}

	SendMessage(button, WM_SETFONT, (WPARAM)font, MAKELPARAM(1, 0));

	// check if we have already subclassed and if not then can subclass
	// no point if already have (probably means it has been called in the
	// leave callback - bad but must cope with it!)
	if(GetWindowLong(hwndParent, GWL_WNDPROC) != (LONG)HookProc){
		proc = (PROC)SetWindowLong(hwndParent, GWL_WNDPROC, (LONG)HookProc);
	}
}


// utility functions and all of that :o)
// my_atoi(...)
//
// Converts a string to an integer
//
unsigned int my_atoi(char *s) {
unsigned int v = 0;
int sign = 0;
	if(*s == '-') { s++; sign++; }
	for (;;){
	int c = *s++ - '0';
		if (c < 0 || c > 9) break;
		v*=10;
		v+=c;
	}
	if (sign) return -(int) v;
	return (int)v;
}


// my_memset(...)
//
// Sets n bytes of a block of memory to byte c
//
void* my_memset(void* dest, int c, unsigned count){
unsigned i;
	for(i = 0; i < count; i++)((char*)dest)[i] = (char)c;
	return dest;
}


DWORD CALLBACK RTFEDIT_ReadStream(DWORD dwCookie, LPBYTE pbBuff,
											 DWORD cb, LPDWORD pcb){
	ReadFile((HANDLE)dwCookie, pbBuff, cb, pcb, NULL);
	// return 0 to continue if not all has been fully read in
	return(DWORD)(*pcb >= 0 ? 0 : (*pcb = 0, -1));
}


BOOL RTFEDIT_OpenFile(HWND hRTF, char* file){
HANDLE hFile;

	if(!hRTF){return 0;}

	if((hFile = CreateFile(file, GENERIC_READ, 0, 0,
								  OPEN_EXISTING, 0, 0)) !=
								  INVALID_HANDLE_VALUE){
	EDITSTREAM eStream;
	LPBYTE pbBuff[5];
	DWORD pcb = 0, mode;
	CHARFORMAT font;

		SendMessage(hRTF,EM_GETCHARFORMAT,0,(LPARAM)&font);

		// detects if the file is rtf or not, testing the first five
		// bytes for the control identifier
		ZeroMem(&pbBuff,sizeof(pbBuff));
		ReadFile(hFile, pbBuff, 5, &pcb, NULL);
		mode = lstrcmpi((char*)pbBuff, "{\\rtf") ? SF_TEXT : SF_RTF;
		SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
		
		// the handle to the file
		eStream.dwCookie = (DWORD)hFile;
		eStream.pfnCallback = (EDITSTREAMCALLBACK)
									 RTFEDIT_ReadStream;
		eStream.dwError = 0;
		// reads in the text from the file and will then set the
		// text limit of the control for the number of characters
		// that have been read supposedly :-)
		SendMessage(hRTF, EM_EXLIMITTEXT, 0,
						SendMessage(hRTF, EM_STREAMIN, mode,
										(LPARAM)&eStream));

		// ensures the text formatting is correct after reading
		SendMessage(hRTF,EM_SETCHARFORMAT,0,(LPARAM)&font);

		CloseHandle((HANDLE)hFile);
		return TRUE;
	}
	return FALSE;
}


// CenterWindow(...)
//
// Function used to centre a window over another window
//
// The function gets the sizes of the two windows and will
// create the position for the first window to apppear in the
// centre of the second window
//
// Add in ScreenToClient(,,) or equivalent calls here!
BOOL CenterWindow(HWND ChildW){
HWND ParentW = GetParent(ChildW);
RECT rcChild, rcParent;
int cxChild, cyChild, cxScreen, cyScreen, xNew, yNew;
HDC hdc = GetDC(ChildW);

	// get the height and width of the child window
	GetWindowRect(ChildW, &rcChild);
	cxChild = rcChild.right - rcChild.left;
	cyChild = rcChild.bottom - rcChild.top;

	// gets the display limits
	cxScreen = GetDeviceCaps(hdc, HORZRES);
	cyScreen = GetDeviceCaps(hdc, VERTRES);
	ReleaseDC(ChildW, hdc);

//	if(ParentW != GetDesktopWindow()){
	// get the height and width of the parent window
	//GetWindowRect(ParentW, &rcParent);
/*	}
	else{*/
		SystemParametersInfo(SPI_GETWORKAREA, 0, &rcParent, 0);
	/*}
*/

	// calculates the new x position and adjusts for the screen
	xNew = rcParent.left + (((rcParent.right - rcParent.left) - cxChild) / 2);
	if(xNew < 0){
		xNew = 0;
	}
	else if((xNew + cxChild) > cxScreen){
		xNew = cxScreen - cxChild;
	}

	// calculates the new y position and adjusts for the screen
	yNew = rcParent.top + (((rcParent.bottom - rcParent.top) - cyChild) / 2);
	if(yNew < 0){
		yNew = 0;
	}
	else if((yNew + cyChild) > cyScreen){
		yNew = cyScreen - cyChild;
	}

	// sets the windows position using the position calculated
	return SetWindowPos(ChildW,0,xNew,yNew,0,0,SWP_NOSIZE|SWP_NOZORDER);
}