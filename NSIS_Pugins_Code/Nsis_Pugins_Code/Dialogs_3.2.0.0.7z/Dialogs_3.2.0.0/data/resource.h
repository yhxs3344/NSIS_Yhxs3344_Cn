#include <windows.h>

#define IDD_DIALOG1                             100
#define IDD_DIALOG2                             200
#define IDC_COMBOBOX							40001
#define IDC_LABEL								40002
#define IDC_ENTRY								40003
