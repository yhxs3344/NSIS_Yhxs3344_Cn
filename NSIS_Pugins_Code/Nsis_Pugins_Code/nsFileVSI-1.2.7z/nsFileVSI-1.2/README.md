# nsFileVSI
The nsis plugin for get dll/exe file product version and os type (x86, x64)
https://github.com/simdsoft/nsFileVSI