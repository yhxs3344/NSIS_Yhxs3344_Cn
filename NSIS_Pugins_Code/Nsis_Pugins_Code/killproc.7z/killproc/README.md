# killproc
Killing 64 bit processes from a 32 bit NSIS installer
https://github.com/jonaski/killproc
### Cross-compile with:
cmake .. -DCMAKE_TOOLCHAIN_FILE=../Toolchain-mingw32.cmake
