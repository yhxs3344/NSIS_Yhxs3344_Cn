# UikoTongji
UikoTongji - NSIS Tongji Library 

UikoTongji是一个NSIS统计库，可用于系统参数的获取，发送Post数据。
功能：
- 获取硬件参数
- 发送Post数据