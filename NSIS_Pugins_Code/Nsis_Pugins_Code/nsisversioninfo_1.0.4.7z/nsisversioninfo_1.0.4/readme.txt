INTRODUCTION
------------
This is a plugin DLL for the Nullsoft installer system NSIS.
It allows to get and set values in the Version resource of a PE executable (exe, dll, ...) within the installer.

The inital code that I reused to produce the plugin itself (including the present notice ;)
was borrowed from the nsPerl plugin.

The libVerInfo that is used by the plugin is a port to GCC/MinGW and improvement of the MFC project 
"Modification of Version Information Resources in Compiled Binaries" By Denis Zabavchik
see http://www.codeproject.com/KB/library/VerInfoLib.aspx

Comments, bugs and suggestions are welcomed. Send them to S�bastien Kirche (sebastien.kirche@free.fr)
If you use it, please send me a note.

INSTALLATION
------------
Just launch the installer. The only mandatory file is nsVersionInfo.dll into the NSIS plugins directory.

NSIS functions
--------------

TODO: list the functions - In the mean time, look at the example .nsi

To avoid the loading of the DLL each time you launch a script, you can use /NOUNLOAD.

There's one example in the "examples" directory to help you to start.


DISCLAIMER
----------
THIS IS EXPERIMENTAL SOFTWARE. USE AT YOUR OWN RISK.
THE AUTHORS CAN NOT BE HELD LIABLE UNDER ANY CIRCUMSTANCES FOR
DAMAGE TO HARDWARE OR SOFTWARE, LOST DATA, OR OTHER DIRECT OR
INDIRECT DAMAGE RESULTING FROM THE USE OF THIS SOFTWARE.
IF YOU DO NOT AGREE TO THESE CONDITIONS, YOU ARE NOT PERMITTED
TO USE OR FURTHER DISTRIBUTE THIS SOFTWARE.
