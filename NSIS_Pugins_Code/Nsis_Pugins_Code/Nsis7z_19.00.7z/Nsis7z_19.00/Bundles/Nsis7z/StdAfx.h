// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include "../../../Common/Common.h"
#include <windows.h>
#include <commctrl.h>
#include "../../../Common/MyWindows.h"
#include "../../../Common/NewHandler.h"
#include "pluginapi.h"

#endif
