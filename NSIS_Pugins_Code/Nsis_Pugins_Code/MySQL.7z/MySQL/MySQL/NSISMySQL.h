#pragma once

#ifndef NSISMySQL_DEBUG
	#define NSISMySQL_DEBUG
#endif