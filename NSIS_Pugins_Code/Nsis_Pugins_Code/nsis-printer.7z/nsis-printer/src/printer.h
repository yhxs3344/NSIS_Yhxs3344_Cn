/*
 * Created:  Fri 12 Dec 2014 07:37:55 PM PST
 * Modified: Sat 16 Apr 2016 08:49:49 PM PDT
 *
 * Copyright (C) 2014-2016  Robert Gill
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#define DLLEXPORT __declspec (dllexport)

#define IDD_PRINTER_SELECT 101
#define IDC_PRINTER_COMBO  102
#define IDC_PRINTER_CTEXT  103
